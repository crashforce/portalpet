<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		if(isset($_POST['id']) && is_numeric($_POST['id']) && isset($_POST['type']) && is_numeric($_POST['type'])) {
	
			$id = safe_string($_POST['id']);
			$type = safe_string($_POST['type']);

			if($type == 1) {

				$sql_10 = mysqli_query($db,"SELECT `id`,`user`,`name`,`email` FROM `users` WHERE `id` = '".$id."' LIMIT 1");
				$fetch_10 = mysqli_fetch_array($sql_10);

				$return = array(
					'name' => strip_spam($fetch_10['name']),
					'email' => $fetch_10['email'],
					'username' => $fetch_10['user']
				);

				print_r(json_encode($return));

			} else {

				if(isset($_POST['name']) && isset($_POST['username']) && isset($_POST['email'])) {

					$email = safe_string($_POST['email']);
					$name = safe_string($_POST['name']);
					$username = safe_string($_POST['username']);

					if(mysqli_query($db,"UPDATE `users` SET `name` = '".$name."', `email` = '".$email."', `user` = '".$username."' WHERE `id` = '".$id."' LIMIT 1")) {
						echo 1;
					}

				}
		
			}	
				
		}

	}
?>