<?php
	require_once('../../config.php');

	$return = array();

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		if(isset($_POST['last']) && is_numeric($_POST['last'])) {
			$last = safe_string($_POST['last']);
		} else {
			$last = '999999999999999999';
		}

		$sql_75 = mysqli_query($db,"SELECT * FROM `comments` WHERE `id` < '".$last."' ORDER BY `id` DESC LIMIT 25");
		while($fetch_75 = mysqli_fetch_array($sql_75)) {

			$sql_76 = mysqli_query($db,"SELECT `id`,`pic`,`user`,`name` FROM `users` WHERE `id` = '".$fetch_75['from']."' LIMIT 1");
			$fetch_76 = mysqli_fetch_array($sql_76);

			if($fetch_76['pic'] != '') {
				$pic = $settings['site_url'].'/thumbs.php?src=uploads/profiles/'.$fetch_76['pic'].'.jpg&w=45&h=45&zc=1';
			} else {
				$pic = $settings['site_url'].'/thumbs.php?src=uploads/profiles/no_profile_pic.jpg&w=45&h=45&zc=1';
			}

			$return[] = array(
				'id' => $fetch_75['id'],
				'time' => timeAgo($fetch_75['time']),
				'name' => strip_spam($fetch_76['name']),
				'profile' => $settings['site_url'].'/'.$fetch_76['user'],
				'pic' => $pic,
				'info' => strip_spam($fetch_75['msg'])
			);

		}
	
	}

	print_r(json_encode($return));
?>