<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		$sql_10 = mysqli_query($db,"SELECT * FROM `settings` WHERE `id` = '1' LIMIT 1");
		$fetch_10 = mysqli_fetch_array($sql_10);

		$web_468_15 = stripslashes($fetch_10['468_15_web']);
		$web_300_250 = stripslashes($fetch_10['300_250_web']);
		$web_728_90 = stripslashes($fetch_10['728_90_web']);
		$m_320_50 = stripslashes($fetch_10['320_50_m']);

		$return = array(
			'web_468_15' => $web_468_15,
			'web_300_250' => $web_300_250,
			'web_728_90' => $web_728_90,
			'm_320_50' => $m_320_50
		);

		print_r(json_encode($return));

	}
?>