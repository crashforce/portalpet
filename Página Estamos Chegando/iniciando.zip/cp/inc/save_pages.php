<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		$about_page_1 = str_replace("\n","<br>", $_POST['about_page']);
		$terms_page_1 = str_replace("\n","<br>", $_POST['terms_page']);
		$privacy_page_1 = str_replace("\n","<br>", $_POST['privacy_page']);
		$faq_page_1 = str_replace("\n","<br>", $_POST['faq_page']);

		$about_page = addslashes($about_page_1);
		$terms_page = addslashes($terms_page_1);
		$privacy_page = addslashes($privacy_page_1);
		$faq_page = addslashes($faq_page_1);

		if(mysqli_query($db,"UPDATE `settings` SET `faq_page` = '".$faq_page."', `about_page` = '".$about_page."', `terms_page` = '".$terms_page."', `privacy_page` = '".$privacy_page."' WHERE `id` = '1' LIMIT 1")) {
			echo 1;
		} else {
			echo 2;
		}

	} else {
		echo 3;
	}
?>