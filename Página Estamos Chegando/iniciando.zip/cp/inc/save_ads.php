<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		$web_468_15 = addslashes($_POST['web_468_15']);
		$web_300_250 = addslashes($_POST['web_300_250']);
		$web_728_90 = addslashes($_POST['web_728_90']);
		$m_320_50 = addslashes($_POST['m_320_50']);

		if(mysqli_query($db,"UPDATE `settings` SET `320_50_m` = '".$m_320_50."', `468_15_web` = '".$web_468_15."', `300_250_web` = '".$web_300_250."', `728_90_web` = '".$web_728_90."' WHERE `id` = '1' LIMIT 1")) {
			echo 1;
		} else {
			echo 2;
		}

	} else {
		echo 3;
	}
?>