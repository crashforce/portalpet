<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		$sql_10 = mysqli_query($db,"SELECT * FROM `settings` WHERE `id` = '1' LIMIT 1");
		$fetch_10 = mysqli_fetch_array($sql_10);

		if($fetch_10['allow_lang'] == 1) {
			$allow_lang_options = '
			<div data-type="allow_lang" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="allow_lang" class="features_button_2">Disabled</div>
			<input type="hidden" id="_allow_lang" value="1" />';
		} else {
			$allow_lang_options = '
			<div data-type="allow_lang" class="features_button_1">Enabled</div>
			<div data-type="allow_lang" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_allow_lang" value="2" />';
		}

		if($fetch_10['cookie_bar'] == 1) {
			$cookie_bar_options = '
			<div data-type="cookie_bar" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="cookie_bar" class="features_button_2">Disabled</div>
			<input type="hidden" id="_cookie_bar" value="1" />';
		} else {
			$cookie_bar_options = '
			<div data-type="cookie_bar" class="features_button_1">Enabled</div>
			<div data-type="cookie_bar" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_cookie_bar" value="2" />';
		}

		if($fetch_10['remove_comments'] == 1) {
			$remove_comments_options = '
			<div data-type="remove_comments" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="remove_comments" class="features_button_2">Disabled</div>
			<input type="hidden" id="_remove_comments" value="1" />';
		} else {
			$remove_comments_options = '
			<div data-type="remove_comments" class="features_button_1">Enabled</div>
			<div data-type="remove_comments" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_remove_comments" value="2" />';
		}

		if($fetch_10['about_me'] == 1) {
			$aboutme_options = '
			<div data-type="aboutme" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="aboutme" class="features_button_2">Disabled</div>
			<input type="hidden" id="_aboutme" value="1" />';
		} else {
			$aboutme_options = '
			<div data-type="aboutme" class="features_button_1">Enabled</div>
			<div data-type="aboutme" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_aboutme" value="2" />';
		}

		if($fetch_10['report_setting'] == 1) {
			$report_setting_options = '
			<div data-type="report_setting" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="report_setting" class="features_button_2">Disabled</div>
			<input type="hidden" id="_report_setting" value="1" />';
		} else {
			$report_setting_options = '
			<div data-type="report_setting" class="features_button_1">Enabled</div>
			<div data-type="report_setting" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_report_setting" value="2" />';
		}

		if($fetch_10['video_skin'] == 1) {
			$video_skin_options = '
			<div data-type="video_skin" class="features_button_1 features_button_selected">Light</div>
			<div data-type="video_skin" class="features_button_2">Dark</div>
			<input type="hidden" id="_video_skin" value="1" />';
		} else {
			$video_skin_options = '
			<div data-type="video_skin" class="features_button_1">Light</div>
			<div data-type="video_skin" class="features_button_2 features_button_selected">Dark</div>
			<input type="hidden" id="_video_skin" value="2" />';
		}

		if($fetch_10['home_style'] == 1) {
			$custom_12_options = '
			<div data-type="custom_12" class="features_button_1 features_button_selected">Style 1</div>
			<div data-type="custom_12" class="features_button_2">Style 2</div>
			<input type="hidden" id="_custom_12" value="1" />';
		} else {
			$custom_12_options = '
			<div data-type="custom_12" class="features_button_1">Style 1</div>
			<div data-type="custom_12" class="features_button_2 features_button_selected">Style 2</div>
			<input type="hidden" id="_custom_12" value="2" />';
		}

		if($fetch_10['custom_6'] == 1) {
			$custom_6_options = '
			<div data-type="custom_6" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="custom_6" class="features_button_2">Disabled</div>
			<input type="hidden" id="_custom_6" value="1" />';
		} else {
			$custom_6_options = '
			<div data-type="custom_6" class="features_button_1">Enabled</div>
			<div data-type="custom_6" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_custom_6" value="2" />';
		}

		if($fetch_10['custom_5'] == 1) {
			$custom_5_options = '
			<div data-type="custom_5" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="custom_5" class="features_button_2">Disabled</div>
			<input type="hidden" id="_custom_5" value="1" />';
		} else {
			$custom_5_options = '
			<div data-type="custom_5" class="features_button_1">Enabled</div>
			<div data-type="custom_5" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_custom_5" value="2" />';
		}

		if($fetch_10['custom_4'] == 1) {
			$custom_4_options = '
			<div data-type="custom_4" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="custom_4" class="features_button_2">Disabled</div>
			<input type="hidden" id="_custom_4" value="1" />';
		} else {
			$custom_4_options = '
			<div data-type="custom_4" class="features_button_1">Enabled</div>
			<div data-type="custom_4" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_custom_4" value="2" />';
		}

		if($fetch_10['rating_system'] == 1) {
			$rating_system_options = '
			<div data-type="rating_system" class="features_button_1 features_button_selected">Like button</div>
			<div data-type="rating_system" class="features_button_2">Rate bar</div>
			<input type="hidden" id="_rating_system" value="1" />';
		} else {
			$rating_system_options = '
			<div data-type="rating_system" class="features_button_1">Like button</div>
			<div data-type="rating_system" class="features_button_2 features_button_selected">Rate bar</div>
			<input type="hidden" id="_rating_system" value="2" />';
		}

		if($fetch_10['comments_links'] == 1) {
			$comments_links_options = '
			<div data-type="comments_links" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="comments_links" class="features_button_2">Disabled</div>
			<input type="hidden" id="_comments_links" value="1" />';
		} else {
			$comments_links_options = '
			<div data-type="comments_links" class="features_button_1">Enable</div>
			<div data-type="comments_links" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_comments_links" value="2" />';
		}

		if($fetch_10['comments_icons'] == 1) {
			$comments_icons_options = '
			<div data-type="comments_icons" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="comments_icons" class="features_button_2">Disabled</div>
			<input type="hidden" id="_comments_icons" value="1" />';
		} else {
			$comments_icons_options = '
			<div data-type="comments_icons" class="features_button_1">Enabled</div>
			<div data-type="comments_icons" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_comments_icons" value="2" />';
		}

		if($fetch_10['desc_links'] == 1) {
			$desc_links_options = '
			<div data-type="desc_links" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="desc_links" class="features_button_2">Disabled</div>
			<input type="hidden" id="_desc_links" value="1" />';
		} else {
			$desc_links_options = '
			<div data-type="desc_links" class="features_button_1">Enabled</div>
			<div data-type="desc_links" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_desc_links" value="2" />';
		}

		if($fetch_10['video'] == 1) {
			$video_options = '
			<div data-type="video" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="video" class="features_button_2">Disabled</div>
			<input type="hidden" id="_video" value="1" />';
		} else {
			$video_options = '
			<div data-type="video" class="features_button_1">Enabled</div>
			<div data-type="video" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_video" value="2" />';
		}

		if($fetch_10['verified'] == 1) {
			$verified_options = '
			<div data-type="verified" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="verified" class="features_button_2">Disabled</div>
			<input type="hidden" id="_verified" value="1" />';
		} else {
			$verified_options = '
			<div data-type="verified" class="features_button_1">Enabled</div>
			<div data-type="verified" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_verified" value="2" />';
		}

		if($fetch_10['hashtags'] == 1) {
			$hashtags_options = '
			<div data-type="hashtags" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="hashtags" class="features_button_2">Disabled</div>
			<input type="hidden" id="_hashtags" value="1" />';
		} else {
			$hashtags_options = '
			<div data-type="hashtags" class="features_button_1">Enabled</div>
			<div data-type="hashtags" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_hashtags" value="2" />';
		}

		if($fetch_10['fullsize_photos'] == 1) {
			$fullsize_photos_options = '
			<div data-type="fullsize" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="fullsize" class="features_button_2">Disabled</div>
			<input type="hidden" id="_fullsize_photos" value="1" />';
		} else {
			$fullsize_photos_options = '
			<div data-type="fullsize" class="features_button_1">Enabled</div>
			<div data-type="fullsize" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_fullsize_photos" value="2" />';
		}

		if($fetch_10['social_photos'] == 1) {
			$social_photos_options = '
			<div data-type="social" class="features_button_1 features_button_selected">Enabled</div>
			<div data-type="social" class="features_button_2">Disabled</div>
			<input type="hidden" id="_social_photos" value="1" />';
		} else {
			$social_photos_options = '
			<div data-type="social" class="features_button_1">Enabled</div>
			<div data-type="social" class="features_button_2 features_button_selected">Disabled</div>
			<input type="hidden" id="_social_photos" value="2" />';
		}

		$custom_1 = $fetch_10['custom_1'];
		$custom_2 = $fetch_10['custom_2'];
		$custom_3 = $fetch_10['custom_3'];

		if($custom_1 == 'color_1') { $custom_1_color_1 = ' cp_color_selected'; } else { $custom_1_color_1 = ''; }
		if($custom_1 == 'color_2') { $custom_1_color_2 = ' cp_color_selected'; } else { $custom_1_color_2 = ''; }
		if($custom_1 == 'color_3') { $custom_1_color_3 = ' cp_color_selected'; } else { $custom_1_color_3 = ''; }
		if($custom_1 == 'color_4') { $custom_1_color_4 = ' cp_color_selected'; } else { $custom_1_color_4 = ''; }
		if($custom_1 == 'color_5') { $custom_1_color_5 = ' cp_color_selected'; } else { $custom_1_color_5 = ''; }
		if($custom_1 == 'color_6') { $custom_1_color_6 = ' cp_color_selected'; } else { $custom_1_color_6 = ''; }
		if($custom_1 == 'color_7') { $custom_1_color_7 = ' cp_color_selected'; } else { $custom_1_color_7 = ''; }
		if($custom_1 == 'color_8') { $custom_1_color_8 = ' cp_color_selected'; } else { $custom_1_color_8 = ''; }
		if($custom_1 == 'color_9') { $custom_1_color_9 = ' cp_color_selected'; } else { $custom_1_color_9 = ''; }
		if($custom_1 == 'color_10') { $custom_1_color_10 = ' cp_color_selected'; } else { $custom_1_color_10 = ''; }
		if($custom_1 == 'color_11') { $custom_1_color_11 = ' cp_color_selected'; } else { $custom_1_color_11 = ''; }
		if($custom_1 == 'color_12') { $custom_1_color_12 = ' cp_color_selected'; } else { $custom_1_color_12 = ''; }

		if($custom_2 == 'color_1') { $custom_2_color_1 = ' cp_color_selected'; } else { $custom_2_color_1 = ''; }
		if($custom_2 == 'color_2') { $custom_2_color_2 = ' cp_color_selected'; } else { $custom_2_color_2 = ''; }
		if($custom_2 == 'color_3') { $custom_2_color_3 = ' cp_color_selected'; } else { $custom_2_color_3 = ''; }
		if($custom_2 == 'color_4') { $custom_2_color_4 = ' cp_color_selected'; } else { $custom_2_color_4 = ''; }
		if($custom_2 == 'color_5') { $custom_2_color_5 = ' cp_color_selected'; } else { $custom_2_color_5 = ''; }
		if($custom_2 == 'color_6') { $custom_2_color_6 = ' cp_color_selected'; } else { $custom_2_color_6 = ''; }
		if($custom_2 == 'color_7') { $custom_2_color_7 = ' cp_color_selected'; } else { $custom_2_color_7 = ''; }
		if($custom_2 == 'color_8') { $custom_2_color_8 = ' cp_color_selected'; } else { $custom_2_color_8 = ''; }
		if($custom_2 == 'color_9') { $custom_2_color_9 = ' cp_color_selected'; } else { $custom_2_color_9 = ''; }
		if($custom_2 == 'color_10') { $custom_2_color_10 = ' cp_color_selected'; } else { $custom_2_color_10 = ''; }
		if($custom_2 == 'color_11') { $custom_2_color_11 = ' cp_color_selected'; } else { $custom_2_color_11 = ''; }
		if($custom_2 == 'color_12') { $custom_2_color_12 = ' cp_color_selected'; } else { $custom_2_color_12 = ''; }

		if($custom_3 == 'color_1') { $custom_3_color_1 = ' cp_color_selected'; } else { $custom_3_color_1 = ''; }
		if($custom_3 == 'color_2') { $custom_3_color_2 = ' cp_color_selected'; } else { $custom_3_color_2 = ''; }
		if($custom_3 == 'color_3') { $custom_3_color_3 = ' cp_color_selected'; } else { $custom_3_color_3 = ''; }
		if($custom_3 == 'color_4') { $custom_3_color_4 = ' cp_color_selected'; } else { $custom_3_color_4 = ''; }
		if($custom_3 == 'color_5') { $custom_3_color_5 = ' cp_color_selected'; } else { $custom_3_color_5 = ''; }
		if($custom_3 == 'color_6') { $custom_3_color_6 = ' cp_color_selected'; } else { $custom_3_color_6 = ''; }
		if($custom_3 == 'color_7') { $custom_3_color_7 = ' cp_color_selected'; } else { $custom_3_color_7 = ''; }
		if($custom_3 == 'color_8') { $custom_3_color_8 = ' cp_color_selected'; } else { $custom_3_color_8 = ''; }
		if($custom_3 == 'color_9') { $custom_3_color_9 = ' cp_color_selected'; } else { $custom_3_color_9 = ''; }
		if($custom_3 == 'color_10') { $custom_3_color_10 = ' cp_color_selected'; } else { $custom_3_color_10 = ''; }
		if($custom_3 == 'color_11') { $custom_3_color_11 = ' cp_color_selected'; } else { $custom_3_color_11 = ''; }
		if($custom_3 == 'color_12') { $custom_3_color_12 = ' cp_color_selected'; } else { $custom_3_color_12 = ''; }

		$custom_1_value = '
		<div class="cp_customization_color cp_color_1 cp_preview_header '.$custom_1_color_1.'" data-id="color_1"></div>
		<div class="cp_customization_color cp_color_2 cp_preview_header '.$custom_1_color_2.'" data-id="color_2"></div>
		<div class="cp_customization_color cp_color_3 cp_preview_header '.$custom_1_color_3.'" data-id="color_3"></div>
		<div class="cp_customization_color cp_color_4 cp_preview_header '.$custom_1_color_4.'" data-id="color_4"></div>
		<div class="cp_customization_color cp_color_5 cp_preview_header '.$custom_1_color_5.'" data-id="color_5"></div>
		<div class="cp_customization_color cp_color_6 cp_preview_header '.$custom_1_color_6.'" data-id="color_6"></div>
		<div class="cp_customization_color cp_color_7 cp_preview_header '.$custom_1_color_7.'" data-id="color_7"></div>
		<div class="cp_customization_color cp_color_8 cp_preview_header '.$custom_1_color_8.'" data-id="color_8"></div>
		<div class="cp_customization_color cp_color_9 cp_preview_header '.$custom_1_color_9.'" data-id="color_9"></div>
		<div class="cp_customization_color cp_color_10 cp_preview_header '.$custom_1_color_10.'" data-id="color_10"></div>
		<div class="cp_customization_color cp_color_11 cp_preview_header '.$custom_1_color_11.'" data-id="color_11"></div>
		<div class="cp_customization_color cp_color_12 cp_preview_header '.$custom_1_color_12.'" data-id="color_12"></div>';

		$custom_2_value = '
		<div class="cp_customization_color cp_color_1 cp_preview_photo '.$custom_1_color_1.'" data-id="color_1"></div>
		<div class="cp_customization_color cp_color_2 cp_preview_photo '.$custom_2_color_2.'" data-id="color_2"></div>
		<div class="cp_customization_color cp_color_3 cp_preview_photo '.$custom_2_color_3.'" data-id="color_3"></div>
		<div class="cp_customization_color cp_color_4 cp_preview_photo '.$custom_2_color_4.'" data-id="color_4"></div>
		<div class="cp_customization_color cp_color_5 cp_preview_photo '.$custom_2_color_5.'" data-id="color_5"></div>
		<div class="cp_customization_color cp_color_6 cp_preview_photo '.$custom_2_color_6.'" data-id="color_6"></div>
		<div class="cp_customization_color cp_color_7 cp_preview_photo '.$custom_2_color_7.'" data-id="color_7"></div>
		<div class="cp_customization_color cp_color_8 cp_preview_photo '.$custom_2_color_8.'" data-id="color_8"></div>
		<div class="cp_customization_color cp_color_9 cp_preview_photo '.$custom_2_color_9.'" data-id="color_9"></div>
		<div class="cp_customization_color cp_color_10 cp_preview_photo '.$custom_2_color_10.'" data-id="color_10"></div>
		<div class="cp_customization_color cp_color_11 cp_preview_photo '.$custom_2_color_11.'" data-id="color_11"></div>
		<div class="cp_customization_color cp_color_12 cp_preview_photo '.$custom_2_color_12.'" data-id="color_12"></div>';

		$custom_3_value = '
		<div class="cp_customization_color cp_color_1 cp_preview_menu '.$custom_3_color_1.'" data-id="color_1"></div>
		<div class="cp_customization_color cp_color_2 cp_preview_menu '.$custom_3_color_2.'" data-id="color_2"></div>
		<div class="cp_customization_color cp_color_3 cp_preview_menu '.$custom_3_color_3.'" data-id="color_3"></div>
		<div class="cp_customization_color cp_color_4 cp_preview_menu '.$custom_3_color_4.'" data-id="color_4"></div>
		<div class="cp_customization_color cp_color_5 cp_preview_menu '.$custom_3_color_5.'" data-id="color_5"></div>
		<div class="cp_customization_color cp_color_6 cp_preview_menu '.$custom_3_color_6.'" data-id="color_6"></div>
		<div class="cp_customization_color cp_color_7 cp_preview_menu '.$custom_3_color_7.'" data-id="color_7"></div>
		<div class="cp_customization_color cp_color_8 cp_preview_menu '.$custom_3_color_8.'" data-id="color_8"></div>
		<div class="cp_customization_color cp_color_9 cp_preview_menu '.$custom_3_color_9.'" data-id="color_9"></div>
		<div class="cp_customization_color cp_color_10 cp_preview_menu '.$custom_3_color_10.'" data-id="color_10"></div>
		<div class="cp_customization_color cp_color_11 cp_preview_menu '.$custom_3_color_11.'" data-id="color_11"></div>
		<div class="cp_customization_color cp_color_12 cp_preview_menu '.$custom_3_color_12.'" data-id="color_12"></div>';

		$video_size = explode('|',$fetch_10['video_size']);
		$video_size_w = $video_size[0];
		$video_size_h = $video_size[1];

		$return = array(
			'logo' => $fetch_10['logo'],
			'site_url' => $fetch_10['site_url'],
			'fb_api' => $fetch_10['fb_api'],
			'analytics' => stripslashes($fetch_10['analytics']),
			'contact' => $fetch_10['contact'],
			'hashtags' => $hashtags_options,
			'fullsize_photos' => $fullsize_photos_options,
			'social_photos' => $social_photos_options,
			'custom_1' => $custom_1_value,
			'custom_2' => $custom_2_value,
			'custom_3' => $custom_3_value,
			'custom_4' => $custom_4_options,
			'custom_5' => $custom_5_options,
			'desc_links' => $desc_links_options,
			'comments_links' => $comments_links_options,
			'comments_icons' => $comments_icons_options,
			'verified' => $verified_options,
			'video' => $video_options,
			'rating_system' => $rating_system_options,
			'custom_6' => $custom_6_options,
			'custom_5_setting' => $fetch_10['custom_5'],
			'custom_6_setting' => $fetch_10['custom_6'],
			'custom_4_setting' => $fetch_10['custom_4'],
			'video_skin_options' => $video_skin_options,
			'video_size_w' => $video_size_w,
			'video_size_h' => $video_size_h,
			'report_setting' => $report_setting_options,
			'remove_comments' => $remove_comments_options,
			'aboutme' => $aboutme_options,
			'cookie_bar' => $cookie_bar_options,
			'allow_lang' => $allow_lang_options,
			'lang' => $fetch_10['lang'],
			'home_style' => $custom_12_options,
			'email_limit' => $fetch_10['email_limit']
		);

		print_r(json_encode($return));

	}
?>