<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		$sql_10 = mysqli_query($db,"SELECT * FROM `settings` WHERE `id` = '1' LIMIT 1");
		$fetch_10 = mysqli_fetch_array($sql_10);

		$about_page_1 = str_replace("<br>","\n", stripslashes($fetch_10['about_page']));
		$terms_page_1 = str_replace("<br>","\n", stripslashes($fetch_10['terms_page']));
		$privacy_page_1 = str_replace("<br>","\n", stripslashes($fetch_10['privacy_page']));
		$faq_page_1 = str_replace("<br>","\n", stripslashes($fetch_10['faq_page']));

		$return = array(
			'about_page' => $about_page_1,
			'terms_page' => $terms_page_1,
			'privacy_page' => $privacy_page_1,
			'faq_page' => $faq_page_1
		);

		print_r(json_encode($return));

	}
?>