<?php
	require_once('../../config.php');

	$return = array();

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		if(isset($_POST['last']) && is_numeric($_POST['last'])) {
			$last = safe_string($_POST['last']);
		} else {
			$last = '999999999999999999';
		}

		$sql_77 = mysqli_query($db,"SELECT * FROM `photos` WHERE `id` < '".$last."' AND `report` = '1' ORDER BY `id` DESC LIMIT 40");
		while($fetch_77 = mysqli_fetch_array($sql_77)) {

			$sql_78 = mysqli_query($db,"SELECT `id`,`pic`,`user`,`name` FROM `users` WHERE `id` = '".$fetch_77['uid']."' LIMIT 1");
			$fetch_78 = mysqli_fetch_array($sql_78);

			$photo = 'style="background:url('.$settings['site_url'].'/thumbs.php?src=uploads/photos/'.$fetch_77['photo'].'.jpg&w=200&h=200&zc=1) no-repeat;"';

			$return[] = array(
				'id' => $fetch_77['id'],
				'time' => timeAgo($fetch_77['time']),
				'photo' => $photo,
				'name' => strip_spam($fetch_78['name']),
				'type' => $fetch_77['type']
			);

		}
	
	}

	print_r(json_encode($return));
?>