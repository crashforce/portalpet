<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		$id = safe_string($_POST['id']);

		if(mysqli_query($db,"DELETE FROM `photos` WHERE `id` = '".$id."' LIMIT 1")) {
			
			echo 1;

		}
	
	}
?>