<?php
	require_once('../../config.php');

	$return = array();

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		if(isset($_POST['last']) && is_numeric($_POST['last'])) {
			$last = safe_string($_POST['last']);
		} else {
			$last = '999999999999999999';
		}

		if(isset($_POST['tag']) && $_POST['tag']!='') {
			$tag = safe_string($_POST['tag']);
			$sql_79 = mysqli_query($db,"SELECT * FROM `users` WHERE (`email` LIKE '%".$tag."%' OR `user` LIKE '%".$tag."%' OR `name` LIKE '%".$tag."%') AND `id` < '".$last."' ORDER BY `id` DESC LIMIT 25");
		} else {
			$sql_79 = mysqli_query($db,"SELECT * FROM `users` WHERE `id` < '".$last."' ORDER BY `id` DESC LIMIT 25");
		}

		while($fetch_79 = mysqli_fetch_array($sql_79)) {

			if($fetch_79['pic'] != '') {
				$pic = $settings['site_url'].'/thumbs.php?src=uploads/profiles/'.$fetch_79['pic'].'.jpg&w=45&h=45&zc=1';
			} else {
				$pic = $settings['site_url'].'/thumbs.php?src=uploads/profiles/no_profile_pic.jpg&w=45&h=45&zc=1';
			}

			if($fetch_79['verified'] == 0) {
				$verified_class = 'class="unverified"';
			} else {
				$verified_class = '';
			}

			$return[] = array(
				'id' => $fetch_79['id'],
				'name' => strip_spam($fetch_79['name']),
				'pic' => $pic,
				'username' => $fetch_79['user'],
				'email' => $fetch_79['email'],
				'verified' => '<img data-type="'.$fetch_79['id'].'" src="'.get_current_host().'/assets/img/verified_small.png"'.$verified_class.' />'
			);

		}
	
	}

	print_r(json_encode($return));
?>