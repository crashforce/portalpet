<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		if(isset($_POST['uid']) && is_numeric($_POST['uid'])) {
	
			$id = safe_string($_POST['uid']);
				
			$sql_10 = mysqli_query($db,"SELECT `id`,`verified` FROM `users` WHERE `id` = '".$id."' LIMIT 1");
			$fetch_10 = mysqli_fetch_array($sql_10);

			if($fetch_10['verified'] == 0) {
	
				if(mysqli_query($db,"UPDATE `users` SET `verified` = '1' WHERE `id` = '".$id."' LIMIT 1")) {
					echo 1;
				} else {
					echo 2;
				}
		
			} else {

				if(mysqli_query($db,"UPDATE `users` SET `verified` = '0' WHERE `id` = '".$id."' LIMIT 1")) {
					echo 1;
				} else {
					echo 2;
				}

			}
				
		}

	}
?>