<?php
	require_once('../../config.php');

	$return = array();

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		if(isset($_POST['last']) && is_numeric($_POST['last'])) {
			$last = safe_string($_POST['last']);
		} else {
			$last = '999999999999999999';
		}

		$sql_72 = mysqli_query($db,"SELECT * FROM `activity` WHERE `id` < '".$last."' ORDER BY `id` DESC LIMIT 50");
		while($fetch_72 = mysqli_fetch_array($sql_72)) {

			$names = array();

			$sql_73 = mysqli_query($db,"SELECT `id`,`user`,`name` FROM `users` WHERE `id` = '".$fetch_72['uid']."' LIMIT 1");
			$fetch_73 = mysqli_fetch_array($sql_73);

			$sql_74 = mysqli_query($db,"SELECT `id`,`pic`,`user`,`name` FROM `users` WHERE `id` = '".$fetch_72['aid']."' LIMIT 1");
			$fetch_74 = mysqli_fetch_array($sql_74);

			if($fetch_72['type'] == '1') {
				$content = 'Rating';
				$content_2 = strip_spam($fetch_72['content']);	
			}

			if($fetch_72['type'] == '2') {
				$content = 'Comment';
				$content_2 = strip_spam($fetch_72['content']);	
			}

			if($fetch_72['type'] == '3') {
				$content = 'Follow';
				$content_2 = strip_spam($fetch_73['name']);			
			}

			if($fetch_72['type'] == '4') {
				$content = 'Unfollow';
				$content_2 = strip_spam($fetch_73['name']);
			}

			if($fetch_72['type'] == '5') {
				$content = 'Register';
				$content_2 = '';
			}

			if($fetch_72['type'] == '6') {
				$content = 'Like';
				$content_2 = '';
			}

			if($fetch_72['type'] == '7') {
				$content = 'Unlike';
				$content_2 = '';
			}

			if($fetch_74['pic'] != '') {
				$pic = $settings['site_url'].'/thumbs.php?src=uploads/profiles/'.$fetch_74['pic'].'.jpg&w=45&h=45&zc=1';
			} else {
				$pic = $settings['site_url'].'/thumbs.php?src=uploads/profiles/no_profile_pic.jpg&w=45&h=45&zc=1';
			}

			$return[] = array(
				'id' => $fetch_72['id'],
				'time' => timeAgo($fetch_72['date']),
				'name' => strip_spam($fetch_74['name']),
				'type' => $content,
				'content' => strip_Spam($content_2),
				'pic' => $pic,
				'profile' => $settings['site_url'].'/'.$fetch_74['user']
			);

		}
	
	}

	print_r(json_encode($return));
?>