<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		$sql_10 = mysqli_query($db,"SELECT * FROM `settings` WHERE `id` = '1' LIMIT 1");
		$fetch_10 = mysqli_fetch_array($sql_10);

		$return = array(
			'meta_1' => $fetch_10['meta_1'],
			'meta_2' => $fetch_10['meta_2'],
			'meta_3' => $fetch_10['meta_3'],
			'meta_4' => $fetch_10['meta_4'],
			'meta_5' => $fetch_10['meta_5'],
			'meta_6' => $fetch_10['meta_6'],
			'meta_7' => $fetch_10['meta_7'],
			'meta_8' => $fetch_10['meta_8'],
			'meta_9' => $fetch_10['meta_9'],
			'meta_10' => $fetch_10['meta_10'],
			'meta_11' => $fetch_10['meta_11'],
			'meta_12' => $fetch_10['meta_12']
		);

		print_r(json_encode($return));

	}
?>