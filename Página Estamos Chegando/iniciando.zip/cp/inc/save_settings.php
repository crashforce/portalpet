<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		if(isset($_POST['site_url']) && $_POST['site_url'] != '') {

			$site_url = $_POST['site_url'];
			$logo = $_POST['logo'];
			$fb_api = $_POST['fb_api'];
			$analytics = addslashes($_POST['analytics']);
			$contact = $_POST['contact'];
			$hashtags = $_POST['hashtags'];
			$social_photos = $_POST['social_photos'];
			$fullsize_photos = $_POST['fullsize_photos'];
			$custom_1 = $_POST['custom_1'];
			$custom_2 = $_POST['custom_2'];
			$custom_3 = $_POST['custom_3'];
			$custom_5 = $_POST['custom_5'];
			$video = $_POST['video'];
			$desc_links = $_POST['desc_links'];
			$comments_links = $_POST['comments_links'];
			$comments_icons = $_POST['comments_icons'];
			$verified = $_POST['verified'];
			$video = $_POST['video'];
			$custom_4 = $_POST['custom_4'];
			$custom_6 = $_POST['custom_6'];
			$video_skin = $_POST['video_skin'];
			$video_size = $_POST['video_size'];
			$rating_system = $_POST['rating_system'];
			$report_setting = $_POST['report_setting'];
			$remove_comments = $_POST['remove_comments'];
			$aboutme = $_POST['aboutme'];
			$cookie_bar = $_POST['cookie_bar'];
			$allow_lang = $_POST['allow_lang'];
			$language = $_POST['langs'];
			$home_style = $_POST['home_style'];
			$email_limit = $_POST['email_limit'];

			$sql_103 = mysqli_query($db,"SELECT `id`,`rating_system` FROM `settings` WHERE `id` = '1' LIMIT 1");
			$fetch_103 = mysqli_fetch_array($sql_103);

			if($fetch_103['rating_system'] != $rating_system) {
				mysqli_query($db,"DELETE FROM `ratings` WHERE `id` != '0'");
				mysqli_query($db,"UPDATE `photos` SET `score` = '0', `ratings` = '', `votes` = '0' WHERE `votes` > '0'");
			}

			if(isset($_POST['new_password']) && $_POST['new_password'] != '') {
				$new_password = $_POST['new_password'];
				mysqli_query($db,"UPDATE `cp` SET `pass` = '".$new_password."' WHERE `id` = '1' LIMIT 1");
			}
	
			if(mysqli_query($db,"UPDATE `settings` SET `email_limit` = '".$email_limit."', `home_style` = '".$home_style."', `allow_lang` = '".$allow_lang."', `lang` = '".$language."', `cookie_bar` = '".$cookie_bar."', `about_me` = '".$aboutme."', `remove_comments` = '".$remove_comments."', `report_setting` = '".$report_setting."', `rating_system` = '".$rating_system."', `video_skin` = '".$video_skin."', `video_size` = '".$video_size."', `custom_6` = '".$custom_6."', `custom_5` = '".$custom_5."', `custom_4` = '".$custom_4."', `video` = '".$video."', `desc_links` = '".$desc_links."', `comments_links` = '".$comments_links."', `comments_icons` = '".$comments_icons."', `verified` = '".$verified."', `custom_2` = '".$custom_2."', `custom_3` = '".$custom_3."', `custom_1` = '".$custom_1."', `fullsize_photos` = '".$fullsize_photos."', `social_photos` = '".$social_photos."', `hashtags` = '".$hashtags."', `contact` = '".$contact."', `site_url` = '".$site_url."', `logo` = '".$logo."', `fb_api` = '".$fb_api."', `analytics` = '".$analytics."' WHERE `id` = '1' LIMIT 1")) {
				echo 1;
			} else {
				echo 2;
			}

		} else {
			echo 3;
		}

	}
?>