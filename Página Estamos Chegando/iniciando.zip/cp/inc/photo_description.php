<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged'])) {

		if(isset($_POST['id']) && is_numeric($_POST['id']) && isset($_POST['type']) && is_numeric($_POST['type'])) {
	
			$id = safe_string($_POST['id']);
			$type = safe_string($_POST['type']);

			if($type == 1) {

				$sql_10 = mysqli_query($db,"SELECT `id`,`desc` FROM `photos` WHERE `id` = '".$id."' LIMIT 1");
				$fetch_10 = mysqli_fetch_array($sql_10);

				echo html_entity_decode(stripslashes($fetch_10['desc']),ENT_QUOTES);

			} else {

				if(isset($_POST['desc']) && $_POST['desc'] != '') {
						
					$desc = strip_tags($_POST['desc']);
					$desc = strip_spam($desc);
					
				} else {
			
					$desc = '';

				}

				if(mysqli_query($db,"UPDATE `photos` SET `desc` = '".$desc."' WHERE `id` = '".$id."' LIMIT 1")) {
					echo 1;
				}
		
			}	
				
		}

	}
?>