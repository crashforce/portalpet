<?php
	require_once('../../config.php');

	if(isset($_SESSION['cp_logged']) && $_SESSION['cp_logged'] == 1) {

		$meta_1 = addslashes(str_replace('"','',$_POST['meta_1']));
		$meta_2 = addslashes(str_replace('"','',$_POST['meta_2']));
		$meta_3 = addslashes(str_replace('"','',$_POST['meta_3']));
		$meta_4 = addslashes(str_replace('"','',$_POST['meta_4']));
		$meta_5 = addslashes(str_replace('"','',$_POST['meta_5']));
		$meta_6 = addslashes(str_replace('"','',$_POST['meta_6']));
		$meta_7 = addslashes(str_replace('"','',$_POST['meta_7']));
		$meta_8 = addslashes(str_replace('"','',$_POST['meta_8']));
		$meta_9 = addslashes(str_replace('"','',$_POST['meta_9']));
		$meta_10 = addslashes(str_replace('"','',$_POST['meta_10']));
		$meta_11 = addslashes(str_replace('"','',$_POST['meta_11']));
		$meta_12 = addslashes(str_replace('"','',$_POST['meta_12']));

		if(mysqli_query($db,"UPDATE `settings` SET `meta_1` = '".$meta_1."', `meta_2` = '".$meta_2."', `meta_3` = '".$meta_3."', `meta_4` = '".$meta_4."', `meta_5` = '".$meta_5."', `meta_6` = '".$meta_6."', `meta_7` = '".$meta_7."', `meta_8` = '".$meta_8."', `meta_9` = '".$meta_9."', `meta_10` = '".$meta_10."', `meta_11` = '".$meta_11."', `meta_12` = '".$meta_12."' WHERE `id` = '1' LIMIT 1")) {
			echo 1;
		} else {
			echo 2;
		}

	} else {
		echo 3;
	}
?>