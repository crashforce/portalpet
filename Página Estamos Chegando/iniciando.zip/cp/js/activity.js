
	var activity_reload = null;
	var activity_limits = 50;

	function load_activity(type) {

		if(type != 3) { $('.cp_main_activity_results').append('<div class="cp_main_loading"></div>'); }

		if(type == 2) {
			var last = $('.cp_main_activity_results .activity_result:last').find('.activity_result_remove').data('id');
		} else {
			var last = '99999999999999999999';
		}
	
		$.post('inc/activity.php', { last: last }, function(get) {

			$('.cp_main_activity_results .cp_main_loading').remove();

			activity_limits = get.length;

			if(get.length == 0) {

				if(type == 1) {
					$('.cp_main_activity_results').append('<div class="cp_main_no_results">No results found</div>');
				}

			} else {

				if(type == 1) { $('.cp_main_activity_table').show(); }

				for(i=0;i<=get.length-1;i++) {

					if(!$('#_activity_'+get[i].id)[0]) {
				
						var result = '<div class="activity_result" id="_activity_'+get[i].id+'" data-id="'+get[i].id+'"><div class="activity_result_pic"><img src="'+get[i].pic+'" /></div><div class="activity_result_content_name">'+get[i].name+'</div><div class="activity_result_content_type">'+get[i].type+'</div><div class="activity_result_content_content">'+get[i].content+'</div><div class="activity_result_content_date">'+get[i].time+'</div><div class="activity_result_remove" data-id="'+get[i].id+'">x</div></div>';
				
						if(type != 3) {
							$('.cp_main_activity_results').append(result);
						} else {
							$(result).hide().fadeIn(2000).prependTo('.cp_main_activity_results');
						}

					} else {

						$('#_activity_'+get[i].id+' .activity_result_content').find('.activity_result_content_time').text(get[i].time);

					}

				}

			}

		}, 'json');
	
	}


       	function activity_scroll(event) {

		if(current_tab == 'activity') {

          		var winHeight = window.innerHeight ? window.innerHeight : $(window).height();
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
        				
			if (closeToBottom && activity_limits == 50 && !$('.cp_main_activity_results .cp_main_loading')[0]) {

				load_activity('2');

			}

		}

      	};

        $(window).bind('scroll', activity_scroll);

	$(document).on('click', '.activity_result_remove', function() {

		var id = $(this).data('id');

		$.post('inc/remove_activity.php', { id: id }, function(get) {

			if(get == 1) {

				$('#_activity_'+id).fadeOut(500);

			}

		});

	});