
	var videos_reload = null;
	var videos_limit = 40;

	function load_videos(type) {

		if(type != 3) { $('.cp_main_videos_results').append('<div class="cp_main_loading"></div>'); }

		if(type == 2) {
			var last = $('.cp_main_videos_results .video_result:last').find('.video_item_options_delete').data('id');
		} else {
			var last = '99999999999999999999';
		}
	
		$.post('inc/videos.php', { last: last }, function(get) {

			$('.cp_main_videos_results .cp_main_loading').remove();

			videos_limit = get.length;

			if(get.length == 0) {

				if(type == 1) { $('.cp_main_videos_results').append('<div class="cp_main_no_results">No results found</div>'); }

			} else {

				for(i=0;i<=get.length-1;i++) {

					if(!$('#_videos_'+get[i].id)[0]) {
				
						var options = '<div class="video_item_options"><div class="video_item_options_menu"><div class="video_item_options_delete" id="del_'+get[i].id+'" data-id="'+get[i].id+'">Delete video</div><div class="video_item_options_edit" id="edit_'+get[i].id+'">Edit video</div></div></div>';
						var play_icon = '<div class="play_icon"></div>';
						var result = '<div class="video_result" '+get[i].photo+' id="_videos_'+get[i].id+'">'+play_icon+''+options+'<div class="video_result_content">'+get[i].time+'</div><div class="video_result_name">'+get[i].name+'</div></div>';
					
						if(type != 3) {
							$('.cp_main_videos_results').append(result);
						} else {
							$(result).hide().fadeIn(2000).prependTo('.cp_main_videos_results');
						}

					} else {

						$('#_videos_'+get[i].id+' .video_result_content').find('.video_result_content_time').text(get[i].time);

					}

				}

			}

		}, 'json');
	
	}

	$(document).on('click', '.video_item_options_delete', function() {

		var id = $(this).attr('id');
		var tid = id.replace('del_','');

		$.post('inc/remove_video.php', { id: tid }, function(get) {

			if(get == 1) {

				$('#_videos_'+tid).fadeOut(500);

			}

		});

	});

	$(document).on('click', '.video_item_options_edit', function() {

		var id = $(this).attr('id');
		var tid = id.replace('edit_','');

		$('.pop_edit_photo .pop_box_header .pop_box_title').text('Edit video');
		$('.pop_edit_photo .pop_box_content .pop_edit_form .pop_edit_form_content .pop_edit_details #pop_edit_description').prop('placeholder','Edit video description...');
		$('.pop_edit_photo .pop_box_content .pop_edit_form .pop_edit_form_content .pop_edit_details .pop_edit_photo_buttons .pop_edit_photo_save').text('Edit video');

		$('.pop').show();
		$('.pop_edit_photo').show();

		$('.pop_edit_details').hide();
		$('.pop_edit_form_content').append('<div class="pop_edit_loading"></div>');

		$.post('inc/photo_description.php', { type: '1', id: tid }, function(get) {

			$('#pop_edit_description').val(get);
			$('#pop_edit_photo').val(tid);

			$('.pop_edit_form_content .pop_edit_loading').remove();
			$('.pop_edit_details').show();

		});

	});

	$(document).on('click', '.pop_edit_video_save', function(get) {

		var desc = $('#pop_edit_description').val();
		var id = $('#pop_edit_photo').val();

		$.post('inc/photo_description.php', { type: '0', desc: desc, id: id }, function(get) {

			if(get == 1) {

				close_pops();

			} else {

				close_pops();

			}

		});

	});	

	$(document).on('click', function(e) {

		var target = e.target;

		if(!$(target).hasClass('video_item_options')) {
			$('.video_item_options_menu').hide();
		}

	});

	$(document).on('click', '.video_item_options', function() {

		if($(this).find('.video_item_options_menu').is(':hidden')) {
			$('.video_item_options_menu').hide();
			$(this).find('.video_item_options_menu').stop().show();
		} else {
			$(this).find('.video_item_options_menu').stop().hide();
		}

	});

       	function videos_scroll(event) {

		if(current_tab == 'videos') {

          		var winHeight = window.innerHeight ? window.innerHeight : $(window).height();
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
        				
			if (closeToBottom && videos_limit == 40 && !$('.cp_main_videos_results .cp_main_loading')[0]) {
			
				load_videos('2');

			}

		}

      	};

        $(window).bind('scroll', videos_scroll);
