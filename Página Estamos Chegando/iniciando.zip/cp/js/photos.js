
	var photos_reload = null;
	var photos_limit = 40;

	function load_photos(type) {

		if(type != 3) { $('.cp_main_photos_results').append('<div class="cp_main_loading"></div>'); }

		if(type == 2) {
			var last = $('.cp_main_photos_results .photo_result:last').find('.photo_item_options_delete').data('id');
		} else {
			var last = '99999999999999999999';
		}
	
		$.post('inc/photos.php', { last: last }, function(get) {

			$('.cp_main_photos_results .cp_main_loading').remove();

			photos_limit = get.length;

			if(get.length == 0) {

				if(type == 1) { $('.cp_main_photos_results').append('<div class="cp_main_no_results">No results found</div>'); }

			} else {

				for(i=0;i<=get.length-1;i++) {

					if(!$('#_photos_'+get[i].id)[0]) {
				
						var options = '<div class="photo_item_options"><div class="photo_item_options_menu"><div class="photo_item_options_delete" id="del_'+get[i].id+'" data-id="'+get[i].id+'">Delete photo</div><div class="photo_item_options_edit" id="edit_'+get[i].id+'">Edit photo</div></div></div>';

						var result = '<div class="photo_result" '+get[i].photo+' id="_photos_'+get[i].id+'">'+options+'<div class="photo_result_content">'+get[i].time+'</div><div class="photo_result_name">'+get[i].name+'</div></div>';
					
						if(type != 3) {
							$('.cp_main_photos_results').append(result);
						} else {
							$(result).hide().fadeIn(2000).prependTo('.cp_main_photos_results');
						}

					} else {

						$('#_photos_'+get[i].id+' .photo_result_content').find('.photo_result_content_time').text(get[i].time);

					}

				}

			}

		}, 'json');
	
	}

	$(document).on('click', '.photo_item_options_delete', function() {

		var id = $(this).attr('id');
		var tid = id.replace('del_','');

		$.post('inc/remove_photo.php', { id: tid }, function(get) {

			if(get == 1) {

				$('#_photos_'+tid).fadeOut(500);

			}

		});

	});

	$(document).on('click', '.photo_item_options_edit', function() {

		var id = $(this).attr('id');
		var tid = id.replace('edit_','');

		$('.pop_edit_photo .pop_box_header .pop_box_title').text('Edit photo');
		$('.pop_edit_photo .pop_box_content .pop_edit_form .pop_edit_form_content .pop_edit_details #pop_edit_description').prop('placeholder','Edit photo description...');
		$('.pop_edit_photo .pop_box_content .pop_edit_form .pop_edit_form_content .pop_edit_details .pop_edit_photo_buttons .pop_edit_photo_save').text('Edit photo');

		$('.pop').show();
		$('.pop_edit_photo').show();

		$('.pop_edit_details').hide();
		$('.pop_edit_form_content').append('<div class="pop_edit_loading"></div>');

		$.post('inc/photo_description.php', { type: '1', id: tid }, function(get) {

			$('#pop_edit_description').val(get);
			$('#pop_edit_photo').val(tid);

			$('.pop_edit_form_content .pop_edit_loading').remove();
			$('.pop_edit_details').show();

		});

	});

	$(document).on('click', '.pop_edit_photo_save', function(get) {

		var desc = $('#pop_edit_description').val();
		var id = $('#pop_edit_photo').val();

		$.post('inc/photo_description.php', { type: '0', desc: desc, id: id }, function(get) {

			if(get == 1) {

				close_pops();

			} else {

				close_pops();

			}

		});

	});	

	$(document).on('click', function(e) {

		var target = e.target;

		if(!$(target).hasClass('photo_item_options')) {
			$('.photo_item_options_menu').hide();
		}

	});

	$(document).on('click', '.photo_item_options', function() {

		if($(this).find('.photo_item_options_menu').is(':hidden')) {
			$('.photo_item_options_menu').hide();
			$(this).find('.photo_item_options_menu').stop().show();
		} else {
			$(this).find('.photo_item_options_menu').stop().hide();
		}

	});

       	function photos_scroll(event) {

		if(current_tab == 'photos') {

          		var winHeight = window.innerHeight ? window.innerHeight : $(window).height();
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
        				
			if (closeToBottom && photos_limit == 40 && !$('.cp_main_photos_results .cp_main_loading')[0]) {
			
				load_photos('2');

			}

		}

      	};

        $(window).bind('scroll', photos_scroll);
