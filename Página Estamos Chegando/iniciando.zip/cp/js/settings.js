
	function load_settings() {

		$.post('inc/load_settings.php', function(get) {

			$('#_site_url').val(get.site_url);
			$('#_logo').val(get.logo);
			$('#_analytics').val(get.analytics);
			$('#_fb_api').val(get.fb_api);
			$('#_contact').val(get.contact);
			$('.features_hashtags').html(get.hashtags);
			$('.features_fullsize').html(get.fullsize_photos);
			$('.features_social').html(get.social_photos);
			$('.features_video').html(get.video);
			$('.features_verified').html(get.verified);
			$('.features_rating').html(get.rating_system);
			$('.features_comments_links').html(get.comments_links);
			$('.features_comments_icons').html(get.comments_icons);
			$('.features_desc_links').html(get.desc_links);
			$('.cp_custom_1').html(get.custom_1);
			$('.cp_custom_2').html(get.custom_2);
			$('.cp_custom_3').html(get.custom_3);
			$('.cp_custom_4').html(get.custom_4);
			$('.cp_custom_5').html(get.custom_5);
			$('.cp_custom_6').html(get.custom_6);
			$('.cp_custom_12').html(get.home_style);
			$('.video_skin').html(get.video_skin_options);
			console.log(get.video_skin_options);
			$('.video_size_w').val(get.video_size_w);
			$('.video_size_h').val(get.video_size_h);
			$('.features_report_setting').html(get.report_setting);
			$('.features_remove_comments').html(get.remove_comments);
			$('.features_aboutme').html(get.aboutme);
			$('.features_cookie_bar').html(get.cookie_bar);
			$('.features_allow_lang').html(get.allow_lang);
			$('#_email_limit').val(get.email_limit);

			if(get.custom_4_setting != 1) {
				$('.custom_4_disable_1, .custom_4_disable_2').show();
				$('.custom_4_enable').hide();
			} else {
				$('.custom_4_enable').show();
				$('.custom_4_disable_1, .custom_4_disable_2').hide();
			}

			if($('#_video').val() == 1 && $('#_custom_4').val() != 1) {
				$('.preview_video_disable').show();
			} else {
				$('.preview_video_disable').hide();
			}

			if(get.custom_6_setting != 1) {
				$('.cp_previews').removeClass('cp_previews_shadow');
			}

			if(get.custom_5_setting != 1) {
				$('.preview_bar_color').removeClass('opacity_on');
			}

			var custom_1_selected = $('.cp_custom_1').find('.cp_color_selected').css('background');
			var custom_2_selected = $('.cp_custom_2').find('.cp_color_selected').css('background');
			var custom_3_selected = $('.cp_custom_3').find('.cp_color_selected').css('background');

			$('.preview_bar_color').css('background',custom_1_selected);
			$('.preview_upload').css('background',custom_2_selected);
			$('head').append('<style>.preview_header_user_logged:hover { background: '+custom_3_selected+' !important; }</style>');

		}, 'json');

	}

	$(document).on('click', '.features_button_1, .features_button_2', function() {
		
		var data_type = $(this).data('type');

		if(data_type == 'video_skin') {

			$('.video_skin').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_video_skin').val('1');
			} else {
				$('#_video_skin').val('2');
			}

		}

		if(data_type == 'custom_12') {

			$('.cp_custom_12').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_custom_12').val('1');
				$('.cp_previews').addClass('cp_previews_shadow');
			} else {
				$('#_custom_12').val('2');
				$('.cp_previews').removeClass('cp_previews_shadow');
			}

		}

		if(data_type == 'custom_6') {

			$('.cp_custom_6').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_custom_6').val('1');
				$('.cp_previews').addClass('cp_previews_shadow');
			} else {
				$('#_custom_6').val('2');
				$('.cp_previews').removeClass('cp_previews_shadow');
			}

		}

		if(data_type == 'custom_5') {

			$('.cp_custom_5').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_custom_5').val('1');
				$('.preview_bar_color').addClass('opacity_on');
			} else {
				$('#_custom_5').val('2');
				$('.preview_bar_color').removeClass('opacity_on');
			}

		}

		if(data_type == 'custom_4') {

			if($('#_video').val() != 1) {
				alert('Video module must be enable');
			} else {

				$('.cp_custom_4').find('.features_button_selected').removeClass('features_button_selected');
				$(this).addClass('features_button_selected');
	
				if($(this).hasClass('features_button_1')) {

					$('#_custom_4').val('1');
					$('.custom_4_enable').show();
					$('.custom_4_disable_1, .custom_4_disable_2').hide();
				
				} else {
				
					$('#_custom_4').val('2');
					$('.custom_4_enable').hide();
					$('.custom_4_disable_1, .custom_4_disable_2').show();
			
				}

			}

		}

		if(data_type == 'hashtags') {

			$('.features_hashtags').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_hashtags').val('1');
			} else {
				$('#_hashtags').val('2');
			}

		}

		if(data_type == 'allow_lang') {

			$('.features_allow_lang').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_allow_lang').val('1');
			} else {
				$('#_allow_lang').val('2');
			}

		}

		if(data_type == 'video') {

			$('.features_video').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_video').val('1');
			} else {
				$('#_video').val('2');
			}

			if($('#_video').val() == 1 && $('#_custom_4').val() != 1) {
				$('.preview_video_disable').show();
			} else {
				$('.preview_video_disable').hide();
			}

		}

		if(data_type == 'verified') {

			$('.features_verified').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_verified').val('1');
			} else {
				$('#_verified').val('2');
			}

		}

		if(data_type == 'desc_links') {

			$('.features_desc_links').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_desc_links').val('1');
			} else {
				$('#_desc_links').val('2');
			}

		}

		if(data_type == 'cookie_bar') {

			$('.features_cookie_bar').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_cookie_bar').val('1');
			} else {
				$('#_cookie_bar').val('2');
			}

		}

		if(data_type == 'report_setting') {

			$('.features_report_setting').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_report_setting').val('1');
			} else {
				$('#_report_setting').val('2');
			}

		}

		if(data_type == 'comments_links') {

			$('.features_comments_links').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_comments_links').val('1');
			} else {
				$('#_comments_links').val('2');
			}

		}

		if(data_type == 'comments_icons') {

			$('.features_comments_icons').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_comments_icons').val('1');
			} else {
				$('#_comments_icons').val('2');
			}

		}

		if(data_type == 'fullsize') {

			$('.features_fullsize').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_fullsize_photos').val('1');
			} else {
				$('#_fullsize_photos').val('2');
			}

		}

		if(data_type == 'remove_comments') {

			$('.features_remove_comments').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_remove_comments').val('1');
			} else {
				$('#_remove_comments').val('2');
			}

		}

		if(data_type == 'aboutme') {

			$('.features_aboutme').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_aboutme').val('1');
			} else {
				$('#_aboutme').val('2');
			}

		}

		if(data_type == 'social') {

			$('.features_social').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_social_photos').val('1');
			} else {
				$('#_social_photos').val('2');
			}

		}

		if(data_type == 'rating_system') {

			$('.features_rating').find('.features_button_selected').removeClass('features_button_selected');
			$(this).addClass('features_button_selected');
	
			if($(this).hasClass('features_button_1')) {
				$('#_rating_system').val('1');
			} else {
				$('#_rating_system').val('2');
			}

		}

	});

	$(document).on('click', '.save_settings', function() {

		var site_url = $('#_site_url').val();
		var logo = $('#_logo').val();
		var analytics = $('#_analytics').val();
		var fb_api = $('#_fb_api').val();
		var new_password = $('#_new_password').val();
		var contact = $('#_contact').val();
		var hashtags = $('#_hashtags').val();
		var fullsize_photos = $('#_fullsize_photos').val();
		var social_photos = $('#_social_photos').val();
		var custom_1 = $('.cp_custom_1').find('.cp_color_selected').data('id');
		var custom_2 = $('.cp_custom_2').find('.cp_color_selected').data('id');
		var custom_3 = $('.cp_custom_3').find('.cp_color_selected').data('id');
		var custom_4 = $('#_custom_4').val();
		var custom_5 = $('#_custom_5').val();
		var desc_links = $('#_desc_links').val();
		var comments_links = $('#_comments_links').val();
		var comments_icons = $('#_comments_icons').val();
		var verified = $('#_verified').val();
		var video = $('#_video').val();
		var custom_6 = $('#_custom_6').val();
		var video_skin = $('#_video_skin').val();
		var video_size = $('.video_size_w').val()+'|'+$('.video_size_h').val();
		var rating_system = $('#_rating_system').val();
		var report_setting = $('#_report_setting').val();
		var remove_comments = $('#_remove_comments').val();
		var aboutme = $('#_aboutme').val();
		var cookie_bar = $('#_cookie_bar').val();
		var allow_lang = $('#_allow_lang').val();
		var langs = $('#_lang').val();
		var home_style = $('#_custom_12').val();
		var email_limit = $('#_email_limit').val();

		$.post('inc/save_settings.php', { email_limit: email_limit, home_style: home_style, allow_lang: allow_lang, langs: langs, cookie_bar: cookie_bar, aboutme: aboutme, remove_comments: remove_comments, report_setting: report_setting, rating_system: rating_system, video_skin: video_skin, video_size: video_size, custom_6: custom_6, custom_5: custom_5, custom_4: custom_4, video: video, verified: verified, comments_links: comments_links, comments_icons: comments_icons, desc_links: desc_links, custom_1: custom_1, custom_2: custom_2, custom_3: custom_3, hashtags: hashtags, social_photos: social_photos, fullsize_photos: fullsize_photos, contact: contact, site_url: site_url, logo: logo, analytics: analytics, fb_api: fb_api, new_password: new_password }, function(get) {

			if(get == 1) {

				$('.cp_saved').stop().fadeIn(1).delay(2000).fadeOut(1000);

			} else {

			}

		});

	});