
	function load_meta() {

		$.post('inc/load_meta.php', function(get) {

			$('#_meta_1').val(get.meta_1);
			$('#_meta_2').val(get.meta_2);
			$('#_meta_3').val(get.meta_3);
			$('#_meta_4').val(get.meta_4);
			$('#_meta_5').val(get.meta_5);
			$('#_meta_6').val(get.meta_6);
			$('#_meta_7').val(get.meta_7);
			$('#_meta_8').val(get.meta_8);
			$('#_meta_9').val(get.meta_9);
			$('#_meta_10').val(get.meta_10);
			$('#_meta_11').val(get.meta_11);
			$('#_meta_12').val(get.meta_12);

		}, 'json');

	}

	$(document).on('click', '.save_meta', function() {

		var meta_1 = $('#_meta_1').val();
		var meta_2 = $('#_meta_2').val();
		var meta_3 = $('#_meta_3').val();
		var meta_4 = $('#_meta_4').val();
		var meta_5 = $('#_meta_5').val();
		var meta_6 = $('#_meta_6').val();
		var meta_7 = $('#_meta_7').val();
		var meta_8 = $('#_meta_8').val();
		var meta_9 = $('#_meta_9').val();
		var meta_10 = $('#_meta_10').val();
		var meta_11 = $('#_meta_11').val();
		var meta_12 = $('#_meta_12').val();

		$.post('inc/save_meta.php', { meta_1: meta_1, meta_2: meta_2, meta_3: meta_3, meta_4: meta_4, meta_5: meta_5, meta_6: meta_6, meta_7: meta_7, meta_8: meta_8, meta_9: meta_9, meta_10: meta_10, meta_11: meta_11, meta_12: meta_12 }, function(get) {

			if(get == 1) {

				$('.cp_saved_1').stop().fadeIn(1).delay(2000).fadeOut(1000);

			} else {

			}

		});

	});