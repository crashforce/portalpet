
	var comments_reload = null;
	var comments_limit = 25;

	function load_comments(type) {

		if(type != 3) { $('.cp_main_comments_results').append('<div class="cp_main_loading"></div>'); }

		if(type == 2) {
			var last = $('.cp_main_comments_results .comment_result:last').find('.comment_result_remove').data('id');
		} else {
			var last = '99999999999999999999';
		}
	
		$.post('inc/comments.php', { last: last }, function(get) {

			$('.cp_main_comments_results .cp_main_loading').remove();

			comments_limit = get.length;

			if(get.length == 0) {

				if(type == 1) { $('.cp_main_comments_results').append('<div class="cp_main_no_results">No results found</div>'); }

			} else {

				if(type == 1) { $('.cp_main_comments_table').show(); }

				for(i=0;i<=get.length-1;i++) {

					if(!$('#_comments_'+get[i].id)[0]) {
				
						var result = '<div class="comment_result" id="_comments_'+get[i].id+'" data-id="'+get[i].id+'"><div class="comment_result_pic"><img src="'+get[i].pic+'" /></div><div class="comment_result_content_name">'+get[i].name+'</div><div class="comment_result_content_comment">'+get[i].info+'</div><div class="comment_result_content_date">'+get[i].time+'</div><div class="comment_result_remove" data-id="'+get[i].id+'">x</div></div>';
					
						if(type != 3) {
							$('.cp_main_comments_results').append(result);
						} else {
							$(result).hide().fadeIn(2000).prependTo('.cp_main_comments_results');
						}

					} else {

						$('#_comments_'+get[i].id+' .comment_result_content').find('.comment_result_content_time').text(get[i].time);

					}

				}

			}

		}, 'json');
	
	}

       	function comments_scroll(event) {

		if(current_tab == 'comments') {

          		var winHeight = window.innerHeight ? window.innerHeight : $(window).height();
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
        				
			if (closeToBottom && comments_limit == 25 && !$('.cp_main_comments_results .cp_main_loading')[0]) {

				load_comments('2');

			}

		}

      	};

        $(window).bind('scroll', comments_scroll);

	$(document).on('click', '.comment_result_remove', function() {

		var id = $(this).data('id');

		$.post('inc/remove_comment.php', { id: id }, function(get) {

			if(get == 1) {

				$('#_comments_'+id).fadeOut(500);

			}

		});

	});