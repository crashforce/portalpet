
	var users_reload = null;
	var users_limit = 25;

	function load_users(type) {

		if(type == 1) {
			$('.cp_main_users_results').html('');
		}

		if(type != 3) { $('.cp_main_users_results').append('<div class="cp_main_loading"></div>'); }

		if(type == 2) {
			var last = $('.cp_main_users_results .user_result:last').find('.user_item_options_edit').data('id');
		} else {
			var last = '99999999999999999999';
		}

		var tag = $('#users_search').val();
	
		$.post('inc/users.php', { last: last, tag: tag }, function(get) {

			$('.cp_main_users_results .cp_main_loading').remove();

			users_limit = get.length;

			if(get.length == 0) {

				if(type == 1) { $('.cp_main_users_results').append('<div class="cp_main_no_results">No results found</div>'); }

			} else {

				if(type == 1) { $('.cp_main_users_table').show(); }

				for(i=0;i<=get.length-1;i++) {

					if(!$('#_users_'+get[i].id)[0]) {
								
						var options = '<div class="user_item_options"><div class="user_item_options_menu"><div class="user_item_options_delete" id="del_'+get[i].id+'">Delete user</div><div class="user_item_options_edit" id="edit_'+get[i].id+'" data-id="'+get[i].id+'">Edit user</div></div></div>';

						var result = '<div class="user_result" id="_users_'+get[i].id+'" data-id="'+get[i].id+'"><div class="user_result_pic"><img src="'+get[i].pic+'" /></div><div class="user_result_content_name">'+get[i].name+'</div><div class="user_result_content_username">'+get[i].username+'</div><div class="user_result_content_email">'+get[i].email+'</div><div class="user_result_content_verified" data-uid="'+get[i].id+'">'+get[i].verified+'</div><div class="user_result_content_options">'+options+'</div></div>';
					
						if(type != 3) {
							$('.cp_main_users_results').append(result);
						} else {
							$(result).hide().fadeIn(2000).prependTo('.cp_main_users_results');
						}

					}

				}

			}

		}, 'json');
	
	}

	$(document).on('click', '.user_item_options_delete', function() {

		var id = $(this).attr('id');
		var tid = id.replace('del_','');

		$.post('inc/remove_user.php', { id: tid }, function(get) {

			if(get == 1) {

				$('#_users_'+tid).fadeOut(500);

			}

		});

	});

	$(document).on('click', '.user_result_content_verified img', function() {

		var uid = $(this).data('type');
		if($(this).hasClass('unverified')) {
			$(this).removeClass('unverified');
		} else {
			$(this).addClass('unverified');
		}

		$.post('inc/verified.php', { uid: uid });

	});

	$(document).on('click', '.user_item_options_edit', function() {

		var id = $(this).attr('id');
		var tid = id.replace('edit_','');

		$('.pop').show();
		$('.pop_edit_user').show();

		$('.pop_edit_details').hide();
		$('.pop_edit_form_content').append('<div class="pop_edit_loading"></div>');

		$.post('inc/user_description.php', { type: '1', id: tid }, function(get) {

			$('#pop_edit_name').val(get.name);
			$('#pop_edit_username').val(get.username);
			$('#pop_edit_email').val(get.email);
			$('#pop_edit_id').val(tid);

			$('.pop_edit_form_content .pop_edit_loading').remove();
			$('.pop_edit_details').show();

		}, 'json');

	});

	$(document).on('click', '.pop_edit_user_save', function(get) {

		var name = $('#pop_edit_name').val();
		var email = $('#pop_edit_email').val();
		var username = $('#pop_edit_username').val();
		var id = $('#pop_edit_id').val();

		$.post('inc/user_description.php', { type: '0', name: name, email: email, username: username, id: id }, function(get) {

			$('#_users_'+id).find('.user_result_content_name').text(name);
			$('#_users_'+id).find('.user_result_content_username').text(username);
			$('#_users_'+id).find('.user_result_content_email').text(email);

			if(get == 1) {

				close_pops();

			} else {

				close_pops();

			}

		});

	});

	$(document).on('click', function(e) {

		var target = e.target;

		if(!$(target).hasClass('user_item_options')) {
			$('.user_item_options_menu').hide();
		}

	});

	$('#users_search').keyup(function (e) {
    		if (e.keyCode == 13) {
			load_users('1');
		}
	});

	$(document).on('click', '.search_users_x', function() {

		$('#users_search').val('');
		load_users('1');

	});

	$(document).on('click', '.user_item_options', function() {

		if($(this).find('.user_item_options_menu').is(':hidden')) {
			$('.user_item_options_menu').hide();
			$(this).find('.user_item_options_menu').stop().show();
		} else {
			$(this).find('.user_item_options_menu').stop().hide();
		}

	});

       	function users_scroll(event) {

		if(current_tab == 'users') {

          		var winHeight = window.innerHeight ? window.innerHeight : $(window).height();
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
        				
			if (closeToBottom && users_limit == 25 && !$('.cp_main_users_results .cp_main_loading')[0]) {

				load_users('2');

			}

		}

      	};

        $(window).bind('scroll', users_scroll);
