
	var reports_reload = null;
	var reports_limit = 40;

	function load_reports(type) {

		if(type != 3) { $('.cp_main_reports_results').append('<div class="cp_main_loading"></div>'); }

		if(type == 2) {
			var last = $('.cp_main_reports_results .report_result:last').find('.reports_item_options_delete').data('id');
		} else {
			var last = '99999999999999999999';
		}
	
		$.post('inc/reports.php', { last: last }, function(get) {

			$('.cp_main_reports_results .cp_main_loading').remove();

			reports_limit = get.length;

			if(get.length == 0) {

				if(type == 1) { $('.cp_main_reports_results').append('<div class="cp_main_no_results">No results found</div>'); }

			} else {

				for(i=0;i<=get.length-1;i++) {

					if(!$('#_reports_'+get[i].id)[0]) {
				
						var options = '<div class="report_item_options"><div class="report_item_options_menu"><div class="report_item_options_delete" id="del_'+get[i].id+'" data-id="'+get[i].id+'">Remove post</div><div class="report_item_options_edit" data-id="'+get[i].id+'">Remove report</div></div></div>';

						if(get[i].type == 1) {
							var play_icon = '<div class="play_icon"></div>';
						} else {
							var play_icon = '';
						}

						var result = '<div class="report_result" '+get[i].photo+' id="_reports_'+get[i].id+'">'+play_icon+''+options+'<div class="report_result_content">'+get[i].time+'</div><div class="report_result_name">'+get[i].name+'</div></div>';
					
						if(type != 3) {
							$('.cp_main_reports_results').append(result);
						} else {
							$(result).hide().fadeIn(2000).prependTo('.cp_main_reports_results');
						}

					} else {

						$('#_reports_'+get[i].id+' .report_result_content').find('.report_result_content_time').text(get[i].time);

					}

				}

			}

		}, 'json');
	
	}

	$(document).on('click', '.report_item_options_delete', function() {

		var tid = $(this).data('id');

		$.post('inc/remove_photo.php', { id: tid }, function(get) {

			if(get == 1) {

				$('#_reports_'+tid).fadeOut(500);

			}

		});

	});

	$(document).on('click', '.report_item_options_edit', function() {

		var tid = $(this).data('id');

		$.post('inc/remove_report.php', { id: tid }, function(get) {

			if(get == 1) {

				$('#_reports_'+tid).fadeOut(500);

			}

		});

	});

	$(document).on('click', function(e) {

		var target = e.target;

		if(!$(target).hasClass('report_item_options')) {
			$('.report_item_options_menu').hide();
		}

	});

	$(document).on('click', '.report_item_options', function() {

		if($(this).find('.report_item_options_menu').is(':hidden')) {
			$('.report_item_options_menu').hide();
			$(this).find('.report_item_options_menu').stop().show();
		} else {
			$(this).find('.report_item_options_menu').stop().hide();
		}

	});

       	function reports_scroll(event) {

		if(current_tab == 'reports') {

          		var winHeight = window.innerHeight ? window.innerHeight : $(window).height();
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
        				
			if (closeToBottom && reports_limit == 40 && !$('.cp_main_reports_results .cp_main_loading')[0]) {
			
				load_reports('2');

			}

		}

      	};

        $(window).bind('scroll', reports_scroll);
