
	function load_pages() {

		$.post('inc/load_pages.php', function(get) {

			$('#_about_page').val(get.about_page);
			$('#_terms_page').val(get.terms_page);
			$('#_privacy_page').val(get.privacy_page);
			$('#_faq_page').val(get.faq_page);

		}, 'json');

	}

	function load_ads() {

		$.post('inc/load_ads.php', function(get) {

			$('#_468_15_web').val(get.web_468_15);
			$('#_300_250_web').val(get.web_300_250);
			$('#_728_90_web').val(get.web_728_90);
			$('#_320_50_m').val(get.m_320_50);

		}, 'json');

	}

	$(document).on('click', '.save_ads', function() {

		var web_468_15 = $('#_468_15_web').val();
		var web_300_250 = $('#_300_250_web').val();
		var web_728_90 = $('#_728_90_web').val();
		var m_320_50 = $('#_320_50_m').val();

		$.post('inc/save_ads.php', { m_320_50: m_320_50, web_468_15: web_468_15, web_300_250: web_300_250, web_728_90: web_728_90 }, function(get) {

			if(get == 1) {

				$('.cp_saved').stop().fadeIn(1).delay(2000).fadeOut(1000);

			} else {

			}

		});

	});

	$(document).on('click', '.save_pages', function() {

		var about_page = $('#_about_page').val();
		var terms_page = $('#_terms_page').val();
		var privacy_page = $('#_privacy_page').val();
		var faq_page = $('#_faq_page').val();

		$.post('inc/save_pages.php', { faq_page: faq_page, about_page: about_page, terms_page: terms_page, privacy_page: privacy_page }, function(get) {

			if(get == 1) {

				$('.cp_saved').stop().fadeIn(1).delay(2000).fadeOut(1000);

			} else {

			}

		});

	});