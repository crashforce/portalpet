
	<script src="../assets/jquery/jquery-2.1.3.min.js" type="text/javascript"></script>

	<script type="text/javascript" src="js/activity.js"></script>
	<script type="text/javascript" src="js/comments.js"></script>
	<script type="text/javascript" src="js/photos.js"></script>
	<script type="text/javascript" src="js/users.js"></script>
	<script type="text/javascript" src="js/settings.js"></script>
	<script type="text/javascript" src="js/pages.js"></script>
	<script type="text/javascript" src="js/meta.js"></script>
	<script type="text/javascript" src="js/videos.js"></script>
	<script type="text/javascript" src="js/reports.js"></script>

	<script type="text/javascript">
	$(function() {

	var current_tab = null;

	<?php
	if(isset($page) && $page != '') {
		if($page == 'activity') {
			echo "$('.round_activity').click();";
		}
		if($page == 'comments') {
			echo "$('.round_comments').click();";
		}
		if($page == 'photos') {
			echo "$('.round_photo').click();";
		}
		if($page == 'videos') {
			echo "$('.round_video').click();";
		}
		if($page == 'users') {
			echo "$('.round_users').click();";
		}
		if($page == 'reports') {
			echo "$('.round_reports').click();";
		}
		if($page == 'settings') {
			echo "$('.round_settings').click();";
		}
	}
	?>
	});

	$(document).on('click', '.cp_main_settings_menu_item', function() {

		$('.cp_saved').stop().hide();
		$('.cp_main_settings_menu').find('.cp_main_settings_menu_item_selected').removeClass('cp_main_settings_menu_item_selected');
		$(this).addClass('cp_main_settings_menu_item_selected');

		$('.cp_settings_tab_block').hide();
		$('#general_'+$(this).data('id')).show();

		if($(this).data('id') == 'ads') {
			load_ads();
		}

		if($(this).data('id') == 'pages') {
			load_pages();
		}

		if($(this).data('id') == 'meta') {
			load_meta();
		}

	});

	function close_pops() {

		$('.pop').hide();
		$('.pop_edit').hide();

		$('#pop_edit_description').val('');
		$('#pop_edit_photo').val('');

	}

	$(document).keydown(function(e){
    
		if(e.which == 27) {

			close_pops();

		}

	});

	$('.pop_box_close, .close_photo, .pop_content, .pop_edit_cancel').on('click', function() {

		close_pops();

	});

	$(document).on('click', '.cp_preview_photo', function() {

		$('.preview_upload').css('background',$('.cp_'+$(this).data('id')).css('background'));

		$('.cp_custom_2').find('.cp_color_selected').removeClass('cp_color_selected');
		$(this).addClass('cp_color_selected');

	});

	$(document).on('click', '.cp_preview_header', function() {

		$('.preview_bar_color').css('background',$('.cp_'+$(this).data('id')).css('background'));

		$('.cp_custom_1').find('.cp_color_selected').removeClass('cp_color_selected');
		$(this).addClass('cp_color_selected');

	});

	$(document).on('click', '.cp_preview_menu', function() {

		$('.cp_custom_3').find('.cp_color_selected').removeClass('cp_color_selected');
		$(this).addClass('cp_color_selected');

		$('head').append('<style>.preview_header_user_logged:hover { background: '+$('.cp_'+$(this).data('id')).css('background')+' !important; }</style>');

	});

	$(document).on('click', '.cp_menu_item', function() {

		if(!$('#progress')[0]) {
			$("body").append($("<div><dt/><dd/></div>").attr("id", "progress"));
			$("#progress").width((50 + Math.random() * 30) + "%");
		}

		current_tab = null;

		$('.cp_main_settings_menu').find('.cp_main_settings_menu_item_selected').removeClass('cp_main_settings_menu_item_selected');
		$('.cp_first_item').addClass('cp_main_settings_menu_item_selected');

		$('.cp_settings_tab_block').hide();
		$('#general_settings').show();

		clearInterval(videos_reload);
		videos_reload = null;
		clearInterval(users_reload);
		users_reload = null;
		clearInterval(activity_reload);
		activity_reload = null;
		clearInterval(comments_reload);
		comments_reload = null;
		clearInterval(photos_reload);
		photos_reload = null;

		$('.cp_tabs').html('');

		$('.cp_main_tab').hide();
		$('.round_activity').removeClass('round_activity_hover');
		$('.round_comments').removeClass('round_comments_hover');
		$('.round_photo').removeClass('round_photo_hover');
		$('.round_users').removeClass('round_users_hover');
		$('.round_settings').removeClass('round_settings_hover');
		$('.round_video').removeClass('round_video_hover');
		$('.round_reports').removeClass('round_reports_hover');

		if($(this).hasClass('round_reports')) {

			window.history.pushState("","", '/cp/reports');

			$('.cp_main_reports').show();
			load_reports('1');
			current_tab = 'reports';

			$(this).addClass('round_reports_hover');
	
		}

		if($(this).hasClass('round_users')) {

			window.history.pushState("","", '/cp/users');

			$('.cp_main_users').show();
			load_users('1');
			current_tab = 'users';

			$(this).addClass('round_users_hover');
	
		}

		if($(this).hasClass('round_photo')) {

			window.history.pushState("","", '/cp/photos');

			$('.cp_main_photos').show();
			load_photos('1');
			current_tab = 'photos';

			$(this).addClass('round_photo_hover');
	
		}

		if($(this).hasClass('round_video')) {

			window.history.pushState("","", '/cp/videos');

			$('.cp_main_videos').show();
			load_videos('1');
			current_tab = 'videos';

			$(this).addClass('round_video_hover');
	
		}

		if($(this).hasClass('round_activity')) {

			window.history.pushState("", "", '/cp/activity');

			$('.cp_main_activity').show();
			load_activity('1');
			current_tab = 'activity';

			$(this).addClass('round_activity_hover');

		}

		if($(this).hasClass('round_comments')) {

			window.history.pushState("", "", '/cp/comments');

			$('.cp_main_comments').show();
			load_comments('1');
			current_tab = 'comments';

			$(this).addClass('round_comments_hover');

		}

		if($(this).hasClass('round_settings')) {

			window.history.pushState("","", '/cp/settings');

			$('.cp_main_settings').show();

			$(this).addClass('round_settings_hover');

			load_settings();
			current_tab = 'settings';
	
		}

		$("#progress").width("101%").delay(100).fadeOut(200, function() {
        		$(this).remove();
    		});

	});
	</script>

</body>
</html>