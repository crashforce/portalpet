<?php
	$main = 0;
	require_once('header.php');
?>

	<div class="cp_login">

		<div class="cp_login_content">
	
			<div class="cp_login_brand unselect">Selfie</div>

			<div class="cp_login_inputs shadow">

				<form action="" method="post">
					<input name="type" type="hidden" value="cp_login" />
					<input name="login" type="text" id="login_focus" placeholder="Administrator username" />
					<input name="pass" type="password" id="pass_focus" placeholder="Password" />
					<input name="in" type="submit" class="login_button" value="Log in panel" />
				</form>
			</div>

		</div>

	</div>

<?php require_once('footer.php'); ?>