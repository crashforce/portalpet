<?php
	require_once('../config.php');

	if($main == 1 && !isset($_SESSION['cp_logged'])) {
		echo '<meta http-equiv="refresh" content="0;URL='.$settings['site_url'].'/cp/login">';
		die();
	}

	if(isset($_POST['type']) && $_POST['type'] == 'cp_login') {

		$login = safe_string($_POST['login']);
		$pass = safe_string($_POST['pass']);

		if(login_cp($login,$pass) != 1) {

			$error = 1;

		} else {

			$_SESSION['cp_logged'] = 1;
			echo '<meta http-equiv="refresh" content="0;URL='.$settings['site_url'].'/cp/activity">';
			die();
		
		}

	}

	if(isset($_GET['page']) && $_GET['page'] !='') {
		$page = safe_string($_GET['page']);
	} else {
		$page = '';
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>

	<title>Administration panel - Selfie</title>
	<base href="<?=$settings['site_url'].'/cp/';?>" />

	<link rel="stylesheet" type="text/css" href="cp.css" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	


</head>

<body>

	<!-- <div class="success_msg">Congrats, you are logged in!</div>--!>
	<?php if(isset($error) && $error == 1) { ?><div class="failed_msg">Login data is incorrect</div><?php } ?>