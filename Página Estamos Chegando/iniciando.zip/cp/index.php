<?php
	$main = 1;
	require_once('header.php');

	$time = time() - 300;
	$online_now = mysqli_num_rows(mysqli_query($db,"SELECT `seen` FROM `users` WHERE `seen` > '".$time."'"));
	if($online_now == 1) {
		$online_text = '<b>'.$online_now.'</b> user online';
	} else {
		$online_text = '<b>'.$online_now.'</b> users online';
	}

	$activity_count = mysqli_num_rows(mysqli_query($db,"SELECT `id` FROM `activity`"));
	$users_count = mysqli_num_rows(mysqli_query($db,"SELECT `id` FROM `users`"));
	$comments_count = mysqli_num_rows(mysqli_query($db,"SELECT `id` FROM `comments`"));
	$photos_count = mysqli_num_rows(mysqli_query($db,"SELECT `id` FROM `photos` WHERE `type` = '0'"));
	$videos_count = mysqli_num_rows(mysqli_query($db,"SELECT `id` FROM `photos` WHERE `type` = '1'"));
	$reports_count = mysqli_num_rows(mysqli_query($db,"SELECT `id`,`report` FROM `photos` WHERE `report` = '1'"));
?>

	<div class="cp_header">

		<div class="cp_header_opacity"></div>

		<div class="cp_header_content">

			<div class="cp_logo unselect">Selfie</div>
			<div class="cp_version unselect">v1.0.4</div>
			<div class="cp_online_users unselect"><?=$online_text;?></div>

			<div class="cp_menu unselect">

				<div class="cp_menu_it">
					<a href="<?=$settings['site_url'].'/logout';?>">
						<div class="cp_menu_item round_logout">Logout</div>
					</a>
				</div>

				<div class="cp_menu_it">
					<div class="cp_menu_item round_settings <?php if($page=='settings') { ?>round_settings_hover<?php } ?>">Settings</div>
				</div>

				<div class="cp_menu_it">
					<div class="cp_menu_item round_users <?php if($page=='users') { ?>round_users_hover<?php } ?>">Users <span style="opacity:0.8;">(<?=$users_count;?>)</span></div>
				</div>

				<div class="cp_menu_it">
					<div class="cp_menu_item round_comments <?php if($page=='comments') { ?>round_comments_hover<?php } ?>">Comments <span style="opacity:0.8;">(<?=$comments_count;?>)</span></div>
				</div>

				<div class="cp_menu_it">
					<div class="cp_menu_item round_reports <?php if($page=='reports') { ?>round_reports_hover<?php } ?>">Reports <span style="opacity:0.8;">(<?=$reports_count;?>)</span></div>
				</div>

				<div class="cp_menu_it">
					<div class="cp_menu_item round_video <?php if($page=='videos') { ?>round_video_hover<?php } ?>">Videos <span style="opacity:0.8;">(<?=$videos_count;?>)</span></div>
				</div>

				<div class="cp_menu_it">
					<div class="cp_menu_item round_photo <?php if($page=='photos') { ?>round_photo_hover<?php } ?>">Photos <span style="opacity:0.8;">(<?=$photos_count;?>)</span></div>
				</div>

				<div class="cp_menu_it">
					<div class="cp_menu_item round_activity <?php if($page=='activity') { ?>round_activity_hover<?php } ?>">Activity <span style="opacity:0.8;">(<?=$activity_count;?>)</span></div>
				</div>
			</div>

		</div>

	</div>

	<div class="pop">

		<div class="pop_content"></div>

		<div class="pop_edit pop_edit_photo">

			<div class="pop_box_header">
				<div class="pop_box_title">Edit photo</div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content">

				<div class="pop_edit_form">

					<div class="pop_edit_form_content">

						<div class="pop_edit_details">

							<input name="pop_edit_photo" type="hidden" id="pop_edit_photo" />
							<textarea name="description_edit" id="pop_edit_description" placeholder="Edit photo description..."></textarea>

							<div class="pop_edit_photo_buttons">
								<div class="pop_edit_save pop_edit_photo_save unselect">Save</div>
								<div class="pop_edit_cancel pop_edit_photo_cancel unselect">Cancel</div>
							</div>

						</div>

					</div>

				</div>


			</div>

		</div>


		<div class="pop_edit pop_edit_user">

			<div class="pop_box_header">
				<div class="pop_box_title">Edit user</div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content">

				<div class="pop_edit_form">

					<div class="pop_edit_form_content pop_edit_form_user_content">

						<div class="pop_edit_details">

							<input name="pop_edit_id" type="hidden" id="pop_edit_id" />
							<input name="pop_edit_name" id="pop_edit_name" type="text" />
							<input name="pop_edit_username" id="pop_edit_username" type="text" />
							<input name="pop_edit_email" id="pop_edit_email" type="text" />
							
							<div class="pop_edit_photo_buttons">
								<div class="pop_edit_save pop_edit_user_save unselect">Save</div>
								<div class="pop_edit_cancel pop_edit_user_cancel unselect">Cancel</div>
							</div>

						</div>

					</div>

				</div>


			</div>

		</div>

	</div>

	<div class="cp">

		<div class="cp_main">

			<div class="cp_main_activity cp_main_tab">

				<div class="cp_main_activity_table">

					<div class="cp_main_activity_table_name">Name</div>
					<div class="cp_main_activity_table_type">Type</div>
					<div class="cp_main_activity_table_content">Content</div>
					<div class="cp_main_activity_table_date">Date</div>

				</div>

				<div class="cp_main_activity_results cp_tabs"></div>

			</div>

			<div class="cp_main_comments cp_main_tab">

				<div class="cp_main_comments_table">

					<div class="cp_main_comments_table_name">Name</div>
					<div class="cp_main_comments_table_comment">Comment</div>
					<div class="cp_main_comments_table_date">Date</div>

				</div>

				<div class="cp_main_comments_results cp_tabs"></div>

			</div>

			<div class="cp_main_photos cp_main_tab">

				<div class="cp_main_photos_results cp_tabs"></div>

			</div>

			<div class="cp_main_reports cp_main_tab">

				<div class="cp_main_reports_results cp_tabs"></div>

			</div>

			<div class="cp_main_videos cp_main_tab">

				<div class="cp_main_videos_results cp_tabs"></div>

			</div>

			<div class="cp_main_users cp_main_tab">

				<div style="width:100%;box-sizing:border-box;background:#f7f7f7;border:1px solid #e1e1e1;padding:15px;position:relative;">
					<input name="filter" id="users_search" type="text" placeholder="Search for name, username or e-mail" style="padding:10px;width:100%;box-sizing:border-box;border:1px solid #e1e1e1;" />
					<div class="search_users_x"></div>
				</div>
				<div class="cp_main_users_table">

					<div class="cp_main_users_table_name">Name</div>
					<div class="cp_main_users_table_username">Username</div>
					<div class="cp_main_users_table_email">E-mail</div>
					<div class="cp_main_users_table_verified"></div>

				</div>

				<div class="cp_main_users_results cp_tabs"></div>

			</div>

			<div class="cp_main_settings cp_main_tab">

				<div class="cp_main_settings_block">

				<div class="cp_settings_tab_block" id="general_ads">

					<div class="cp_settings_title">Settings &nbsp;<span class="raquo">&raquo;</span>&nbsp; Ads</div>

					<div class="cp_settings_inblock_title" style="border-top:0;">468 x 15 (web)</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_pages_value"><textarea name="468x15_text" id="_468_15_web" placeholder="468x15 Ad code"></textarea></div>

					</div>

					<div class="cp_settings_inblock_title">300 x 250 (web)</div>

					<div class="cp_main_settings_db cp_no_margin">

						<div class="cp_main_pages_value"><textarea name="300x250_text" id="_300_250_web" placeholder="300x250 Ad code"></textarea></div>

					</div>

					<div class="cp_settings_inblock_title">728 x 90 (web)</div>

					<div class="cp_main_settings_db cp_no_margin">

						<div class="cp_main_pages_value"><textarea name="728x90_text" id="_728_90_web" placeholder="728x90 Ad code"></textarea></div>

					</div>

					<div class="cp_settings_inblock_title">320 x 50 (mobile)</div>

					<div class="cp_main_settings_db cp_no_margin">

						<div class="cp_main_pages_value"><textarea name="320x50_text" id="_320_50_m" placeholder="320x50 Ad code"></textarea></div>

					</div>

					<div style="padding:10px;margin-top:10px;border-top:1px solid #e1e1e1;overflow:hidden;">
						<div class="save_ads unselect">Save changes</div><div class="cp_saved">Changes has been saved</div>
					</div>

				</div>

				<div class="cp_settings_tab_block" id="general_pages">

					<div class="cp_settings_title">Settings &nbsp;<span class="raquo">&raquo;</span>&nbsp; Legal pages</div>

					<div class="cp_settings_inblock_title" style="border-top:0;">About</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_pages_value"><textarea name="about_text" id="_about_page" placeholder="About Page content..."></textarea></div>

					</div>

					<div class="cp_settings_inblock_title">Faq</div>

					<div class="cp_main_settings_db cp_no_margin">

						<div class="cp_main_pages_value"><textarea name="faq_text" id="_faq_page" placeholder="Faq content..."></textarea></div>

					</div>

					<div class="cp_settings_inblock_title">Terms of use</div>

					<div class="cp_main_settings_db cp_no_margin">

						<div class="cp_main_pages_value"><textarea name="terms_text" id="_terms_page" placeholder="Terms of use content..."></textarea></div>

					</div>

					<div class="cp_settings_inblock_title">Privacy</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_pages_value"><textarea name="privacy_text" id="_privacy_page" placeholder="Privacy content..."></textarea></div>

					</div>

					<div style="padding:10px;margin-top:10px;border-top:1px solid #e1e1e1;overflow:hidden;">
						<div class="save_pages unselect">Save changes</div><div class="cp_saved">Changes has been saved</div>
					</div>

				</div>

				<div class="cp_settings_tab_block" id="general_meta">

					<div class="cp_settings_title">Settings &nbsp;<span class="raquo">&raquo;</span>&nbsp; Meta tags</div>

					<div class="cp_settings_inblock_title" style="border-top:0;">Homepage</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Title</div>
						<div class="cp_main_settings_value"><input name="meta_1" id="_meta_1" type="text" class="large_input" /></div>

					</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Keywords</div>
						<div class="cp_main_settings_value"><input name="meta_2" id="_meta_2" type="text" class="large_input" /></div>

					</div>

					<div class="cp_main_settings_db">
				
						<div class="cp_main_settings_option">Description</div>
						<div class="cp_main_settings_value"><textarea name="meta_3" id="_meta_3" placeholder="Description"></textarea></div>

					</div>

					<div class="cp_settings_inblock_title">Browse users</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Title</div>
						<div class="cp_main_settings_value"><input name="meta_4" id="_meta_4" type="text" class="large_input" /></div>

					</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Keywords</div>
						<div class="cp_main_settings_value"><input name="meta_5" id="_meta_5" type="text" class="large_input" /></div>

					</div>

					<div class="cp_main_settings_db">
				
						<div class="cp_main_settings_option">Description</div>
						<div class="cp_main_settings_value"><textarea name="meta_6" id="_meta_6" placeholder="Description"></textarea></div>

					</div>


					<div class="cp_settings_inblock_title">User profile</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Title</div>
						<div class="cp_main_settings_value"><input name="meta_7" id="_meta_7" type="text" class="large_input" /></div>

					</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Keywords</div>
						<div class="cp_main_settings_value"><input name="meta_8" id="_meta_8" type="text" class="large_input" /></div>

					</div>

					<div class="cp_main_settings_db">
				
						<div class="cp_main_settings_option">Description</div>
						<div class="cp_main_settings_value"><textarea name="meta_9" id="_meta_9" placeholder="Description"></textarea></div>

					</div>


					<div class="cp_settings_inblock_title">Photo</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Title</div>
						<div class="cp_main_settings_value"><input name="meta_10" id="_meta_10" type="text" class="large_input" /></div>

					</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Keywords</div>
						<div class="cp_main_settings_value"><input name="meta_11" id="_meta_11" type="text" class="large_input" /></div>

					</div>

					<div class="cp_main_settings_db">
				
						<div class="cp_main_settings_option">Description</div>
						<div class="cp_main_settings_value"><textarea name="meta_12" id="_meta_12" placeholder="Description"></textarea></div>

					</div>

					<div style="padding:10px;margin-top:10px;border-top:1px solid #e1e1e1;overflow:hidden;">
						<div class="save_meta unselect">Save changes</div><div class="cp_saved cp_saved_1">Changes has been saved</div>
					</div>

				</div>

				<div class="cp_settings_tab_block" id="general_customization">

					<div class="cp_settings_title">Settings &nbsp;<span class="raquo">&raquo;</span>&nbsp; Customization</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Home style</span></div>
						<div class="cp_main_settings_value cp_custom_12"></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Upload menu<br /><span style="color:#777;font-size:12px;">(video module must be enable)</span></div>
						<div class="cp_main_settings_value cp_custom_4" style="padding-top:6px;"></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Header bar opacity</span></div>
						<div class="cp_main_settings_value cp_custom_5"></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Header bar bottom shadow</span></div>
						<div class="cp_main_settings_value cp_custom_6"></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Header bar color</div>
						<div class="cp_main_settings_value cp_custom_1"></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Upload button(s) color</div>
						<div class="cp_main_settings_value cp_custom_2"></div>

					</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">My menu color <span style="color:#777;font-size:12px;">(on hover)</span></div>
						<div class="cp_main_settings_value cp_custom_3"></div>

					</div>

					<div style="padding:10px;margin-top:10px;border-top:1px solid #e1e1e1;overflow:hidden;">
						<div class="save_settings unselect">Save settings</div><div class="cp_saved">Settings has been saved</div>
					</div>

					<div class="cp_settings_inblock_title">Live preview</div>

					<div class="cp_previews cp_previews_shadow">
		
						<div class="preview_header unselect">
							<div class="preview_bar_color opacity_on"></div>
							<div style="z-index:999;position:relative;">
								<div class="preview_logo unselect"><div class="preview_sub_logo"><?php echo $settings['logo_text']; ?></div></div>
								<div class="preview_header_user_logged">
									<img src="<?=$settings['site_url'];?>/thumbs.php?src=uploads/profiles/no_profile_pic.jpg&w=35&h=35&zc=1" class="header_user_logged_pic" />
									<div class="user_menus_load"></div>
								</div>
								<div class="preview_menu">
									<div class="preview_upload unselect custom_4_enable" style="display:none;"><div class="preview_round2 preview_round2_upload"></div></div>
									<div class="preview_upload unselect custom_4_disable_1 preview_video_disable"><div class="preview_round2 preview_round2_video"></div></div>
									<div class="preview_upload unselect custom_4_disable_2"><div class="preview_round2 preview_round2_photo"></div></div>
									<div class="preview_m_item searching unselect"><div class="preview_round preview_round_search"></div></div>
									<div class="preview_m_item unselect"><div class="preview_round preview_round_feed"></div></div>
									<div class="preview_m_item messaging unselect"><div class="preview_round preview_round_chat"></div></div>
									<div class="preview_m_item activitytab unselect"><div class="preview_round preview_round_activity"></div></div>
									<div class="preview_m_item unselect"><div class="preview_round preview_round_users"></div></div>
								</div>
							</div>
						</div>

					</div>

				</div>

				<div class="cp_settings_tab_block" id="general_video">

					<div class="cp_settings_title">Settings &nbsp;<span class="raquo">&raquo;</span>&nbsp; Video module</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Video module</div>
						<div class="cp_main_settings_value features_video">
							<input type="hidden" id="_video" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Player skin</div>
						<div class="cp_main_settings_value video_skin"></div>

					</div>

					<div class="cp_main_settings_db" style="padding-bottom:0px;">

						<div class="cp_main_settings_option">Player size <span style="color:#777;font-size:12px;">(width & height)</span></div>
						<div class="cp_main_settings_value" style="overflow:hidden;">
							<div style="float:left;"><input name="player_size_w" type="text" class="video_size_w" style="width:25px;" /></div>
							<div style="float:left;padding:5px;padding-top:13px;">px</div>							
							<div style="float:left;"><input name="player_size_h" type="text" class="video_size_h" style="width:25px;" /></div>
							<div style="float:left;padding:5px;padding-top:13px;">px</div>
						</div>

					</div>

					<div style="padding:10px;margin-top:10px;border-top:1px solid #e1e1e1;overflow:hidden;">
						<div class="save_settings unselect">Save settings</div><div class="cp_saved">Settings has been saved</div>
					</div>

				</div>

				<div class="cp_settings_tab_block unselect" id="general_features">

					<div class="cp_settings_title">Settings &nbsp;<span class="raquo">&raquo;</span>&nbsp; Features</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Hashtags</div>
						<div class="cp_main_settings_value features_hashtags">
							<input type="hidden" id="_hashtags" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Fullsize photos</div>
						<div class="cp_main_settings_value features_fullsize">
							<input type="hidden" id="_fullsize_photos" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Social photos</div>
						<div class="cp_main_settings_value features_social">
							<input type="hidden" id="_social_photos" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Verified users</div>
						<div class="cp_main_settings_value features_verified">
							<input type="hidden" id="_verified" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Description links</div>
						<div class="cp_main_settings_value features_desc_links">
							<input type="hidden" id="_desc_links" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Report posts</div>
						<div class="cp_main_settings_value features_report_setting">
							<input type="hidden" id="_report_setting" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Comments links</div>
						<div class="cp_main_settings_value features_comments_links">
							<input type="hidden" id="_comments_links" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Comments icons</div>
						<div class="cp_main_settings_value features_comments_icons">
							<input type="hidden" id="_comments_icons" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Remove comments</div>
						<div class="cp_main_settings_value features_remove_comments">
							<input type="hidden" id="_remove_comments" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">About me field</div>
						<div class="cp_main_settings_value features_aboutme">
							<input type="hidden" id="_aboutme" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Cookie bar</div>
						<div class="cp_main_settings_value features_cookie_bar">
							<input type="hidden" id="_cookie_bar" />
						</div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Allow multilanguage</div>
						<div class="cp_main_settings_value features_allow_lang">
							<input type="hidden" id="_allow_lang" />
						</div>

					</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Rating system<br /><span style="color:#777;font-size:12px;">(ratings/likes will reset on change)</span></div>
						<div class="cp_main_settings_value features_rating" style="padding-top:7px;">
							<input type="hidden" id="_rating_system" />
						</div>

					</div>

					<div style="padding:10px;margin-top:10px;border-top:1px solid #e1e1e1;overflow:hidden;">
						<div class="save_settings unselect">Save settings</div><div class="cp_saved">Settings has been saved</div>
					</div>


				</div>

				<div class="cp_settings_tab_block" id="general_password">

					<div class="cp_settings_title">Settings &nbsp;<span class="raquo">&raquo;</span>&nbsp; Change password</div>

					<div style="margin-top:-2px;">&nbsp;</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">New password</div>
						<div class="cp_main_settings_value"><input name="new_password" id="_new_password" type="text" /></div>

					</div>

					<div style="padding:10px;margin-top:10px;border-top:1px solid #e1e1e1;overflow:hidden;">
						<div class="save_settings unselect">Save password</div><div class="cp_saved">New password has been saved</div>
					</div>

				</div>

				<div class="cp_settings_tab_block" id="general_settings">

					<div class="cp_settings_title">Settings &nbsp;<span class="raquo">&raquo;</span>&nbsp; General settings</div>

					<div style="margin-top:-2px;">&nbsp;</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Logo</div>
						<div class="cp_main_settings_value"><input name="logo" id="_logo" type="text" /></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Site URL</div>
						<div class="cp_main_settings_value"><input name="site_url" id="_site_url" type="text" /></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Facebook App ID</div>
						<div class="cp_main_settings_value"><input name="fb_api" id="_fb_api" type="text" /></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Contact email</div>
						<div class="cp_main_settings_value"><input name="contact" id="_contact" type="text" /></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">E-mail limit (per user)</div>
						<div class="cp_main_settings_value"><input name="email_limit" id="_email_limit" type="text" /></div>

					</div>

					<div class="cp_main_settings_db cp_hr">

						<div class="cp_main_settings_option">Language</div>
						<div class="cp_main_settings_value">
							<select name="lang" id="_lang">
								<?php for($i=1;$i<=count($languages_list);$i++) { ?>
								<option value="<?=$languages_list[$i]['file'];?>" <?php if($languages_list[$i]['file'] == $settings['lang']) { echo 'selected'; } ?>><?=$languages_list[$i]['name'];?></option>
								<?php } ?>
							</select>
						</div>

					</div>

					<div class="cp_main_settings_db">

						<div class="cp_main_settings_option">Analytics</div>
						<div class="cp_main_settings_value"><textarea name="analytics" id="_analytics" rows="4" cols="40" placeholder="Analytics tracking code"></textarea></div>

					</div>

					<div style="padding:10px;margin-top:10px;border-top:1px solid #e1e1e1;overflow:hidden;">
						<div class="save_settings unselect">Save settings</div><div class="cp_saved">Settings has been saved</div>
					</div>

				</div>

				</div>

				<div class="cp_main_settings_menu unselect">

					<div class="cp_main_settings_menu_item cp_first_item cp_main_settings_menu_item_selected" data-id="settings">General settings</div>
					<div class="cp_main_settings_menu_item" data-id="features">Features</div>
					<div class="cp_main_settings_menu_item" data-id="video">Video module</div>
					<div class="cp_main_settings_menu_item" data-id="pages">Legal pages</div>
					<div class="cp_main_settings_menu_item" data-id="meta">Meta tags</div>
					<div class="cp_main_settings_menu_item" data-id="customization">Customization</div>
					<div class="cp_main_settings_menu_item" data-id="ads">Ads</div>
					<div class="cp_main_settings_menu_item" data-id="password">Change password</div>

				</div>

				<div style="clear:both;"></div>

			</div>

		</div>

	</div>

<?php require_once('footer.php'); ?>