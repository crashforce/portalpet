
	$(document).on('click','.feed_button', function() {

		feed_limit = 15;
		activity_limit = 15;

		$('.feed_scroll').stop().animate({left: $(this).position().left, width: $(this).width()+30},'100');
		$('.feed_scroll').width($(this).width()+30).data('curl', $('.feed_scroll').position().left).data('curw', $('.feed_scroll').width());

		var id = $(this).attr('id');

		$('.feedside, .trendingside, .activityside').hide();
		
		$('.'+id+'side').show();

		if(mobile == 1) {
			$('.feed_buttons_list_content').find('.feed_button_s').removeClass('feed_button_s');
			$(this).addClass('feed_button_s');
		}

		if(id == 'activity') {
			window.history.pushState("", "", '/activity');
			load_activity('1');
			clearInterval(feed_update);
			feed_update = null;
			activity_update = setInterval(function () { load_activity('2'); }, 10000); 
		}

		if(id == 'trending') {
			window.history.pushState("", "", '/trending');
			clearInterval(feed_update);
			feed_update = null;
			clearInterval(activity_update);
			activity_update = null;
			load_feed('x','1','1','trending');
		}

		if(id == 'feed') {
			window.history.pushState("", "", '/');
			clearInterval(activity_update);
			activity_update = null;
			load_feed('x','1','1','feed');
			feed_update = setInterval(function () { load_feed('9999999999999','2','2','feed'); }, 10000);
		}

	});

	function get_suggestions() {

		$('.suggestions, .load_suggestions').show();
		$('.suggestions_box').html('').hide();

		reload_footer();

		$.post('inc/suggestions.php', function(get) {

			if(get.length == 0) {

				$('.no_suggestions').show();
			
			} else {

				for(i=0;i<=get.length-1;i++) {

					$('.suggestions_box').append('<div class="suggestion"><div class="suggestion_img"><img src="'+get[i].pic+'" class="call_live_profile" data-profileuser="'+get[i].profileuser+'" /></div><div class="suggestion_det"><div class="follow" data-uid="'+get[i].uid+'"><div class="follows_op">'+lang['follow']+'</div><div class="follows_count">'+get[i].follows_count+'</div></div><div class="suggestion_col"><div class="suggestion_name call_live_profile" data-profileuser="'+get[i].profileuser+'">'+get[i].name+'</div><div class="suggestion_verified">'+get[i].verified+'</div></div></div>');
				
				}

			}

			$('.suggestions_box').imagesLoaded(function() {
				$('.suggestions_box').show();
				$('.load_suggestions').hide();
				reload_footer();
			});

		}, 'json');

	}

	$(document).on('click', '.suggestions_reload', function() {
      		get_suggestions();
	});

	function load_feed(id,type,first,page) {
	
		reload_footer();

		if(type == 1) { $('.loading_'+page).show(); $('.no_'+page).hide(); }

		$.getJSON('inc/load_'+page+'.php?id='+id, function(json) {

			feed_limit = json.length;

			if(json.length == 0) {

				$('.loading_'+page).hide();
				if(first == 1) { $('.no_'+page).show(); }

			} else {

				$('.no_'+page).hide();

				for(tid=0;tid<=(json.length)-1;tid++) {
					if(json[tid].id != '') {

						if(!$('#_'+page+'_'+json[tid].url)[0]) {

							if(rating_system != 1) {
								var rate_col = '<div class="feed_item_stats_views feed_rate_1_col">'+json[tid].views+'</div><div class="feed_item_stats_votes feed_rate_1_col">'+json[tid].votes+'</div><div class="feed_item_stats_rating feed_rate_1_col">'+json[tid].score+'</div><div class="feed_item_stats_comments feed_rate_1_col">'+json[tid].comments+'</div>';
							} else {
								var rate_col = '<div class="feed_item_stats_views feed_rate_2_col">'+json[tid].views+'</div><div class="feed_item_stats_votes feed_rate_2_col">'+json[tid].votes+'</div><div class="feed_item_stats_comments feed_rate_2_col">'+json[tid].comments+'</div>';
							}

							if(json[tid].type == 1) {
								var play_icon = '<div class="play_icon play_icon_feed" data-id="'+json[tid].url+'"></div>';
							} else {
								var play_icon = '';
							}

							var results = '<div class="feed_item" data-uid="'+json[tid].time_count+'" data-lid="'+json[tid].id+'" id="_'+page+'_'+json[tid].url+'">'+play_icon+'<div class="feed_item_pic"><img src="'+json[tid].photo+'" class="feed_img" id="feed_img_'+json[tid].url+'" /></div><div class="feed_item_stats">'+rate_col+'</div><div class="feed_item_info"><div class="feed_item_info_arrow"></div><div class="feed_item_info_details"><div class="feed_item_info_avatar call_live_profile" data-profileuser="'+json[tid].profileuser+'"><img src="'+json[tid].uphoto+'" /></div><div class="feed_item_info_data"><div class="feed_item_info_data_name call_live_profile" data-profileuser="'+json[tid].profileuser+'">'+json[tid].name+'</div><div class="feed_item_info_data_time">'+json[tid].time+'</div></div></div></div></div>';

							if(type == 1) {
								$('.'+page).append(results);
							} else {

								$('.no_'+page).hide(function() {

									$(results).hide().fadeIn(1200).prependTo('.'+page);

								});

							}

						} else {

							var find_exist = $('#_'+page+'_'+json[tid].url+' .feed_item_stats');
							$(find_exist).find('.feed_item_stats_views').text(json[tid].views);
							$(find_exist).find('.feed_item_stats_rating').text(json[tid].score);
							$(find_exist).find('.feed_item_stats_votes').text(json[tid].votes);
							$(find_exist).find('.feed_item_stats_comments').text(json[tid].comments);
							$('#_'+page+'_'+json[tid].url+' .feed_item_info .feed_item_info_details .feed_item_info_data').find('.feed_item_info_data_time').text(json[tid].time);

						}

					}
				}

			}

			$('.loading_'+page).hide();

			if($('.pop').is(':hidden') && $('.pop_settings').is(':hidden')) { $('body').css('overflow','auto'); }
			reload_footer();
			loading_bar(2);

		});

	}

	$(document).on('click', '.activity_item_remove', function() {

		var id = $(this).data('id');
		
		$.post('inc/remove_activity.php', { id: id }, function(get) {

			if(get == 1) {

				$('#_activity_'+id).fadeOut(300, function() {

					$('#_activity_'+id).remove();

					if(!$('.activity_item')[0]) {
						$('.no_activity').show();
					}
					

				});

			}

		});

	});

	function load_activity(type) {

		reload_footer();

		if(!$('.activity').is(':hidden')) {

		if(type == 1 || type == 2) {
			var idk = '999999999999999';
		} else {
			if(typeof $('.activity .activity_item:last') != 'undefined') {
				var idx = $('.activity .activity_item:last').attr('id');
				var idk = idx.replace('_activity_','');
			} else {
				var idk = '999999999999999999';
			}
		}

		}

		$.getJSON('inc/load_activity.php?id='+idk, function(json) {

			activity_limit = json.length;

			if(json.length == 0 && type == 1) {
	
				$('.no_activity').show();

			}

			if(json.length > 0) {

				$('.no_activity').hide();

				for(tid=0;tid<=(json.length)-1;tid++) {
					if(json[tid].id != '') {
						if(!$('#_activity_'+json[tid].id)[0]) {

							var profile = '<a href="'+json[tid].aprofile+'">'+json[tid].aname+'</a>';

							var types = json[tid].types;
							var contents = json[tid].contents;

							if(contents == '') {
								var activity_content = '';
							} else {
								var activity_content = '<div class="activity_item_content">'+contents+'</div>';
							}

							var results = '<div class="activity_item" id="_activity_'+json[tid].id+'"><div class="activity_item_remove" data-id="'+json[tid].id+'"></div><div class="activity_item_pic"><a href="'+json[tid].aprofile+'"><img src="'+json[tid].apic+'" /></a></div><div class="activity_item_details"><div class="activity_item_details_type">'+types+'</div><div class="activity_item_date">'+json[tid].date+'</div><div class="activity_item_content">'+activity_content+'</div></div></div>';

							if(type == 1 || type == 3) {
								$('.activity').append(results);
							}
	
							if(type == 2) {
								$(results).hide().fadeIn(2000).prependTo('.activity');
							}


						} else {

							$('#_activity_'+json[tid].id+' .activity_item_details .activity_item_date').text(json[tid].date);

						}

					}
				}

			}

			$('.loading_activity').hide();

			if($('.pop').is(':hidden')) { $('body').css('overflow','auto'); }
			reload_footer();
			loading_bar(2);

		});

	}

       	function onScroll(event) {

          	var winHeight = window.innerHeight ? window.innerHeight : $(window).height();

		if(mobile == 0) {
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
		} else {
			var closeToBottom = ($(window).scrollTop() >= $(document).height() - $(window).height() - 60);
		}
        				
		if (closeToBottom && feed_limit == 15 && $('#_main_now').val() == 'feed') {

			$('.loading_feed').show();

			var id = $('.feed .feed_item:last').data('lid');
			load_feed(id,'1','2','feed');

		}

      	};

        $(window).bind('scroll', onScroll);
	
	$(window).bind('scroll', function() {

		if(!$('.activityside').is(':hidden') && $('#_main_now').val() == 'activity') {

          		var winHeight = window.innerHeight ? window.innerHeight : $(window).height();

			if(mobile == 0) {
				var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
			} else {
				var closeToBottom = ($(window).scrollTop() >= $(document).height() - $(window).height() - 60);
			}
        				
			if (closeToBottom && activity_limit == 15) { 
				
				$('.loading_activity').show();
				load_activity('3');

			}

		}

	});
