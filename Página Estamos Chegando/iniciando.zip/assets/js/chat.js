
	var update_chat = null;
	var check_online = null;
	var send_spam = 1;

	function fetch_conversation(id, loggedid) {

		var toname = $('#_message_info').data('toname');
		var topic = $('#_message_info').data('topic');
		var toprofile = $('#_message_info').data('toprofile');
		var fromname = $('#_message_info').data('fromname');
		var frompic = $('#_message_info').data('frompic');
		var fromprofile = $('#_message_info').data('fromprofile');

		var logs_id = $('#_loggedid').val();

		$.getJSON('inc/messages.php?id='+id, function(get) {

			if(get.length > 0) {

				for(i=0;i<=get.length-1;i++) {

					console.log(get[i].to+' - '+logs_id);
					if(get[i].to != logs_id) {
						var getname = fromname;
						var getpic = frompic;
						var getprofile = fromprofile;
					} else {
						var getname = toname;
						var getpic = topic;
						var getprofile = toprofile;
					}

					console.log('choosen '+getname);

					if(!$('#msg_id_'+i).length){

						$('.conversation').append('<div class="chat_table" id="msg_id_'+i+'"><div class="chat_table_pic call_live_profile" data-profileuser="'+getprofile+'"><img src="'+getpic+'" /></div><div class="left"><div class="chat_table_main"><div class="chat_table_main_name call_live_profile" data-profileuser="'+getprofile+'">'+getname+'</div><div class="chat_table_main_date">'+get[i].date+'</div></div><div class="chat_table_message">'+get[i].message+'</div></div></div>');

						var height = $('.conversation').height();
						$('#conversation').scrollTop(height);

					} else {

						$('.conversation #msg_id_'+i+' .left .chat_table_main').find('.chat_table_main_date').text(get[i].date);

					}

				}

			}

			$('#conversation').perfectScrollbar('update');

		});

	}

	function checker_online(the_id) {

		$.post('inc/check_online.php', { id: the_id }, function(get) {

			if(get == 1) {

				var onliner = '<div class="online_icon"></div>';
			
			} else {

				var onliner = '<div class="online_icon offline"></div>';

			}

			$('.onliner').html(onliner);

		});

	};

	$(document).on('click', '.message, .messages_result', function(loggedid) {

		if(!$(this).hasClass('privacy')) {

			$('.conversation').html('');

			$(document).click();

			if($(this).hasClass('messages_result')) {
		
				var id = $(this).attr('id');
				var the_id = id.replace('_msg_','');

			} else {

				var id = $(this).attr('id');
				var the_id = id.replace('chat_','');

			}

			if($(this).hasClass('messages_result_unread')) {

				var get_unread = $('.chat_notifications').text();

				get_unread--;

				if(get_unread == 0) {
					$('.chat_notifications').hide().text('');
				} else {
					$('.chat_notifications').text(get_unread);
				}

			}

			$('.messages_results').html('');
			$('.messages').hide();
			$('.round_chat').removeClass('menu_active');

			$.getJSON('inc/message_info.php?to='+the_id, function(get) {
					
				$('#_message_info').data('toname',get.toname).data('topic',get.topic).data('toprofile',get.toprofile);
				var found = $('.pop_chat').find('.pop_box_header .pop_box_title').html(get.toname);

				$('#conversation').perfectScrollbar();

				$('#chat_message').focus();

				checker_online(the_id);
				check_online = setInterval(function() { checker_online(the_id); }, 15000);

				fetch_conversation(the_id, loggedid);
				update_chat = setInterval(function () { fetch_conversation(the_id); }, 1000); 

			});

		}

	});

	$('#chat_message').keyup(function(e){
  
		if(e.keyCode == 13){

			var message = $('#chat_message').val();
			var to = $('#chat_to').val();
			var fromname = $('#_message_info').data('fromname');
			var frompic = $('#_message_info').data('frompic');
			var fromprofile = $('#_message_info').data('fromprofile');
			$('#chat_message').val('').focus();

			if(message.length > 0) {

				$.post('inc/chat.php', { to: to, message: message }, function(data) {

					if(data.id >= 0 && $('#msg_id_'+data.id).length == 0) {

						$('.conversation').stop().append('<div class="chat_table" id="msg_id_'+data.id+'"><div class="chat_table_pic call_live_profile" data-profileuser="'+fromprofile+'"><img src="'+frompic+'" /></div><div class="left"><div class="chat_table_main"><div class="chat_table_main_name call_live_profile" data-profileuser="'+fromprofile+'">'+fromname+'</div><div class="chat_table_main_date">'+data.date+'</div></div><div class="chat_table_message">'+data.message+'</div></div></div>');

					}

					$('#conversation').perfectScrollbar('update');
					var height = $('.conversation').height();
					$('#conversation').scrollTop(height);

				}, 'json');

			}
	
		}

	});

	$(document).on('click', '#send', function() {

		var message = $('#chat_message').val();
		var to = $('#chat_to').val();
		var fromname = $('#_message_info').data('fromname');
		var frompic = $('#_message_info').data('frompic');
		var fromprofile = $('#_message_info').data('fromprofile');
		$('#chat_message').val('').focus();

		if(message.length > 0) {

			$.post('inc/chat.php', { to: to, message: message }, function(data) {

				if(data.id >= 0 && $('#msg_id_'+data.id).length == 0) {

					$('.conversation').stop().append('<div class="chat_table" id="msg_id_'+data.id+'"><div class="chat_table_pic call_live_profile" data-profileuser="'+fromprofile+'"><img src="'+frompic+'" /></div><div class="left"><div class="chat_table_main"><div class="chat_table_main_name call_live_profile" data-profileuser="'+fromprofile+'">'+fromname+'</div><div class="chat_table_main_date">'+data.date+'</div></div><div class="chat_table_message">'+data.message+'</div></div></div>');

				}

				$('#conversation').perfectScrollbar('update');
				var height = $('.conversation').height();
				$('#conversation').scrollTop(height);

			}, 'json');

		}
	
	});
