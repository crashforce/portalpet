
	function load_hashtags(id,type,first,hashtagu) {

		document.title = '#'+hashtagu;
		$('#hashtags').text('#'+hashtagu);
	
		if(type == 1) { $('.loading_hashtags').show(); }

		$.post('inc/load_hashtags.php', { id: id, hashtag: hashtagu }, function(json) {

			hashtags_limit = json.length;

			if(json.length == 0) {

				$('.loading_hashtags').hide();
				if(first == 1) { $('.no_hashtags').show(); }

			} else {

				$('.no_hashtags').hide();

				for(tid=0;tid<=(json.length)-1;tid++) {
					if(json[tid].id != '') {

						if(!$('#_hashtags_'+json[tid].url)[0]) {

							if(rating_system != 1) {
								var rate_col = '<div class="hashtags_item_stats_views feed_rate_1_col">'+json[tid].views+'</div><div class="hashtags_item_stats_votes feed_rate_1_col">'+json[tid].votes+'</div><div class="hashtags_item_stats_rating feed_rate_1_col">'+json[tid].score+'</div><div class="hashtags_item_stats_comments feed_rate_1_col">'+json[tid].comments+'</div>';
							} else {
								var rate_col = '<div class="hashtags_item_stats_views feed_rate_2_col">'+json[tid].views+'</div><div class="hashtags_item_stats_votes feed_rate_2_col">'+json[tid].votes+'</div><div class="hashtags_item_stats_comments feed_rate_2_col">'+json[tid].comments+'</div>';
							}

							if(json[tid].type == 1) {
								var play_icon = '<div class="play_icon play_icon_feed" data-id="'+json[tid].url+'"></div>';
							} else {
								var play_icon = '';
							}

							var results = '<div class="hashtags_item" data-uid="'+json[tid].time_count+'" data-lid="'+json[tid].id+'" id="_hashtags_'+json[tid].url+'">'+play_icon+'<div class="hashtags_item_pic"><img src="'+json[tid].photo+'" class="hashtags_img" id="hashtags_img_'+json[tid].url+'" /></div><div class="hashtags_item_stats">'+rate_col+'</div><div class="hashtags_item_info"><div class="hashtags_item_info_arrow"></div><div class="hashtags_item_info_details"><div class="hashtags_item_info_avatar"><img src="'+json[tid].uphoto+'" class="call_live_profile" data-profileuser="'+json[tid].profileuser+'" /></div><div class="hashtags_item_info_data"><div class="hashtags_item_info_data_name call_live_profile" data-profileuser="'+json[tid].profileuser+'">'+json[tid].name+'</div><div class="hashtags_item_info_data_time">'+json[tid].time+'</div></div></div></div></div>';
							$('.hashtags').append(results);

						}

					}
				}

			}

			$('.loading_hashtags').hide();

			$("#progress").width("101%").delay(100).fadeOut(200, function() {
        			$(this).remove();
    			});

			if($('.pop').is(':hidden')) { $('body').css('overflow','auto'); }

		}, 'json');

	}

       	function onScroll(event) {

          	var winHeight = window.innerHeight ? window.innerHeight : $(window).height();

		if(mobile == 0) {
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
		} else {
			var closeToBottom = ($(window).scrollTop() >= $(document).height() - $(window).height() - 60);
		}
        				
		if (closeToBottom && $('#_main_now').val() == 'hashtag' && hashtags_limit == 15) {

			$('.loading_hashtags').show();

			var id = $('.hashtags .hashtags_item:last').data('lid');
			load_hashtags(id,'1','2');

		}

      	};

        $(window).bind('scroll', onScroll);
