
	$(document).on('click', '.pop_join_genderf, .pop_join_genderm', function() {

		if($(this).hasClass('home_2_join_genderm') || $(this).hasClass('home_2_join_genderf')) {

			var s = $('#home_gender_j').val();

			if(!$(this).hasClass(s)) {

				$('.home_2_join_input_genders').find('.home_2_join_checkbox_selected').removeClass('home_2_join_selcheck');
				$('.home_2_join_input_genders').find('.home_2_join_check_name').removeClass('home_2_join_check_name_sel');

				$(this).find('.home_2_join_checkbox_selected').addClass('home_2_join_selcheck');
				$(this).find('.home_2_join_check_name').addClass('home_2_join_check_name_sel');

				if($(this).hasClass('home_2_join_genderm')) {
					$('#home_gender_j').val('pop_join_genderm');
				} else {
					$('#home_gender_j').val('pop_join_genderf');
				}

			}

		} else {

			var s = $('#gender_j').val();

			if(!$(this).hasClass(s)) {

				$('.pop_join_input_genders').find('.pop_join_checkbox_selected').removeClass('pop_join_selcheck');
				$('.pop_join_input_genders').find('.pop_join_check_name').removeClass('pop_join_check_name_sel');

				$(this).find('.pop_join_checkbox_selected').addClass('pop_join_selcheck');
				$(this).find('.pop_join_check_name').addClass('pop_join_check_name_sel');

				if($(this).hasClass('pop_join_genderm')) {
					$('#gender_j').val('pop_join_genderm');
				} else {
					$('#gender_j').val('pop_join_genderf');
				}

			}

		}

	});

	$(document).on('click', '.pop_lostpw_button', function() {

		var email = $('#lostpw_email_focus').val();
		$('.pop_lostpw_error_box').hide();

		if(!validateEmail(email)) {

			$('#lostpw_err_1').stop().fadeIn(1).delay(3000).fadeOut(500);

		} else {

			$.post('inc/lostpw.php', { email: email }, function(get) {

				if(get == 1) {

					$('.pop_lostpw_success_box').stop().fadeIn(1).delay(3000).fadeOut(500);

				}

				if(get == 2) {
	
					$('#lostpw_err_2').stop().fadeIn(1).delay(3000).fadeOut(500);

				}

				if(get == 3) {
	
					$('#lostpw_err_3').stop().fadeIn(1).delay(3000).fadeOut(500);

				}

				if(get == 4) {
	
					$('#lostpw_err_4').stop().fadeIn(1).delay(3000).fadeOut(500);

				}


			});

		}

	});

	$(document).on('click', '.pop_login_button, .pop_login_button_2', function() {

		if($(this).hasClass('pop_login_button')) {
			home_style = 1;
		} else {
			home_style = 2;
		}

		if(home_style == 2) {
			var email = $('#email_2_focus').val();
			var password = $('#password_2_focus').val();
		} else {
			var email = $('#email_focus').val();
			var password = $('#password_focus').val();
		}

		if(email.length > 1 && password.length > 5) {

			$.post('inc/login.php', { email: email, password: password }, function(data) {

				if(data['error'] == 1) {
			
					if(home_style == 2) {

						$('#erro_13').stop().fadeIn(1).delay(3000).fadeOut(1);
						$('#email_2_focus, #password_2_focus').val('');
						$('#email_2_focus').focus();

					} else {

						$('.pop_login_error_box').hide();
						$('#error_box_1').stop().fadeIn(1).delay(3000).fadeOut(500);
						$('#email_focus, #password_focus').val('');
						$('#email_focus').focus();

					}

				} else {

					update_header(1,data['logged'],data['profile']);
					$('#_logged').val(1);
					$('#_loggedid').val(data['id']);
					load_settings_box();
					load_live_page('feed');

				}

			}, 'json');

		} else {

			if(home_style == 2) {

				$('#erro_13').stop().fadeIn(1).delay(3000).fadeOut(1);
				$('#email_2_focus, #password_2_focus').val('');
				$('#email_2_focus').focus();

			} else {

				$('.pop_login_error_box').hide();
				$('#error_box_1').stop().fadeIn(1).delay(3000).fadeOut(500);
				$('#email_focus,#password_focus').val('');
				$('#email_focus').focus();
	
			}
	
		}

	});

	$(document).on('click','.pop_join_button', function() {

		if($(this).hasClass('home_2_join_button')) {

			var name = $('#name_focus_2').val();
			var email = $('#email_j_focus_2').val();
			var password = $('#password_j_focus_2').val();
			var gender2 = $('#home_gender_j').val();

		} else {

			var name = $('#name_focus').val();
			var email = $('#email_j_focus').val();
			var password = $('#password_j_focus').val();
			var gender2 = $('#gender_j').val();

		}

		if(gender2 == 'pop_join_genderm') {
			var gender = 'm';
		} else {
			var gender = 'f';
		}

		if(name.length < 4) {

			$('.pop_join_error_box, .pop_join_error_box_2').hide();

			if(home_style == 2) {
				$('#error_box_2_2').stop().fadeIn(1).delay(3000).fadeOut(500);
				$('#name_focus_2,#email_j_focus_2,#password_j_focus_2').val('');
				$('#name_focus_2').focus();
			} else {
				$('#error_box_2').stop().fadeIn(1).delay(3000).fadeOut(500);
				$('#name_focus,#email_j_focus,#password_j_focus').val('');
				$('#name_focus').focus();
			}

		} else {

			if(!validateEmail(email)) {

				$('.pop_join_error_box').hide();

				if(home_style == 2) {
					$('#error_box_3_2').stop().fadeIn(1).delay(3000).fadeOut(500);
					$('#email_j_focus_2,#password_j_focus_2').val('');
					$('#email_j_focus_2').focus();
				} else {
					$('#error_box_3').stop().fadeIn(1).delay(3000).fadeOut(500);
					$('#email_j_focus,#password_j_focus').val('');
					$('#email_j_focus').focus();
				}

			} else {

				if(!alphanum(password)) {

					$('.pop_join_error_box, .pop_join_error_box_2').hide();

					if(home_style == 2) {
						$('#error_box_4_2').stop().fadeIn(1).delay(3000).fadeOut(500);
						$('#password_j_focus_2').val('').focus();
					} else {
						$('#error_box_4').stop().fadeIn(1).delay(3000).fadeOut(500);
						$('#password_j_focus').val('').focus();
					}

				} else {

					$.post('inc/join.php', { name: name, email: email, password: password, gender: gender }, function(data) {

						if(data == 2) {
			
							$('.pop_join_error_box, .pop_join_error_box_2').hide();

							if(home_style == 2) {
								$('#error_box_5_2').stop().fadeIn(1).delay(3000).fadeOut(500);
								$('#email_j_focus_2').val('').focus();
							} else {
								$('#error_box_5').stop().fadeIn(1).delay(3000).fadeOut(500);
								$('#email_j_focus').val('').focus();
							}

						} else {

							$.post('inc/login.php', { email: email, password: password }, function(data) {
					
								update_header(1,data['logged'],data['profile']);
								$('#_logged').val(1);
								$('#_loggedid').val(data['id']);
								load_settings_box();
								load_live_page('feed');

							}, 'json');

						}

					});

				}

			}

		}
				
	});
