
	$(document).on('click', '.photo_ratings_rate', function() {

		var g_id = $(this).attr('id');
		var id = g_id.replace('rate_','');
	
		var pid = $('.pop').attr('id');

		$.post('inc/rate.php', { id: id, pid: pid }, function(get) {

			$('.photo_ratings').hide();

			if(get != 2) {

				var gets = get.split('|');
				$('.photo_stats_votes_count').text(gets[1]);
				$('.photo_stats_score_count').text(gets[0]);

				$('.photo_rate_message_success').stop().fadeIn(1).delay(3000).fadeOut(150);

			}

		});


	});

	$(document).on('click', '.like_button', function() {

		if($('#_logged').val() == 0) {
			$('#login_but').click();
		} else {

			if(rating_system == 1) {

				var pid = $('.pop').attr('id');
				var status = $(this).data('status');
				var current_count = $('.photo_stats_votes_count').text();
	
				if(status == 1) {
					current_count++;
					$('.like_button').text(lang['unlike_button']).data('status','0');
				} else {
					current_count--;
					$('.like_button').text(lang['like_button']).data('status','1');
				}

				$('.photo_stats_votes_count').text(current_count);

				$.post('inc/like.php', { pid: pid, status: status });

			}

		}

	});


	$('#rate_10').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
		$('#rate_2').addClass('photo_ratings_hover_rate');
		$('#rate_3').addClass('photo_ratings_hover_rate');
		$('#rate_4').addClass('photo_ratings_hover_rate');
		$('#rate_5').addClass('photo_ratings_hover_rate');
		$('#rate_6').addClass('photo_ratings_hover_rate');
		$('#rate_7').addClass('photo_ratings_hover_rate');
		$('#rate_8').addClass('photo_ratings_hover_rate');
		$('#rate_9').addClass('photo_ratings_hover_rate');
		$('#rate_10').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
		$('#rate_2').removeClass('photo_ratings_hover_rate');
		$('#rate_3').removeClass('photo_ratings_hover_rate');
		$('#rate_4').removeClass('photo_ratings_hover_rate');
		$('#rate_5').removeClass('photo_ratings_hover_rate');
		$('#rate_6').removeClass('photo_ratings_hover_rate');	
		$('#rate_7').removeClass('photo_ratings_hover_rate');
		$('#rate_8').removeClass('photo_ratings_hover_rate');
		$('#rate_9').removeClass('photo_ratings_hover_rate');
		$('#rate_10').removeClass('photo_ratings_hover_rate');
	});

	$('#rate_9').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
		$('#rate_2').addClass('photo_ratings_hover_rate');
		$('#rate_3').addClass('photo_ratings_hover_rate');
		$('#rate_4').addClass('photo_ratings_hover_rate');
		$('#rate_5').addClass('photo_ratings_hover_rate');
		$('#rate_6').addClass('photo_ratings_hover_rate');
		$('#rate_7').addClass('photo_ratings_hover_rate');
		$('#rate_8').addClass('photo_ratings_hover_rate');
		$('#rate_9').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
		$('#rate_2').removeClass('photo_ratings_hover_rate');
		$('#rate_3').removeClass('photo_ratings_hover_rate');
		$('#rate_4').removeClass('photo_ratings_hover_rate');
		$('#rate_5').removeClass('photo_ratings_hover_rate');
		$('#rate_6').removeClass('photo_ratings_hover_rate');	
		$('#rate_7').removeClass('photo_ratings_hover_rate');
		$('#rate_8').removeClass('photo_ratings_hover_rate');
		$('#rate_9').removeClass('photo_ratings_hover_rate');
	});

	$('#rate_8').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
		$('#rate_2').addClass('photo_ratings_hover_rate');
		$('#rate_3').addClass('photo_ratings_hover_rate');
		$('#rate_4').addClass('photo_ratings_hover_rate');
		$('#rate_5').addClass('photo_ratings_hover_rate');
		$('#rate_6').addClass('photo_ratings_hover_rate');
		$('#rate_7').addClass('photo_ratings_hover_rate');
		$('#rate_8').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
		$('#rate_2').removeClass('photo_ratings_hover_rate');
		$('#rate_3').removeClass('photo_ratings_hover_rate');
		$('#rate_4').removeClass('photo_ratings_hover_rate');
		$('#rate_5').removeClass('photo_ratings_hover_rate');
		$('#rate_6').removeClass('photo_ratings_hover_rate');	
		$('#rate_7').removeClass('photo_ratings_hover_rate');
		$('#rate_8').removeClass('photo_ratings_hover_rate');
	});

	$('#rate_7').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
		$('#rate_2').addClass('photo_ratings_hover_rate');
		$('#rate_3').addClass('photo_ratings_hover_rate');
		$('#rate_4').addClass('photo_ratings_hover_rate');
		$('#rate_5').addClass('photo_ratings_hover_rate');
		$('#rate_6').addClass('photo_ratings_hover_rate');
		$('#rate_7').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
		$('#rate_2').removeClass('photo_ratings_hover_rate');
		$('#rate_3').removeClass('photo_ratings_hover_rate');
		$('#rate_4').removeClass('photo_ratings_hover_rate');
		$('#rate_5').removeClass('photo_ratings_hover_rate');
		$('#rate_6').removeClass('photo_ratings_hover_rate');	
		$('#rate_7').removeClass('photo_ratings_hover_rate');
	});

	$('#rate_6').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
		$('#rate_2').addClass('photo_ratings_hover_rate');
		$('#rate_3').addClass('photo_ratings_hover_rate');
		$('#rate_4').addClass('photo_ratings_hover_rate');
		$('#rate_5').addClass('photo_ratings_hover_rate');
		$('#rate_6').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
		$('#rate_2').removeClass('photo_ratings_hover_rate');
		$('#rate_3').removeClass('photo_ratings_hover_rate');
		$('#rate_4').removeClass('photo_ratings_hover_rate');
		$('#rate_5').removeClass('photo_ratings_hover_rate');
		$('#rate_6').removeClass('photo_ratings_hover_rate');
	});

	$('#rate_5').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
		$('#rate_2').addClass('photo_ratings_hover_rate');
		$('#rate_3').addClass('photo_ratings_hover_rate');
		$('#rate_4').addClass('photo_ratings_hover_rate');
		$('#rate_5').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
		$('#rate_2').removeClass('photo_ratings_hover_rate');
		$('#rate_3').removeClass('photo_ratings_hover_rate');
		$('#rate_4').removeClass('photo_ratings_hover_rate');
		$('#rate_5').removeClass('photo_ratings_hover_rate');
	});

	$('#rate_4').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
		$('#rate_2').addClass('photo_ratings_hover_rate');
		$('#rate_3').addClass('photo_ratings_hover_rate');
		$('#rate_4').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
		$('#rate_2').removeClass('photo_ratings_hover_rate');
		$('#rate_3').removeClass('photo_ratings_hover_rate');
		$('#rate_4').removeClass('photo_ratings_hover_rate');
	});

	$('#rate_3').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
		$('#rate_2').addClass('photo_ratings_hover_rate');
		$('#rate_3').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
		$('#rate_2').removeClass('photo_ratings_hover_rate');
		$('#rate_3').removeClass('photo_ratings_hover_rate');
	});


	$('#rate_2').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
		$('#rate_2').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
		$('#rate_2').removeClass('photo_ratings_hover_rate');
	});

	$('#rate_1').hover(function() {
		$('#rate_1').addClass('photo_ratings_hover_rate');
	}, function() {
		$('#rate_1').removeClass('photo_ratings_hover_rate');
	});		
