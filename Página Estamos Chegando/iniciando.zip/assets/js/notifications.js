
	function get_notifications() {

		$.post('inc/notifications.php', function(get) {

			var old_unread = $('.chat_notifications').text();
			var old_unseen = $('.activity_notifications').text();
			
			if(get.unread > 0) {

				if(get.unread > old_unread) {
					if($('.messages').is(':visible')) {
						get_messages('2');
					}
				}

				$('.chat_notifications').show().text(get.unread);
			} else {
				$('.chat_notifications').hide().text('');
			}

			if(get.unseen > 0) {

				if(get.unseen > old_unseen) {
					if($('.activity_tab').is(':visible')) {
						get_activity('2');
					}
				}

				$('.activity_notifications').show().text(get.unseen);
			} else {
				$('.activity_notifications').hide().text('');
			}

		}, 'json');

	}

	if($('#_logged').val() == 1) {

		get_notifications();
		
		setInterval(function () {
			get_notifications();
		}, 5000);

	}