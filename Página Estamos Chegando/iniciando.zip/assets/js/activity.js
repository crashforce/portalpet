
	var not_limit = 15;

	function get_activity(type,page) {

		if(typeof page != 'undefined') {
			var page = 0;
		} else {

			if(page < 1) {
				var page = 0;
			}

		}

		if(type == 3) {
			var last = $('.activity_results .activity_result:last').attr('id');
			var id = last.replace('activity_','');
		} else {
			var id = '9999999999999999';
		}

		if(type == 1) {
			$('.activity_results').append('<div class="activity_loading"></div>');
		}

		$.post('inc/load_activity_tab.php', { page: id }, function(get) {

			$('#act_count').text('('+get.count+')');

			var data = 'data';

			if(typeof get[data] != 'undefined' && get[data].length > 0) {

				$('.activity_results .activity_no_results').remove();

				not_limit = get[data].length;

				for(i=0;i<=get[data].length-1;i++) {

					if(!$('.activity_results #activity_'+get[data][i].id)[0]) {

						if(get[data][i].type == 1) {
							var pag = 'data-page="'+get[data][i].content_id+'" data-type="1"';
						}
			
						if(get[data][i].type == 2) {
							var pag = 'data-page="'+get[data][i].content_id+'" data-type="2"';
						}

						if(get[data][i].type == 3) {
							var pag = 'data-page="'+get[data][i].profile+'" data-type="3"';
						}

						if(get[data][i].type == 4) {
							var pag = 'data-page="'+get[data][i].profile+'" data-type="4"';
						}

						if(get[data][i].type == 5) {
							var pag = 'data-page="'+get[data][i].content_id+'" data-type="5"';
						}

						if(get[data][i].type == 6) {
							var pag = 'data-page="'+get[data][i].content_id+'" data-type="6"';
						}

						if(get[data][i].type == 7) {
							var pag = 'data-page="'+get[data][i].content_id+'" data-type="7"';
						}

						var types = get[data][i].types;
						var contents = get[data][i].contents;

						if(type == 2) {
							$('.activity_results').prepend('<div class="activity_result '+get[data][i].unseen+'" '+pag+' id="activity_'+get[data][i].id+'"><div class="activity_result_pic"><img src="'+get[data][i].pic+'" /></div><div class="activity_result_details"><div class="activity_result_details_name">'+types+'</div><div class="activity_result_details_date">'+get[data][i].date+'</div><div class="activity_result_message">'+contents+'</div></div></div>');
						} else {
							$('.activity_results').append('<div class="activity_result '+get[data][i].unseen+'" '+pag+' id="activity_'+get[data][i].id+'"><div class="activity_result_pic"><img src="'+get[data][i].pic+'" /></div><div class="activity_result_details"><div class="activity_result_details_name">'+types+'</div><div class="activity_result_details_date">'+get[data][i].date+'</div><div class="activity_result_message">'+contents+'</div></div></div>');
						}

					}

				}

			} else {

				if(type == 1) {
					$('.activity_results').append('<div class="activity_no_results">'+lang['activity_no_results']+'</div>');
				}

			}

			$('.activity_results .activity_loading').remove();
			$('.activity_box').perfectScrollbar('destroy');
			$('.activity_box').perfectScrollbar();
			$('.activity_box').perfectScrollbar('update');

		}, 'json');

	}

	$(document).on('click','.activitytab, .activity_notifications', function(e) {

		$('.activity_tab').show();
		$('.round_activity').addClass('menu_active');

		$('.activity_box').scrollTop(0);
		$('.activity_results').html('');

		if(!$('.activity_results .activity_loading')[0]) {

			get_activity('1','0');

		}

	});

	$(document).on('click','.activity_result', function() {

		var type = $(this).data('type');
		var page = $(this).data('page');

		if(type == 1 || type == 2 || type == 6 || type == 7) {

			$('.auto').remove();
			$('body').append('<div class="auto" data-id="'+page+'"></div>');
			$('.auto').click();

		} else {

			window.location.href = page;

		}			

	});

       	$('.activity_box').on('mousewheel', function() {
		
		var position = $('.activity_box .activity_result:last').position().top;

		if(position < 400 && not_limit == 15) {
			
			if(!$('.activity_results .activity_loading')[0]) {

				get_activity('3');

			}

		}

	});

	$(document).on('click', function(e) {

		var target = e.target;

		if(!$(target).hasClass('round_activity') && !$(target).hasClass('activity_notifications')) {

			$('.activity_results').html('');
			$('.activity_tab').hide();
			$('.round_activity').removeClass('menu_active');

		}

	});
