
	$(document).on('click', function(e) {

		var target = e.target;

		if(!$(target).hasClass('round_search') && !$(target).hasClass('search') && !$(target).hasClass('search_results') && !$(target).is('#search')) {

			$('.search_results').html('');
			$('.search_results').hide();
			$('.search_icon2').css('background','url(assets/img/search_icon2.png) no-repeat center center');
			if(mobile == 0) { $('.searchs').hide(); }
			$('.round_search').removeClass('menu_active').removeClass('search_expand');

			if(custom_bar_style == 1 && video_system == 1) {
				$('#select_upload').css('right','0');
			} else {
				if(video_system == 1) {
					$('#select_photo, #select_video').css('margin-left','0');
				} else {
					$('#select_photo').css('margin-left','0');
				}
			}

			$('#search').fadeOut(200);
			$('#search').css('margin-left','300px');

		}

	});

	$(document).on('click','.searching', function(e) {

		if($('.round_search').hasClass('search_expand')) {

			$('.search_results').html('');
			$('.search_results').hide();
			$('.search_icon2').css('background','url(assets/img/search_icon2.png) no-repeat center center');
			if(mobile == 0) { $('.searchs').hide(); }
			$('.round_search').removeClass('menu_active').removeClass('search_expand');
			
			if(custom_bar_style == 1 && video_system == 1) {
				$('#select_upload').css('right','0');
			} else {
				if(video_system == 1) {
					$('#select_photo, #select_video').css('margin-left','0');
				} else {
					$('#select_photo').css('margin-left','0');
				}
			}

			$('#search').fadeOut(200);
			$('#search').css('margin-left','300px');

		} else {

			$('.search_icon2').css('background','url(assets/img/search_icon_h.png) no-repeat center center #fff');
			$('.search').show();
			$('#search').show().val('').focus();
			$('.search_results').html('');
			$('.round_search').addClass('menu_active').addClass('search_expand');
			
			if(custom_bar_style == 1 && video_system == 1) {
				$('#select_upload').css('right','325px');
			} else {
				if(video_system == 1) {
					$('#select_photo').css('margin-left','-375px');
					$('#select_video').css('margin-left','-425px');
				} else {
					$('#select_photo').css('margin-left','-375px');
				}
			}

			$('#search').css('margin-left','0');

		}

	});

	function search_call(tag) {

		var test_tag = tag.replace(/ /g,'');

		if($('#sleep').val()!=1 && test_tag.length > 0) {

			if(mobile == 0) { $('#search').addClass('searchin'); }

			if(!$('.search_results .search_loading')[0]) {
				$('.search_results').append('<div class="search_loading">Loading</div>');
			}

			if(mobile == 1) {		

				$('.search_closed').hide();
				$('.search_open').show();

			}

			$('#sleep').stop().val('1');

			$.post('inc/search.php', { tag: tag }, function(get) {

				$('.search_results .search_loading').remove();

				var tag = $('#search').val();
				
				if(get.length == 0) {
	
					setTimeout(function(){
						$('.search_results').stop().html('<div class="header_search_no_results">'+lang['header_search_no_results']+'</div>');
					}, 700);
		
				}
	
				for(i=0;i<=get.length-1;i++) {

					if(!$('#_search_'+get[i].id)[0]) {

						var verified_class = '<div class="search_result_verified">'+get[i].verified+'</div>';
					
						if(get[i].search_type == 1) {
							$('.search_results').stop().append('<div class="search_result call_live_photo" id="_search_'+get[i].id+'" data-url="'+get[i].username+'"><div class="search_result_preview"><img src="'+get[i].pic+'" /></div><div class="search_result_name">'+get[i].name+'</div>'+verified_class+'</div>');
						} else {
							$('.search_results').stop().append('<div class="search_result call_live_profile" id="_search_'+get[i].id+'" data-profileuser="'+get[i].username+'"><div class="search_result_preview"><img src="'+get[i].pic+'" /></div><div class="search_result_name">'+get[i].name+'</div>'+verified_class+'</div>');
						}
				
					}

					$('.search_results .header_search_no_results').remove();

				}

				$('#sleep').val('0');

				if(mobile == 0) {
					setTimeout(function(){
						$('#search').removeClass('searchin');
						$('.search_results').show();
					}, 700);
				}

			}, 'json');

		}

	}

	$('#search').bind('keyup input paste', function() {

		$('.search_results').stop().hide().html('');

		var tag = $('#search').val();
		search_call(tag);

	});

	$(document).on('click', '.search_erase', function() {

		$('.search_results').stop().html('');
		$('.search_open').hide();
		$('.search_closed').show();
		$('#search').val('');

	});
