
	$(document).on('click', '#select_photo', function() {

		if(mobile == 1 && mobile_supported == 0) {
			alert('Your device is not supported for uploading');
		}

		if(mobile == 0) { 
			$('.pop_upload').css('height','152px');
			$('body').css('overflow','hidden');
		}

		$('.pop').show();
		$('.pop_upload').show();
		$('.pop_upload_details_2, .pop_upload_details_3').hide();
		$('.pop_upload_details_1').show();
		$('#upload_url').val('');

		if(mobile == 1) { $('.main').hide(); }


	});

	$(document).on('click', '.upload_details_1_1', function() {

		$('#new_photo').click();

	});

	$(document).on('click', '.upload_details_1_2', function() {

		if(mobile == 0) { 
			var form_height_2 = $('.upload_url').length;
			var form_height = (44 * form_height_2) + 116;
			$('.pop_upload').css('height',form_height+'px');
		}

		$('.pop_upload_details_1, .pop_upload_details_2, .pop_upload_details_3').stop().hide();
		$('.pop_upload_details_4').stop().show();

	});

	$(document).on('click', '.upload_more', function() {

		var total_more = $('.upload_url').length;
		if(total_more < 5) {
			$('.upload_url_list').append('<div class="upload_url"><textarea name="url_upload" class="upload_url_text" placeholder="'+lang['upload_photo_input']+'"></textarea></div>');
			if(total_more == 4) {
				$('.upload_more').hide();
			}
		}

		if(mobile == 0) { 
			var form_height_2 = $('.upload_url').length;
			var form_height = (44 * form_height_2) + 116;
			$('.pop_upload').css('height',form_height+'px');
		}

	});

	var upload_progress = Math.floor((Math.random() * 30) + 1);

	$('#new_photo').on("change", function(){

		if(mobile == 0) { 
			$('.pop_upload').stop().css('height','202px');
		}
		$('.pop_upload_details_1, .pop_upload_details_2').stop().hide();
		$('.pop_upload_details_3').stop().show().text(lang['uploading']+' 0%');

		if($('#_logged').val() == 1) {

			lang['uploading'] = lang['uploading'];

			if($("#new_photo")[0].files.length > files_limit) {

				lang['upload_files_limit'] = lang['upload_limit'];
				var upload_limit_lang = lang['upload_files_limit'].replace('%limit%',files_limit);
				$('#new_photo').val('');

			} else {

				$('.pop_upload_details_3').stop().show().text(lang['uploading']+' 0%');

				$("#upload_photo").ajaxForm({
				
					clearForm: true,
        				resetForm: true,
					uploadProgress: function(event, position, total, percentComplete) {
						if(percentComplete == 100) { percentComplete = '99'; }
            					$('.pop_upload_details_3').text(lang['uploading']+' '+percentComplete+'%');
            				},
					dataType: 'json',
					success: function(get) {
		
						$('.uploaded_list').html('');

						if(get['files'].length > 0) {

							for(i=0;i<=(get['files'].length)-1;i++) {
								$('.uploaded_list').append('<div class="uploaded_item" id="upload_'+get['files'][i]+'"><div class="uploaded_item_left"><img src="'+site_url+'/thumbs.php?src=uploads/photos/'+get['files'][i]+'_2.jpg&w=80&h=60&zc=1" /></div><div class="uploaded_item_right"><textarea name="description" class="pop_upload_description" placeholder="'+lang['pop_upload_description']+'"></textarea></div></div>');
							}
					
							if(mobile == 0) {
								var form_height_2 = get['files'].length;
								var form_height = (80 * form_height_2) + 116;
								$('.pop_upload').css('height',form_height+'px');
							}

							$('.pop_upload_details_1, .pop_upload_details_3').hide();
							$('.pop_upload_details_2').show();
							$('#pop_upload_photo').val(get['files'][0]);

						} else {

							close_pops();
							$('body').css('overflow','auto');

							$('#erro_14').stop().fadeIn(1).delay(2000).fadeOut(1);

						}

					}

				}).submit();

			}

		}

	});

	$(document).on('click', '.pop_upload_cancel', function() {
			
		$('.pop').hide();
		$('.pop_upload').hide();
		$('body').css('overflow','auto');
		$('#pop_upload_description').val('');

		if(mobile == 1 && $('#_main_now').val() != 'home') { $('.main').show(); }

	});

	$(document).on('click', '.pop_upload_saves', function() {

		var selected_photos_url = new Array();

		$('.upload_url_list .upload_url').each(function() {

			selected_photos_url[selected_photos_url.length] = $(this).find('textarea').val();

		});

		if(mobile == 0) {
			$('.pop_upload').stop().css('height','202px');
		}

		$('.pop_upload_details_1, .pop_upload_details_2, .pop_upload_details_4').stop().hide();
		$('.pop_upload_details_3').stop().show().text(lang['uploading']+' 0%');

		$.post('inc/upload_photo.php', { upload_urls: selected_photos_url }, function(get) {

			$('.uploaded_list').html('');

			if(get.error == 1) {
				close_pops();
				$('body').css('overflow','auto');
				$('#erro_14').stop().fadeIn(1).delay(2000).fadeOut(1);
			} else {

				if(get['files'].length > 0) {

					for(i=0;i<=(get['files'].length)-1;i++) {
						$('.uploaded_list').append('<div class="uploaded_item" id="upload_'+get['files'][i]+'"><div class="uploaded_item_left"><img src="'+site_url+'/thumbs.php?src=uploads/photos/'+get['files'][i]+'_2.jpg&w=80&h=60&zc=1" /></div><div class="uploaded_item_right"><textarea name="description" class="pop_upload_description" placeholder="'+lang['pop_upload_description']+'"></textarea></div></div>');
					}
					
					if(mobile == 0) {
						var form_height_2 = get['files'].length;
						var form_height = (80 * form_height_2) + 116;
						$('.pop_upload').css('height',form_height+'px');
					}

					$('.pop_upload_details_1, .pop_upload_details_3, .pop_upload_details_4').hide();
					$('.pop_upload_details_2').show();
					$('#pop_upload_photo').val(get['files'][0]);

				}

			}

	
		}, 'json');

	});

	$(document).on('click', '.pop_upload_save', function() {
		
		var selected_photos_id = new Array();
		var selected_photos_desc = new Array();

		$('.uploaded_list .uploaded_item').each(function() {

			var file_id_2 = $(this).attr('id');
			var file_id = file_id_2.replace('upload_','');

			selected_photos_id[selected_photos_id.length] = file_id;
			selected_photos_desc[selected_photos_desc.length] = $(this).find('textarea').val();

		});

		$.post('inc/uploader.php', { photo: selected_photos_id, desc: selected_photos_desc }, function(get) {

			if(get['error'] == 0) {

				var id = get['files'][0].id;

				for(i=0;i<=(get['files'].length)-1;i++) {

					if($('#_loggedid').val() == $('#_current_id').val()) {
						var logged_data = '<div class="user_photo_item_options" data-jid="'+get['files'][i].url+'" data-type="'+get['files'][i].type+'"><div class="user_photo_item_options_menu"><div class="user_photo_item_options_delete" id="del_'+get['files'][i].url+'" data-type="0">'+lang['user_remove_photo']+'</div><div class="user_photo_item_options_edit" id="edit_'+get.url+'" data-type="0">'+lang['user_edit_photo']+'</div></div></div><div class="photo_large" data-id="'+get['files'][i].url+'"></div>';
					} else {
						var logged_data = '<div class="photo_large larger" data-id="'+get['files'][i].url+'"></div>';
					}

					if($('#_loggedid').val() == $('#_current_id').val()) {

						$('.user_photos .user_no_results').hide();
	
						if(rating_system != 1) {
							var rate_col = '<div class="user_photos_item_stats_views user_rate_1_col">0</div><div class="user_photos_item_stats_votes user_rate_1_col">0</div><div class="user_photos_item_stats_rating user_rate_1_col">0</div><div class="user_photos_item_stats_comments user_rate_1_col">0</div>';
						} else {
							var rate_col = '<div class="user_photos_item_stats_views user_rate_2_col">0</div><div class="user_photos_item_stats_votes user_rate_2_col">0</div><div class="user_photos_item_stats_comments user_rate_2_col">0</div>';
						}

						var results = '<div class="user_photos_item" data-id="'+get['files'][i].url+'" id="_'+get['files'][i].url+'" style="background:url('+get['files'][i].photo+') no-repeat center center">'+logged_data+'<div class="user_photos_item_black">'+get['files'][i].time+'</div><div class="user_photos_item_stats">'+rate_col+'</div></div>';
						if($('.user_photos')[0]) {
							$('.user_photos').prepend(results);
						}

						var first_one = $('.user_photos .user_photo_item:first');
				
						$(first_one).hide();
						$(first_one).fadeIn(1000);

						var pnr = $('#pnr').text();
						pnr++;
						$('#pnr').text(pnr);
					
					}

				}

				$('#succ_5').stop().fadeIn(1).delay(2000).fadeToggle(500);

				$('.pop').hide();
				$('.pop_upload').hide();
				$('body').css('overflow','auto');
				if(mobile == 1 && $('#_main_now').val() != 'home') { $('.main').show(); }

			} else {

				$('#erro_8').stop().fadeIn(1).delay(2000).fadeOut(500);

				$('.pop').hide();
				$('.pop_upload').hide();
				$('body').css('overflow','auto');
				$('#pop_upload_description').val('');
				if(mobile == 1 && $('#_main_now').val() != 'home') { $('.main').show(); }

			}

		}, 'json');

	});

    	$('#pop_upload_description').bind('keyup input paste', function() {

        	var limit = 200;  
        	var text = $(this).val();  
        	var chars = text.length;  
  
        	if(chars > limit){  
            		var new_text = text.substr(0, limit);   
            		$(this).val(new_text);  
        	}  

    	});  
