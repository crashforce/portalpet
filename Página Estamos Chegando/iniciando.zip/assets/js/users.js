
	$(document).on('click', '.users_box_name', function() {

		if(mobile == 1) {

			var page = $(this).attr('data-page');

			$('.users_box_name').removeClass('user_box_name_selected');
			$(this).addClass('user_box_name_selected');

			if(page == 'users') {
				$('.box_users').show();
				$('.box_filters').hide();
			}

			if(page == 'filters') {
				$('.box_filters').show();
				$('.box_users').hide();
			}

			$('.users_scroll').stop().animate({left: $(this).position().left, width: $(this).width()+22},'100');
			$('.users_scroll').width($(this).width()+22).data('curl', $('.users_scroll').position().left).data('curw', $('.users_scroll').width());

		}

	});

	$(document).on('click', '#search_enter', function() {

		$('.users').html('');
		$('.filters_box').css({ 'opacity': '0.7', 'pointer-events':'none' });
		var page = $('#users_page').text('0');
	
		load_users('0','1');

	});

	$(document).on('click', '.users_search_box_x', function() {

		$('.users_search').val('');

		$('.users').html('');
		$('.filters_box').css({ 'opacity': '0.7', 'pointer-events':'none' });
		var page = $('#users_page').text('0');
	
		load_users('0','1');

		$('.users_search').focus();

	});

	$(document).on('click', '.filters_list_filter', function() {

		var type_click = $(this).attr('id');
		var type = type_click.split('_');

		var filter = type[1];
		var value = type[2];

		var filter_1 = $('#_filter_1').val();
		var filter_2 = $('#_filter_2').val();

		if(filter == 1) { var the_val = filter_1; } else { var the_val = filter_2; }

		if(filter == 1 && filter_1 != value) {

			$('#filter_1_'+filter_1).find('.filters_list_checkbox_selected').removeClass('filters_list_selcheck');
			$('#filter_1_'+filter_1).find('.filters_list_check_name').removeClass('filters_list_name_sel');

			$(this).find('.filters_list_checkbox_selected').addClass('filters_list_selcheck');
			$(this).find('.filters_list_check_name').addClass('filters_list_name_sel');

			$('#_filter_1').val(value);

		}

		if(filter == 2 && filter_2 != value) {

			$('#filter_2_'+filter_2).find('.filters_list_checkbox_selected').removeClass('filters_list_selcheck');
			$('#filter_2_'+filter_2).find('.filters_list_check_name').removeClass('filters_list_name_sel');

			$(this).find('.filters_list_checkbox_selected').addClass('filters_list_selcheck');
			$(this).find('.filters_list_check_name').addClass('filters_list_name_sel');

			$('#_filter_2').val(value);

		}

		$('.users').html('');
		$('.filters_box').css({ 'opacity': '0.7', 'pointer-events':'none' });
		var page = $('#users_page').text('0');
	
		load_users('0','1');

		if(mobile == 1) {
			$('.user_box_users').click();
		}

	});

	$(document).on('click','.users_reload', function() {

		$("body").append($("<div><dt/><dd/></div>").attr("id", "progress"));
		$("#progress").width((50 + Math.random() * 30) + "%");

		$('.users').html('');
		$('.filters_box').css({ 'opacity': '0.7', 'pointer-events':'none' });
		var page = $('#users_page').text('0');
	
		load_users('0','1');

	});

	function load_users(time,type) {

		reload_footer();

		$('.users_loading').show();

		var tag = $('.users_search').val();
		var gender = $('#_filter_1').val();
		var sortby = $('#_filter_2').val();

		var logs_id = $('#logged_id').text();

		$.post('inc/load_users.php', { page: time, gender: gender, sortby: sortby, tag: tag }, function(json) {

			var list = 'list';
			var count = 'count';

			users_limit = json[list].length;

			$('#users_count').text(json[count]);

			if(json[list].length == 0) {

				$('.users_loading').hide();
				if(type == 1 || type == 3) { $('.no_users').show(); }
				if(type == 2) { $('.no_users').hide(); }

			} else {

				for(tid=0;tid<=(json[list].length)-1;tid++) {
					if(json["list"][tid].id != '') {
						if(!$('#fol_'+json[list][tid].id)[0]) {

							if(logs_id != json[list][tid].id) {
								var follow_button = '<div class="'+json[list][tid].follow_2+' unselect" data-uid="'+json[list][tid].id+'"><div class="follows_count">'+json[list][tid].follows_count+'</div><div class="follows_op">'+ucwords(json[list][tid].follow)+'</div></div>';
							} else {
								var follow_button = '';
							}
									
							var result_data1 = $('<div class="users_result" id="fol_'+json[list][tid].id+'"><div class="users_result_pic"><img src="'+json[list][tid].pic+'" class="img_load_'+json[list][tid].id+' call_live_profile" data-profileuser="'+json[list][tid].profileuser+'" /></div><div class="users_result_cover" '+json[list][tid].background_cover+'>'+follow_button+'</div><div class="users_result_name call_live_profile" data-profileuser="'+json[list][tid].profileuser+'"><div class="users_results_col_1">'+json[list][tid].name+'</div><div class="users_result_verified">'+json[list][tid].verified+'</div></div></div>');
							$('.users').append(result_data1);

						}
					}
				}

				$('.no_users').hide();
				$('#scrolling').text('0');

			}

			$('.users_loading').hide();
			$('.filters_box').css({ 'opacity': '1', 'background':'#fff', 'pointer-events':'auto' });

			
			if($('.pop').is(':hidden')) {
				$('body').css('overflow','auto');
			}

			reload_footer();

		}, 'json');

	}

       	function onScroll(event) {

		if($('#_main_now').val() == 'users') { 

          		var winHeight = window.innerHeight ? window.innerHeight : $(window).height();

			if(mobile == 0) {
				var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
			} else {
				var closeToBottom = ($(window).scrollTop() >= $(document).height() - $(window).height() - 60);
			}
        				
			if (closeToBottom && users_limit == 27) {

				var checking = $('#scrolling').text();

				if(checking != 1) {

					$('#scrolling').text('1');

					var time = $('#users_page').text();
					time++;
					var new_time = time;

					$('#users_page').text(new_time);

					load_users(new_time,'2');

				}
			}

		}

      	};

	$(window).bind('scroll', onScroll);
