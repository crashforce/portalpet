
	function show_pop(pop,id,email) {

		if(mobile == 1) {
			close_mobile_menu();
		}
		if(mobile == 0) { $('body').css('overflow','hidden'); }
		if(mobile == 1) { $('.footer_home').hide(); }
		$('.photo_nav_left, .photo_nav_right').hide();
		$('.pop_login').hide();
		$('.pop_join').hide();
		$('.pop_photo').hide();
		$('.pop_chat').hide();
		$('.pop_upload').hide();
		$('.pop_upload_video').hide();
		$('.pop_edit').hide();
		$('.pop_lostpw').hide();
		$('.pop_contact').hide();
		$('.pop_verify').hide();
	
		if(mobile == 1) {
			$('.site').hide();
			$('.footer').hide();
		}

		$('.pop').show();

		if(pop == 'login') {

			$('.pop_login').stop().fadeIn(500);

			if(id == 1) {
				$('#email_focus').val(email);
				if(mobile == 0) { $('#password_focus').focus(); }
				$('.pop_login_success_box').stop().fadeIn(1).delay(4000).fadeOut(1);
			} else {
				if(mobile == 0) { $('#email_focus').focus(); }
			}

		}

		if(pop == 'messages') {
			$('.pop_messages').fadeIn(500);
		}

		if(pop == 'lostpw') {
			$('.pop_lostpw').fadeIn(500);
			if(mobile == 0) { $('#lostpw_email_focus').focus(); }
		}

		if(pop == 'contact') {
			$('.pop_contact').fadeIn(500);
			if(mobile == 0) { $('#contact_email_focus').focus(); }
		}

		if(pop == 'join') {
			$('.pop_join').fadeIn(500);
			if(mobile == 0) { $('#name_focus').focus(); }
		}

		if(pop == 'photo') {
			$('.pop_photo').fadeIn(1);
			$('.close_photo').show();
		}

		if(pop == 'chat') {
			$('.pop_chat').fadeIn(1);
			if(mobile == 1) {
				var window_h = parseInt($(window).height()) - 102;
				$('#conversation').css('height',window_h+'px');
			}
		}

		if(mobile == 1) { $('.pop').scrollTop(0); }
		
	}

	$(document).on('click', '.unverified_user', function() {

		show_pop('verify','x');
		$('body').css('overflow','hidden');
		$('.pop, .pop_verify').show();

	});

	$(document).on('click', '.swipe_6', function() {

		close_pops();

		show_pop('messages','x');
		$('.pop, .pop_messages, .messages').show();
		get_messages('1');

	});

	$(document).on('click', '.auto, .loaderg, .call_live_photo, .home_photo_item, .home_photo_item2, .play_icon, .browse_img, .hashtags_img, .photo_nav_left, .photo_nav_right, .feed_img, .photo_large, .user_it_img, .home_pic', function() {
		
		var y_id = $(this).attr('id');

		if($(this).hasClass('call_live_photo')) {
			var id = $(this).data('url');
		}

		if($(this).hasClass('home_photo_item') || $(this).hasClass('home_photo_item2')) {
			var id = $(this).data('id');
		}

		if($(this).hasClass('photo_large')) {
			var id = $(this).data('id');
		}

		if($(this).hasClass('play_icon')) {
			var id = $(this).data('id');
		}

		if($(this).hasClass('home_pic')) {
			var id = $(this).data('id');
		}

		if($(this).hasClass('auto')) {
			var id = $('.auto').data('id');
		}

		if($(this).hasClass('photo_nav_left') || $(this).hasClass('photo_nav_right')) {
			var id = y_id.replace('n_','');
		}
		
		if($(this).hasClass('feed_img')) {
			var id = y_id.replace('feed_img_','');
		}

		if($(this).hasClass('hashtags_img')) {
			var id = y_id.replace('hashtags_img_','');
		}

		if($(this).hasClass('browse_img')) {
			var id = y_id.replace('browse_img_','');
		}

		if($(this).hasClass('loaderg')) {
			var id = y_id.replace('k_','');
		}
	
		if($(this).hasClass('user_it_img')) {
			var id = $(this).data('ids');
		}

		var pop_type = $(this).data('type');

		var go_forw = 1;

		if(mobile == 1 && !$(this).hasClass('home_photo_item')) {
			var go_forw = 1;
		}

		if(mobile == 1 && $(this).hasClass('home_photo_item')) {
			var go_forw = 0;
		}

		if(go_forw == 1) {

			clearInterval(live_comments);
			live_comments = null;

			$('#comments').perfectScrollbar('destroy');

			if(!$(this).hasClass('photo_nav_left') && !$(this).hasClass('photo_nav_right')) {
				show_pop('photo',pop_type);
			}

			load_photo(id);

		}

	});

	$(document).on('click', '.message, .messages_result', function() {

		if(!$(this).hasClass('privacy')) {

			if($(this).hasClass('messages_result')) {
		
				var id = $(this).attr('id');
				var the_id = id.replace('_msg_','');

			} else {

				var id = $(this).attr('id');
				var the_id = id.replace('chat_','');

			}

			if($('#_logged').val() == 0) {
				$('#login_but').click();
			} else {

				$('#chat_to').val(the_id);

				show_pop('chat','x');

				$('.messages_results').html('');
				$('.messages').hide();
				$('.round_chat').removeClass('menu_active');

			}

		} else {

			$('#erro_12').stop().fadeIn(1).delay(2000).fadeOut(1);

		}
		
	});

	$(document).on('click','.hit_contact', function() {

		window.history.pushState("","contact","/contact");
		show_pop('contact','x');

	});

	$(document).on('click','#login_but', function() {

		window.history.pushState("","Login","/login");
		show_pop('login','x');

	});

	$(document).on('click','#join_but', function() {

		window.history.pushState("", "Join", '/join');
		show_pop('join','x');

	});

	$(document).on('click','.pop_login_recover, .home_2_login_recover', function() {

		window.history.pushState("", "", '/lost-password');
		show_pop('lostpw','x');

	});
	
	function close_pops() {

		if(mobile == 1 && $('#_main_now').val() != 'home') { $('.main').show(); }		
		if(mobile == 1) { $('.pop_messages').hide(); }

		window.history.pushState("", "", '/'+temp_page);

		if(mobile == 1) { $('.footer_home').show(); }
		$('.photo_display iframe').remove();

		$('.pop_login').hide();
		$('.pop_join').hide();
		$('.pop_photo').hide();
		$('.pop_upload_video').hide();
		$('.pop_contact').hide();

		$('.photo_nav_left, .photo_nav_right').hide();

		$('#contact_email_focus').val('');

		if(mobile == 0) { $('body').css('overflow','auto'); }
			
		$('#email_focus').val('');
		$('#email_j_focus').val('');
		$('#password_focus').val('');
		$('#password_j_focus').val('');
		$('#name_focus').val('');
		$('#gender_j').val('pop_join_genderm');
		$('.pop_join_genderm').click();

		$('.pop_lostpw').hide();
		$('#lostpw_email_focus').val('');

		if (typeof live_comments != "undefined") {
		
			clearInterval(live_comments);
			live_comments = null;

		}

		if (typeof update_chat != "undefined") {

			clearInterval(update_chat);
			update_chat = null;

		}

		$('.pop_chat').hide();
		$('.pop_chat').find('.pop_box_header .pop_box_title').html('');
		$('.conversation').html('');
		$('#conversation').perfectScrollbar('destroy');

		$('.pop').hide();
		$('.close_photo').hide();

		$('.pop_upload').hide();
		$('.pop_edit').hide();

		$('#pop_edit_description').val('');
		$('.pop_edit_details').hide();

		if (typeof check_online != "undefined") {
		
			clearInterval(check_online);
			check_online = null;
		
		}

		$('.pop_covers').hide();
		$('.pop_covers_details').hide();

		if(mobile == 1) {
			$('.site').show();
			$('.footer').show();
			$('#pop_photo_src').attr('src','');
		}

		reload_footer();

	}

	$(document).keydown(function(e){
    
		if(e.which == 27) {

			close_pops();

			$('.settings_pop').hide();

		}

	});

	$(document).on('click', '.pop_box_close, .close_photo, .pop_content', function() {

		if(mobile == 1) {
	
			if($(this).hasClass('pop_box_close')) {
				close_pops();
			}

		} else {

			close_pops();

		}

		$('.settings_pop').hide();

	});
		
	$(document).on('click', '.pop_user_cancel, .pop_opacity', function() {

		if(mobile == 1) {

			$('.pop_user_menu, .pop_picture_menu').hide();
			$('body').css('overflow','auto');

		}

	});
