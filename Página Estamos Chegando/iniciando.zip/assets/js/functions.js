
	function fix_encoding(str_data) {

 		var tmp_arr = [], i = 0, ac = 0, c1 = 0, c2 = 0, c3 = 0, c4 = 0;
		str_data += '';

  		while (i < str_data.length) {
    
			c1 = str_data.charCodeAt(i);
    
			if (c1 <= 191) { tmp_arr[ac++] = String.fromCharCode(c1); i++;
			} else if (c1 <= 223) { c2 = str_data.charCodeAt(i + 1); tmp_arr[ac++] = String.fromCharCode(((c1 & 31) << 6) | (c2 & 63)); i += 2;
    			} else if (c1 <= 239) { c2 = str_data.charCodeAt(i + 1); c3 = str_data.charCodeAt(i + 2); tmp_arr[ac++] = String.fromCharCode(((c1 & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63)); i += 3;
    			} else { c2 = str_data.charCodeAt(i + 1); c3 = str_data.charCodeAt(i + 2); c4 = str_data.charCodeAt(i + 3); c1 = ((c1 & 7) << 18) | ((c2 & 63) << 12) | ((c3 & 63) << 6) | (c4 & 63); c1 -= 0x10000; tmp_arr[ac++] = String.fromCharCode(0xD800 | ((c1 >> 10) & 0x3FF)); tmp_arr[ac++] = String.fromCharCode(0xDC00 | (c1 & 0x3FF)); i += 4; }
  
		}

	  	return tmp_arr.join('');

	}

	if(mobile == 1) {

		var screen_size = $(document).width();

		if(screen_size == '320') {
			var screen_img = '144';
			var screen_img_w = '146';
			var screen_img_h = '124';
		}

		if(screen_size == '340') {
			var screen_img = '154';
			var screen_img_w = '156';
			var screen_img_h = '134';
		}

		if(screen_size == '360') {
			var screen_img = '163';
			var screen_img_w = '165';
			var screen_img_h = '134';
		}

		if(screen_size == '375') {
			var screen_img = '170';
			var screen_img_w = '173';
			var screen_img_h = '134';
		}

		if(screen_size == '380') {
			var screen_img = '173';
			var screen_img_w = '175';
			var screen_img_h = '134';
		}

		if(screen_size == '400') {
			var screen_img = '182';
			var screen_img_w = '182';
			var screen_img_h = '144';
		}

		if(screen_size == '414') {
			var screen_img = '189';
			var screen_img_w = '190';
			var screen_img_h = '149';
		}

		if(screen_size == '432') {
			var screen_img = '196';
			var screen_img_w = '199';
			var screen_img_h = '163';
		}

		if(screen_size == '480') {
			var screen_img = '148';
			var screen_img_w = '148';
			var screen_img_h = '119';
		}

		if(screen_size == '540') {
			var screen_img = '164';
			var screen_img_w = '166';
			var screen_img_h = '135';
		}

		if(screen_size == '568') {
			var screen_img = '173'; 
			var screen_img_w = '175';
			var screen_img_h = '140';
		}

		if(screen_size == '600') {
			var screen_img = '183';
			var screen_img_w = '185';
			var screen_img_h = '145';
		}

		if(screen_size == '620') {
			var screen_img = '189';
			var screen_img_w = '191';
			var screen_img_h = '150';
		}

		if(screen_size == '640') {
			var screen_img = '196';
			var screen_img_w = '198';
			var screen_img_h = '155';
		}

		if(screen_size == '667') {
			var screen_img = '204';
			var screen_img_w = '206';
			var screen_img_h = '165';
		}

		if(screen_size == '680') {
			var screen_img = '208';
			var screen_img_w = '210';
			var screen_img_h = '165';
		}

		if(screen_size == '720') {
			var screen_img = '221';
			var screen_img_w = '224';
			var screen_img_h = '170';
		}

		if(screen_size == '740') {
			var screen_img = '227';
			var screen_img_w = '230';
			var screen_img_h = '180';
		}

		if(screen_size == '750') {
			var screen_img = '230';
			var screen_img_w = '233';
			var screen_img_h = '180';
		}

		if(screen_size == '768') {
			var screen_img = '236';
			var screen_img_w = '240';
			var screen_img_h = '185';
		}

		if(screen_size == '800') {
			var screen_img = '246';
			var screen_img_w = '249';
			var screen_img_h = '200';
		}

		if(screen_size == '960') {
			var screen_img = '221';
			var screen_img_w = '224';
			var screen_img_h = '180';
		}

		if(screen_size == '1024') {
			var screen_img = '236';
			var screen_img_w = '240';
			var screen_img_h = '200';
		}

		if(screen_size == '1280') {
			var screen_img = '297';
			var screen_img_w = '297';
			var screen_img_h = '234';
		}

		if(screen_size == '1366') {
			var screen_img = '297';
			var screen_img_w = '297';
			var screen_img_h = '234';
		}

	} else {

		var screen_img = 270;
		var screen_img_w = 270;
		var screen_img_h = 220;

	}

	function responsive_mobile() {

		var screen_size = $(window).width();
	
		var size_1 = (screen_size / 10) / 3.4;
		var size_2 = screen_size / 3.4;
		if(size_2 > 300) { size_2 = 300; }
		var size_3 = size_2 - 45;
		var size_4 = screen_size - 11;
		var size_5 = screen_img_h - 35;
		var size_6 = screen_img_w - 20;
		var size_7 = size_3 + 4;

		if(mobile == 1) {

			var us_1 = '.user_photos { width:'+size_4+'px !important; margin:0 auto !important; }';
			var us_2 = '.user_cover { width:'+screen_size+'px !important; height:'+size_2+'px !important }';
			var us_3 = '.cover_slide { width:'+screen_size+'px !important; height:'+size_2+'px !important }';
			var us_4 = '.user_photos_item { float:left !important; width:'+screen_img_w+'px !important; height:'+screen_img_h+'px !important; margin:4px !important; margin-top:5px !important; margin-bottom:5px !important }';
			var us_5 = '.user_profile_pic { width:90px !important; height:90px !important; top:'+size_3+'px !important; left:10px !important }';
			var us_6 = '.user_menu_verified img { top:50px !important }';
			var us_7 = '.user_data_col { width:95% !important; top:'+size_7+'px !important; left:120px !important }';
			var us_8 = '.user_menu_name { max-width:174px !important }';
			var us_9 = '.user_photos_item_black { width:'+size_6+'px !important; height:15px !important; padding:10px !important }';
			var us_10 = '.user_photos_item_stats { width:'+screen_img_w+'px !important; height:52px !important }';
			var us_11 = '.user_follow_result { float:none !important; margin:0 auto; display:block !important; margin-top:9px !important; margin-bottom:9px !important; width:316px !important; height:115px !important }';
			var us_12 = '.user_follow_result_pic { top:25px !important; left:9px; width:75px !important;height:75px !important }';
			var us_13 = '.user_follow_result_pic img { border:2px solid #fff !important; border-radius:75px !important; width:75px !important; height:75px !important }';
			var us_14 = '.user_follow_result_cover { width:216px !important; padding-top:38px !important; padding-left:100px !important; height:37px !important }';
			var us_15 = '.user_follow_result_name { width:206px !important; padding:10px !important; padding-bottom:13px !important; padding-top:9px !important; height:18px !important; padding-left:100px !important; max-width:275px !important }';
			var us_16 = '.user_follow_result_col_1 { max-width:250px !important }';
			var us_17 = '.play_icon_user { top:40px !important; width:40px !important; height:40px !important; background-size:40px 40px !important }';
			var us_18 = '.photo_large { width:'+screen_img_w+'px !important; height:'+size_5+'px !important; top:35px important; }';

			$('#head_style').stop().html('<style type="text/css">'+us_1+us_2+us_3+us_4+us_5+us_6+us_7+us_8+us_9+us_10+us_11+us_12+us_13+us_14+us_15+us_16+us_17+us_18+'</style>');
		
		}

	}

	$(window).on('load resize', function(){

		if(mobile == 1) {
			responsive_mobile();
		}

	});

	function load_settings_box() {

		$.post('inc/load_settings.php', function(get) {

			var logged_privacy_1 = get.logged_privacy_1;
			var logged_privacy_2 = get.logged_privacy_2;	
			var logged_privacy_3 = get.logged_privacy_3;

			$('.settings_0_1').val(get.logged_name);
			$('.settings_0_2').val(get.logged_user);
			$('.settings_0_3').val(get.logged_email);

			$('#select_1_field').find('option[value="' + logged_privacy_1 + '"]').attr("selected", "selected");
			$('#select_2_field').find('option[value="' + logged_privacy_2 + '"]').attr("selected", "selected");
			$('#select_3_field').find('option[value="' + logged_privacy_3 + '"]').attr("selected", "selected");

			$('#gender_field').find('option[value="' + get.logged_gender + '"]').attr("selected", "selected");

			$('#birthday_field').find('option[value="' + get.birthday + '"]').attr("selected", "selected");
			$('#birthmonth_field').find('option[value="' + get.birthmonth + '"]').attr("selected", "selected");
			$('#birthyear_field').find('option[value="' + get.birthyear + '"]').attr("selected", "selected");

			$('#desc_field').val(get.logged_desc);
			$('#birthday_field').val();
			$('#birthmonth_field').val();
			$('#birthyear_field').val();
			$('#country_field').val(get.logged_location_country);
			$('#city_field').val(get.logged_location_city);
			$('#facebook_field').val(get.logged_social_facebook);
			$('#twitter_field').val(get.logged_social_twitter);
			$('#google_field').val(get.logged_social_google);
			$('#pinterest_field').val(get.logged_social_pinterest);

			$('#_message_info').data('fromname', get.logged_name).data('fromprofile', get.logged_user).data('frompic', site_url+'/picture/'+$('#_loggedid').val()+'/35/35');

			$('#_settings_loaded').val(1);

		}, 'json');

	}

	if($('#_settings_loaded').val() == 0 && $('#_logged').val() == 1) {
		load_settings_box();
	}

	function reload_footer() {

		var heights = $(window).height();
		var documents = documents = $('html').height() + $('.footer_home').height();

		$('.footer_home').css('position','fixed').css('bottom','0');

		if(documents < heights) {

			$('.footer_home').css('position','fixed').css('bottom','0');

		} else {

			if(mobile == 0 && $('#_main_now').val() == 'home' && home_style == 2) {
				$('.footer_home').css('position','fixed').css('bottom','0');
			} else {
				$('.footer_home').css('position','relative').css('bottom','none');
			}

		}

	}

	$(document).on('click', '.cookie_ok', function() {

		$.post('inc/cookie.php');
		$('.cookie_bar').remove();

	});

	$(document).on('click', '.menu_languages_box_close', function() {
	
		$('.menu_languages').hide();

	});

	$(document).on('click', '.pop_languages_close, .pop_opacity', function() {
	
		if(mobile == 1) {
			$('.pop_menu_languages').hide();
		}

	});

	$(document).on('click', '.hit_language', function() {
	
		if(mobile == 0) {
			$('.menu_languages').show();
		} else {
			$('.pop_menu_languages').show();
		}

	});

	$(document).on('click', '.menu_languages_box_item', function() {

		var file = $(this).data('file');
		$.post('inc/set_lang.php', { file: file }, function() {

			window.location.href = page_url;

		});

	});

	function validateEmail($email) {

		var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		if( !emailReg.test( $email ) ) {

			return false;

  		} else {

			if($email.length > 5) {
    				return true;
			} else {
				return false;
			}

  		}

	}

	function strip_HTML(html) {

    		return html.replace(/<\/?([a-z][a-z0-9]*)\b[^>]*>?/gi, '');

	}

	function alphanum(inputtxt) { 

		var letters = /^[0-9a-zA-Z]+$/;
		if(letters.test(inputtxt)) {

			if(inputtxt.length > 5) {
				return true;
			} else {
				return false;
			}

		} else {

			return false;
		}

	}

	function is_numeric(obj) {

    		return !isNaN(parseFloat(obj)) && isFinite(obj);

	}

  	function comparatorName(a, b) {

          	return $(a).data('views') < $(b).data('views') ? -1 : 1;

       	}

	function time() {
 
		return Math.floor(new Date().getTime() / 1000);

	}


	function ucwords(str) {
 		
		return (str + '').replace(/^([a-z\u00E0-\u00FC])|\s+([a-z\u00E0-\u00FC])/g, function($1) {
      			return $1.toUpperCase();
    		});

	}

 	function updateCoords(data) {
    		
		$('#cropx').text(data.cropX);
		$('#cropy').text(data.cropY);
		$('#cropw').text(data.cropW);
		$('#croph').text(data.cropH);
  					
	}

	function update_header(logg,picture,profile) {

		if(mobile == 0) {

			if(logg == 1) {
				$('#_logged').val(1);
				$('.logo').addClass('call_live_feed').removeClass('call_live_home');
				$('.header_user_logged_pic').attr('src', site_url+'/picture/'+picture+'/35/35');
				$('.header_profile_link').data('profileuser', profile);
				$('.header_user_logged, .upload_plus, .upload_video, .upload, .m_item_1, .m_item_2, .m_item_3').show();
				$('.m_item_4, .m_item_5').hide();
			} else {
				$('#_logged').val(0);
				$('.logo').removeClass('call_live_feed').addClass('call_live_home');
				$('.header_user_logged, .upload_plus, .upload_video, .upload, .m_item_1, .m_item_2, .m_item_3').hide();
				$('.m_item_4, .m_item_5').show();
			}

		} else {

			if(logg == 1) {
				$('#_logged').val(1);
				$('.logo').addClass('call_live_feed').removeClass('call_live_home');
				$('.top_logged_pic img').stop().attr('src', site_url+'/picture/'+picture+'/75/75').data('profileuser', profile);
				$('.swipe_1, .swipe_12, .swipe_13').stop().hide();
				$('.top_logged_pic, .swipe_2, .swipe_3, .swipe_4, .swipe_5, .swipe_6, .swipe_7, .swipe_8, .swipe_9').stop().show();
				$('.swipe_5').data('profileuser', profile);
			} else {
				$('#_logged').val(0);
				$('.logo').removeClass('call_live_feed').addClass('call_live_home');
				$('.swipe_1, .swipe_12, .swipe_13').stop().show();
				$('.top_logged_pic, .swipe_2, .swipe_3, .swipe_4, .swipe_5, .swipe_6, .swipe_7, .swipe_8, .swipe_9').stop().hide();
			}

		}

	}

	$(document).on('click', '.user_menus_load', function() {

		$('.upload_menus').hide();
		$('.upload_plus').removeClass('upload_plus_active');

		if($('.user_menus').is(':hidden')) {
			$('.user_menus').show();
			if($('.header_user_logged').hasClass('cp_color_1_hover')) { $('.header_user_logged').addClass('cp_color_1'); }
			if($('.header_user_logged').hasClass('cp_color_2_hover')) { $('.header_user_logged').addClass('cp_color_2'); }
			if($('.header_user_logged').hasClass('cp_color_3_hover')) { $('.header_user_logged').addClass('cp_color_3'); }
			if($('.header_user_logged').hasClass('cp_color_4_hover')) { $('.header_user_logged').addClass('cp_color_4'); }
			if($('.header_user_logged').hasClass('cp_color_5_hover')) { $('.header_user_logged').addClass('cp_color_5'); }
			if($('.header_user_logged').hasClass('cp_color_6_hover')) { $('.header_user_logged').addClass('cp_color_6'); }
			if($('.header_user_logged').hasClass('cp_color_7_hover')) { $('.header_user_logged').addClass('cp_color_7'); }
			if($('.header_user_logged').hasClass('cp_color_8_hover')) { $('.header_user_logged').addClass('cp_color_8'); }
			if($('.header_user_logged').hasClass('cp_color_9_hover')) { $('.header_user_logged').addClass('cp_color_9'); }
			if($('.header_user_logged').hasClass('cp_color_10_hover')) { $('.header_user_logged').addClass('cp_color_10'); }
			if($('.header_user_logged').hasClass('cp_color_11_hover')) { $('.header_user_logged').addClass('cp_color_11'); }
			if($('.header_user_logged').hasClass('cp_color_12_hover')) { $('.header_user_logged').addClass('cp_color_12'); }
		} else {
			$('.user_menus').hide();
			$('.header_user_logged').removeClass('cp_color_1').removeClass('cp_color_2').removeClass('cp_color_3').removeClass('cp_color_4').removeClass('cp_color_5').removeClass('cp_color_6').removeClass('cp_color_7').removeClass('cp_color_8').removeClass('cp_color_9').removeClass('cp_color_10').removeClass('cp_color_11').removeClass('cp_color_12');
		}

	});

	$(document).on('click', function(e) {

		var target = e.target;

		if(!$(target).hasClass('user_menus_load')) {
			$('.user_menus').hide();
			$('.header_user_logged').removeClass('cp_color_1').removeClass('cp_color_2').removeClass('cp_color_3').removeClass('cp_color_4').removeClass('cp_color_5').removeClass('cp_color_6').removeClass('cp_color_7').removeClass('cp_color_8').removeClass('cp_color_9').removeClass('cp_color_10').removeClass('cp_color_11').removeClass('cp_color_12');
		}

		if(!$(target).hasClass('upload_plus') && !$(target).hasClass('round2_upload')) {
			$('.upload_menus').hide();
			$('.upload_plus').removeClass('upload_plus_active');
			$('.round2_upload').removeClass('round2_upload_active');
		}

		if(!$(target).hasClass('share_button') && !$(target).hasClass('share_button_options')) {
			$('.share_button_options').hide();
		}

		if(!$(target).hasClass('hit_language')) {
			$('.menu_languages').hide();
		}

	});


	$(document).on('click','#login_but2,#join_but2', function() {

		if($(this).attr('id') == 'login_but2') {
			$('#login_but').click();
		}
		if($(this).attr('id') == 'join_but2') {
			$('#join_but').click();
		}

	});


	$(document).on({

    		mouseenter: function(){
			if(!$(this).is(':hidden')) {
       				$(this).fadeOut(300);
			}
    		},
    		mouseleave: function(){
       
    		}

	}, '.failed_msg, .success_msg');


	$(document).on({

    		mouseenter: function(){
			if(!$(this).is(':hidden')) {
       				$(this).fadeOut(300);
			}
    		},
    		mouseleave: function(){
       
    		}

	}, '.failed_msgs, .success_msgs');

	$(document).on('click', '.follow, .unfollow', function() {

		var uid = $(this).data('uid');

		var this_button = $(this);

		if($(this).hasClass('follow')) {

			if($('#_logged').val() == 0) {
				$('#login_but').click();
			} else {

				$.post('inc/follow.php', { fid: uid }, function(get) {

					if(get == 1) {
	
						if($('#_loggedid').val() != $('#_current_id').val()) {

							var element = document.getElementById('fnr');
 							if (typeof (element) != undefined && typeof (element) != null && typeof (element) != 'undefined') {

								if(uid == $('#_current_id').val()) {
									
									var fnr = $('#fnr').text();
									fnr++;
									$('#fnr').text(fnr);

								}

 							}

						} else {

							if($('#_current_id').val() == uid) {
								
								var finr = $('#finr').text();
								finr++;
								$('#finr').text(finr);

							}

						}

						var old_count = $(this_button).find('.follows_count').text();
						var cut = old_count.slice(-1);
						if(cut != 'k') {
							old_count++;
							$(this_button).find('.follows_count').text(old_count);
						}

						$(this_button).removeClass('follow').addClass('unfollow');
						$(this_button).find('.follows_op').text(lang['unfollow']);

						if($('.user_privacy')[0]) {
							
							$('.message').removeClass('privacy');
							$('.user_privacy').val('0');
							$('.user_privacy_results').hide();
							load_photos('x','1');

						}
	
					}

				});

			}

		} else {
	
			$.post('inc/unfollow.php', { fid: uid }, function(get) {

				if(get == 1) {

					if($('.user_following #fol_'+uid)[0]) {

						if($('#_current_id').val() == $('#_loggedid').val()) {

							$('.user_following #fol_'+uid).fadeOut(500, function() {

								var count_items = $('.user_following .user_follow_result').length;

								if(count_items < 2) {
									$('.user_following .user_no_results').show();
								}

							});

						}

					}	

					if($('#_loggedid').val() == $('#_current_id').val()) {

						var element = document.getElementById('finr');
 						if (typeof (element) != undefined && typeof (element) != null && typeof (element) != 'undefined') {

							var finr = $('#finr').text();
							finr--;
							$('#finr').text(finr);

						}

					} else {

						if($('#_current_id').val() == uid) {

							var fnr = $('#fnr').text();
							fnr--;
							$('#fnr').text(fnr);

						}

 					}

					var old_count = $(this_button).find('.follows_count').text();
					var cut = old_count.slice(-1);
					if(cut != 'k') {
						old_count--;
						$(this_button).find('.follows_count').text(old_count);
					}

					$(this_button).removeClass('unfollow').addClass('follow');
					$(this_button).find('.follows_op').text(lang['follow']);

					if($('.user_privacy')[0]) {
							
						$('.message').addClass('privacy');
						$('.user_privacy').val('1');

					}

				}

			});

		}

	});

	function open_mobile_menu() {

		$('.mask').show();	
		$('html,body').css('overflow-x','hidden');
		$('.site, .footer').css('left','-260px');
		$('.menu_swipe').css('width','260px');

		$('.footer_home').css('z-index','-999');

	}

	function close_mobile_menu() {
		
		$('.mask').hide();
		$('html,body').css('overflow-x','auto');
		$('.site, .footer').css('left','0');
		$('.m_menu').css('left','0');
		$('.menu_swipe').css('width','0');

		$('.footer_home').css('z-index','999');

	}

	$(document).on('click', '.mask', function() {

		if(mobile == 1) {
			close_mobile_menu();
		}

	});

	$(document).on('click','.m_menu', function() {

		if(mobile == 1) {

			if($('.menu_swipe').css('width') == '0px') {

				open_mobile_menu();

			} else {

				close_mobile_menu();

			}

		}

	});

	$(document).on('click', '#select_photo', function() {

		if(mobile == 1) {

			close_mobile_menu();

		}

	});

	function loading_bar(type) {

		if(type == 1) {
			$("body").append($("<div><dt/><dd/></div>").attr("id", "progress"));
			$("#progress").width((50 + Math.random() * 30) + "%");
		}

		if(type == 2) {
			$("#progress").width("101%").delay(100).fadeOut(200, function() {
        			$(this).remove();
    			});
		}

	}

	function reload_action(action) {

		if(mobile == 0) {

			if(action == 'feed') {
				$('.feed_scroll').stop().animate({left: $('.feed_button_s').position().left, width: $('.feed_button_s').width()+30});
       				$('.feed_scroll').width($('.feed_button_s').width()+30).data('curl', $('.feed_scroll').position().left).data('curw', $('.feed_scroll').width());
			}

			if(action == 'user') {
				$('.user_menu_buttons_scroll').stop().animate({left: $('.user_menu_buttons_item_selected').position().left, width: $('.user_menu_buttons_item_selected').width()+40});
       				$('.user_menu_buttons_scroll').width($('.user_menu_buttons_item_selected').width()+40).data('curl', $('.user_menu_buttons_scroll').position().left).data('curw', $('.user_menu_buttons_scroll').width());
			}

			if(action == 'users') {
				$('.users_scroll').stop().animate({left: $('.user_box_name_selected').position().left, width: $('.user_box_name_selected').width()+22});
       				$('.users_scroll').width($('.user_box_name_selected').width()+22).data('curl', $('.users_scroll').position().left).data('curw', $('.users_scroll').width());
			}

		}

	}

	$(document).on('click', '.call_live_users, .call_live_feed, .call_live_hashtag, .call_live_browse, .call_live_profile, .call_live_logout, .call_live_home', function() {

		close_mobile_menu();

		if($(this).hasClass('call_live_browse')) { load_live_page('browse'); }
		if($(this).hasClass('call_live_users')) { load_live_page('users'); }
		if($(this).hasClass('call_live_feed')) { load_live_page('feed'); }
		if($(this).hasClass('call_live_hashtag')) { load_live_page('hashtag', $(this).data('hashtag')); }
		if($(this).hasClass('call_live_profile')) { load_live_page('profile', $(this).data('profileuser')); }
		if($(this).hasClass('call_live_logout')) { $.post('inc/logout.php', function() { load_live_page('logout'); }); }
		if($(this).hasClass('call_live_home')) { load_live_page('home'); }
		return false;

	});

	$(window).resize(function() {

		reload_footer();

	});

	function set_ad(custom_page,step) {

		if($('#_ad_728_active').val() == 0) {
			tag_728_90 = '0';
		}

		if($('#_ad_300_active').val() == 0) {
			tag_300_250 = '0';
		}

		if($('#_ad_468_active').val() == 0) {
			tag_468_15 = '0';
		}

		if($('#_ad_320_active').val() == 0) {
			tag_320_50 = '0';
		}

		if(step == 1) {

			if(mobile == 0) {

				if($('#_ads_loaded_2').val() == 0) {

					if(custom_page == 'home' || custom_page == 'logout' || custom_page == 'profile') {
		
						tag_728_90 = $('#tag_728_90').html();
						$('#tag_728_90').stop().html('');
						$('#tag_728_90').html(tag_728_90);

						$('#_ads_loaded_2').val(1);

					}

				}

				if($('#_ads_loaded_3').val() == 0) {

					if(custom_page == 'feed' || custom_page == 'hashtag' || custom_page == 'browse' || custom_page == 'users' || custom_page == 'faq' || custom_page == 'terms' || custom_page == 'about' || custom_page == 'privacy') {

						tag_300_250 = $('#tag_300_250').html();
						tag_468_15 = $('#tag_468_15').html();

						$('#tag_300_250, #tag_468_15').stop().html('');

						$('#tag_300_250').html(tag_300_250);
						$('#tag_468_15').html(tag_468_15);

						$('#_ads_loaded_3').val(1);

					}

				}

			} else {

				if($('#_ads_loaded').val() == 0) {
			
					tag_320_50 = $('#tag_320_50').html();
					$('#tag_320_50').stop().html('');
			
				} else {

					tag_320_50 = $('.ad_320_50_users').html();
					$('.ad_320_50_users').stop().html('');
	
				}

			}

			if($('#_ads_loaded').val() != 0) {

				if($('#_ads_loaded').val() == 'home' || $('#_ads_loaded').val() == 'logout') {

					if(custom_page == 'profile' || custom_page == 'logout' || custom_page == 'home') {
				
						tag_728_90 = $('.ad_728_90_home').html();
						$('.ad_728_90_home').stop().html('');

					} else {

						tag_728_90 = $('.ad_728_90_home').html();
						$('.ad_728_90_home').stop().html('');
						$('#tag_728_90').html(tag_728_90);

						tag_300_250 = $('#tag_300_250').html();
						tag_468_15 = $('#tag_468_15').html();
						$('#tag_300_250, #tag_468_15').stop().html('');

					}

				}

				if($('#_ads_loaded').val() == 'profile') {

					if(custom_page == 'home' || custom_page == 'logout') {
				
						if($('#selected_user').text() == 'photos') {
							tag_728_90 = $('.user_photos .ad_728_90_home').html();
							$('.user_photos .ad_728_90_home').stop().html('');
						}
	
						if($('#selected_user').text() == 'about') {
							tag_728_90 = $('.user_about .ad_728_90_home').html();
							$('.user_about .ad_728_90_home').stop().html('');
						}

						if($('#selected_user').text() == 'followers') {
							tag_728_90 = $('.user_followers .ad_728_90_home').html();
							$('.user_followers .ad_728_90_home').stop().html('');
						}

						if($('#selected_user').text() == 'following') {
							tag_728_90 = $('.user_following .ad_728_90_home').html();
							$('.user_following .ad_728_90_home').stop().html('');
						}

					}

					if(custom_page == 'feed' || custom_page == 'hashtag' || custom_page == 'browse' || custom_page == 'users' || custom_page == 'faq' || custom_page == 'terms' || custom_page == 'about' || custom_page == 'privacy') {

						tag_300_250 = $('#tag_300_250').html();
						tag_468_15 = $('#tag_468_15').html();
						$('#tag_300_250, #tag_468_15').stop().html('');

						if($('#selected_user').text() == 'photos') {
							tag_728_90 = $('.user_photos .ad_728_90_home').html();
							$('.user_photos .ad_728_90_home').stop().html('');
						}
	
						if($('#selected_user').text() == 'about') {
							tag_728_90 = $('.user_about .ad_728_90_home').html();
							$('.user_about .ad_728_90_home').stop().html('');
						}

						if($('#selected_user').text() == 'followers') {
							tag_728_90 = $('.user_followers .ad_728_90_home').html();
							$('.user_followers .ad_728_90_home').stop().html('');
						}

						if($('#selected_user').text() == 'following') {
							tag_728_90 = $('.user_following .ad_728_90_home').html();
							$('.user_following .ad_728_90_home').stop().html('');
						}

						$('#tag_728_90').html(tag_728_90);

					}

					if(custom_page == 'profile') {
					
						if($('#selected_user').text() == 'photos') {
							tag_728_90 = $('.user_photos .ad_728_90_home').html();
							$('.user_photos .ad_728_90_home').stop().html('');
						}

						if($('#selected_user').text() == 'about') {
							tag_728_90 = $('.user_about .ad_728_90_home').html();
							$('.user_about .ad_728_90_home').stop().html('');
						}

						if($('#selected_user').text() == 'followers') {
							tag_728_90 = $('.user_followers .ad_728_90_home').html();
							$('.user_followers .ad_728_90_home').stop().html('');
						}

						if($('#selected_user').text() == 'following') {
							tag_728_90 = $('.user_following .ad_728_90_home').html();
							$('.user_following .ad_728_90_home').stop().html('');
						}

						$('#tag_728_90').html(tag_728_90);

					}

				}

				if($('#_ads_loaded').val() == 'browse' || $('#_ads_loaded').val() == 'hashtag' || $('#_ads_loaded').val() == 'users' || $('#_ads_loaded').val() == 'privacy' || $('#_ads_loaded').val() == 'faq' || $('#_ads_loaded').val() == 'terms' || $('#_ads_loaded').val() == 'feed' || $('#_ads_loaded').val() == 'trending' || $('#_ads_loaded').val() == 'activity' || $('#_ads_loaded').val() == 'about') {

					if(custom_page == 'home' || custom_page == 'profile' || custom_page == 'logout') {

						tag_300_250 = $('.ad_300_250').html();
						tag_468_15 = $('.ad_468_15').html();
						$('.ad_300_250, .ad_468_15').stop().html('');
						$('#tag_300_250').html(tag_300_250);
						$('#tag_468_15').html(tag_468_15);

						tag_728_90 = $('#tag_728_90').stop().html();
						$('#tag_728_90').stop().html('');

					} else {

						tag_300_250 = $('.ad_300_250').html();
						tag_468_15 = $('.ad_468_15').html();

						$('.ad_300_250, .ad_468_15').stop().html('');
	
					}

				}

			}

		}

		if(step == 2) {

			if(custom_page == 'home' || custom_page == 'logout') {

				if(mobile == 0) {
					if(typeof tag_728_90.length !== "undefined" && tag_728_90.length > 5) { $('.ad_728_90_home').html(tag_728_90); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_home').html(tag_320_50); }
				}

			}

			if(custom_page == 'users') {

				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}

			if(custom_page == 'trending') {
	
				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}

			if(custom_page == 'activity') {
	
				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}
	
			}

			if(custom_page == 'feed') {
	
				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}

			if(custom_page == 'privacy') {
	
				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}

			if(custom_page == 'terms') {
	
				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}

			if(custom_page == 'faq') {
	
				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}

			if(custom_page == 'about') {
	
				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}

			if(custom_page == 'browse') {
	
				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}

			if(custom_page == 'profile') {

				if(mobile == 0) {
					if(typeof tag_728_90.length !== "undefined" && tag_728_90.length > 5) { $('.user_photos .ad_728_90_home').html(tag_728_90); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}

			if(custom_page == 'hashtag') {

				if(mobile == 0) {
					if(typeof tag_300_250.length !== "undefined" && tag_300_250.length > 5) { $('.ad_300_250').html(tag_300_250); }
					if(typeof tag_468_15.length !== "undefined" && tag_468_15.length > 5) { $('.ad_468_15').html(tag_468_15); }
				} else {
					if(typeof tag_320_50.length !== "undefined" && tag_320_50.length > 5) { $('.ad_320_50_users').html(tag_320_50); }
				}

			}
			
			$('#_ads_loaded').val(custom_page);
			$('#_load_start').val(0);

		}

	}

	function load_live_page(custom_page,profile_user) {

		if($('#_load_start').val() == 0) {
	
		$('#_load_start').val(1);

		close_pops();
		$(document).click();

		if(mobile == 1) {
			close_mobile_menu();
		}

		$('.footer_home').css('position','fixed').css('bottom','0');

		last_count_photos = 16;
		last_count_follow = 21;
		clearInterval(feed_update);
		clearInterval(activity_update);
		feed_update = null;
		activity_update = null;
		feed_limit = 15;
		users_limit = 27;
		hashtags_limit = 15;
		activity_limit = 15;
		browse_limit = 15;
		loading_bar(1);

		set_ad(custom_page,1);

		if(custom_page != 'logout' && custom_page != 'home') {
			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
		} else {
			$('body').stop().addClass('background');
			$('.background_slide, .opacity_home').stop().fadeIn(1);
		}

		$('body .live_load').stop().html('');
		$('body .browse_users, body .user').stop().remove();
			
		$('.user_menus').stop().hide();
		$('.header_user_logged').stop().removeClass('cp_color_1').removeClass('cp_color_2').removeClass('cp_color_3').removeClass('cp_color_4').removeClass('cp_color_5').removeClass('cp_color_6').removeClass('cp_color_7').removeClass('cp_color_8').removeClass('cp_color_9').removeClass('cp_color_10').removeClass('cp_color_11').removeClass('cp_color_12');

		$('.activity_results').stop().html('');
		$('.activity_tab').stop().hide();
		$('.round_activity').stop().removeClass('menu_active');

		$('.messages_results').stop().html('');
		$('.messages').stop().hide();
		$('.round_chat').stop().removeClass('menu_active');

		clearInterval(slide_start);
		slide_start = null;

		$('.suggestions').each(function() {

			if($('#_logged').val() == 0) {
				$(this).hide();
			} else {
				$(this).show();
			}

		});

		if(custom_page == 'logout' || custom_page == 'home') {

			document.title = lang['title_home'];
			window.history.pushState("", "Home", '/');
			temp_page = '';

			$('#_logged').val(0);
			$('#_loggedid').val(0);
			$('#_settings_loaded').val(0);

			update_header('0');
			$('#_main_now').val('home');
			
			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('.main, .header_bar_space').stop().hide();
			$('.footer').stop().hide();

			if(mobile == 1) {
				var temp_f = 'home_area';
			} else {
				if(home_style == 2) {
					var temp_f = 'home_area';
				} else {
					var temp_f = 'site';
				}
			}

			$('.live_load').load('index.php?page=home&option=live .'+temp_f, function() {

				set_ad(custom_page,2);

				$('body').scrollTop(0);
				loading_bar(2);
				reload_footer();
			});

		}

		if(custom_page == 'users') {

			document.title = lang['title_users'];
			window.history.pushState("", "Users", '/users');
			temp_page = 'users';

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('#_main_now').val('users');
			$('.live_load').load('index.php?page=users&option=live .site .browse_users', function() {

				set_ad(custom_page,2);

				load_users('0','3');
				$('body').scrollTop(0);
				loading_bar(2);

				reload_footer();

			});

		}

		if(custom_page == 'trending') {
	
			document.title = lang['title_trending'];
			$('#_main_now').val('trending');

			window.history.pushState("", "Trending", '/trending');
			temp_page = '';

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('.live_load').load('index.php?page=home .site .feed_page', function() { 
				
				set_ad(custom_page,2);

				reload_action('feed');

				$('#trending').click();
				if(mobile == 0) { get_suggestions(); }
				loading_bar(2);

				reload_footer();

			});

		}

		if(custom_page == 'activity') {
	
			document.title = lang['title_activity'];
			$('#_main_now').val('activity');

			window.history.pushState("", "Activity", '/activity');
			temp_page = '';

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('.live_load').load('index.php?page=home .site .feed_page', function() { 
				
				set_ad(custom_page,2);

				reload_action('feed');

				$('#activity').click();
				if(mobile == 0) { get_suggestions(); }
				loading_bar(2);

				reload_footer();

			});

		}

		if(custom_page == 'feed') {
	
			document.title = lang['title_feed'];
			$('#_main_now').val('feed');

			window.history.pushState("", "Feed", '/');
			temp_page = '';

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('.live_load').load('index.php?page=home .site .feed_page', function() { 

				set_ad(custom_page,2);

				$('#feed').click();
				if(mobile == 0) { get_suggestions(); }
				loading_bar(2);

				reload_footer();

			});

		}

		if(custom_page == 'privacy') {
	
			document.title = lang['title_privacy'];
			$('#_main_now').val('privacy'); 

			window.history.pushState("", "Privacy", '/privacy.html');
			temp_page = 'privacy';

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('.live_load').load('index.php?option=live&page=pages&no=privacy .site .pages', function() { 

				set_ad(custom_page,2);

				loadpage('privacy');

				loading_bar(2);
				reload_footer();

			});

		}

		if(custom_page == 'terms') {
	
			document.title = lang['title_terms'];
			$('#_main_now').val('terms'); 

			window.history.pushState("", "Terms", '/terms.html');
			temp_page = 'terms';

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('.live_load').load('index.php?option=live&page=pages&no=terms .site .pages', function() { 

				set_ad(custom_page,2);

				loadpage('terms');

				loading_bar(2);
				reload_footer();

			});

		}

		if(custom_page == 'faq') {
	
			document.title = lang['title_faq'];
			$('#_main_now').val('faq'); 

			window.history.pushState("", "Faq", '/faq.html');
			temp_page = 'faq';

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('.live_load').load('index.php?option=live&page=pages&no=faq .site .pages', function() { 

				set_ad(custom_page,2);

				loadpage('faq');

				loading_bar(2);
				reload_footer();

			});

		}

		if(custom_page == 'about') {
	
			document.title = lang['title_about'];
			$('#_main_now').val('about'); 

			window.history.pushState("", "About", '/about.html');
			temp_page = 'about';

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('.live_load').load('index.php?option=live&page=pages&no=about .site .pages', function() { 

				set_ad(custom_page,2);

				loadpage('about');

				loading_bar(2);
				reload_footer();

			});

		}

		if(custom_page == 'browse') {
	
			document.title = lang['title_browse'];
			$('#_main_now').val('browse'); 

			window.history.pushState("", "Browse", '/browse');
			temp_page = 'browse';

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('.live_load').load('index.php?option=live&page=browse .site .browse_page', function() { 

				set_ad(custom_page,2);

				load_browse('x','1','1','0');
				if(mobile == 0 && $('#_logged').val() == 1) { get_suggestions(); }
				loading_bar(2);

				reload_footer();

			});

		}

		if(custom_page == 'profile') {

			$('#_main_now').val('user');
			current_user = profile_user;

			window.history.pushState("", "Profile", '/'+profile_user);
			temp_page = profile_user;

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			if(mobile == 1) {
				var call_f = 'user_page';
			} else {
				var call_f = 'user';
			}

			$('.live_load').load('index.php?option=live&id='+profile_user+' .'+call_f, function() { 

				set_ad(custom_page,2);

				var fetch_name = $('.user_menu_name').text();
				document.title = lang['title_user'].replace('%name%',fetch_name);

				reload_action('user');
				$('#_current_user').val(profile_user);

				load_user(current_user);
				slide_start = setInterval(function () { slide_cover(); }, 5000);
				loading_bar(2);

				reload_footer();

			});

		}

		if(custom_page == 'hashtag') {

			document.title = '#'+profile_user;
			window.history.pushState("", "Hashtags", '/hashtags/'+profile_user);
			temp_page = 'hashtags/'+profile_user;

			$('#_main_now').val('hashtags');

			if($('#_logged').val() == 1) {
				$('.logo, .logo_homes').stop().addClass('call_live_feed').removeClass('call_live_home');
			} else {
				$('.logo, .logo_homes').stop().removeClass('call_live_feed').addClass('call_live_home');
			}

			$('body').stop().removeClass('background');
			$('.background_slide, .opacity_home').stop().hide();
			$('.site, .main, .header_bar_space').stop().show();

			$('.live_load').load('index.php?option=live&page=hashtags&hashtags='+profile_user+' .hashtags_page', function() { 

				set_ad(custom_page,2);

				if(mobile == 0) { get_suggestions(); }
				load_hashtags('x','1','1',profile_user);

				loading_bar(2);

				reload_footer();

			});
	
		}

		}

	}

	$(document).on('click', '.upload_plus', function() {
	
		$('.user_menus').hide();
		$('.header_user_logged').removeClass('header_user_logged_menu');

		if($('.upload_menus').is(':hidden')) {
			$('.round2_upload').addClass('round2_upload_active');
			$('.upload_plus').addClass('upload_plus_active');
			$('.upload_menus').show();
		} else {
			$('.round2_upload').removeClass('round2_upload_active');
			$('.upload_plus').removeClass('upload_plus_active');
			$('.upload_menus').hide();
		}

	});

	function loadpage(page_click) {

		$('.page_content').hide();
		$('#_page_'+page_click).show();

		$('.menu_box').find('.menu_page_'+page_click).addClass('menu_box_item_selected');

		$('.pages_box_title').text(ucwords(page_click));
		document.title = ucwords(page_click);

	}

	$(document).on('click', '.hit_page_1, .hit_page_2, .hit_page_3, .hit_page_4', function() {

		if($(this).hasClass('hit_page_1')) {
			load_live_page('about');
			loadpage('about');
		}

		if($(this).hasClass('hit_page_2')) {
			load_live_page('faq');
			loadpage('faq');
		}

		if($(this).hasClass('hit_page_3')) {
			load_live_page('privacy');
			loadpage('privacy');
		}

		if($(this).hasClass('hit_page_4')) {
			load_live_page('terms');
			loadpage('terms');
		}

	});

	$(document).on('click', '.menu_box_item', function() {

		$('.menu_box_item').removeClass('menu_box_item_selected');
		var page_click = $(this).data('page');

		if(page_click == 'faq') { window.history.pushState("", "Faq", '/faq.html'); }
		if(page_click == 'about') { window.history.pushState("", "About", '/about.html'); }
		if(page_click == 'terms') { window.history.pushState("", "Terms", '/terms-of-use.html'); }
		if(page_click == 'privacy') { window.history.pushState("", "Privacy", '/privacy.html'); }

		loadpage(page_click);

	});

	$(document).on('click', '.pop_contact_button', function() {

		var email = $('#contact_email_focus').val();
		var message = $('#contact_text_focus').val();

		$('.pop_contact_error_box').hide();

		if(!validateEmail(email)) {

			$('#contact_err_1').stop().fadeIn(1).delay(3000).fadeOut(500);

		} else {

			$.post('inc/contact.php', { email: email, message: message }, function(get) {

				if(get == 1) {

					$('.pop_contact_success_box').stop().fadeIn(1).delay(3000).fadeOut(500);

					$('#contact_email_focus').val('');
					$('#contact_text_focus').val('');

				}

				if(get == 2) {
	
					$('#contact_err_2').stop().fadeIn(1).delay(3000).fadeOut(500);

				}

				if(get == 3) {
	
					$('#contact_err_3').stop().fadeIn(1).delay(3000).fadeOut(500);

				}

				if(get == 4) {
	
					$('#contact_err_4').stop().fadeIn(1).delay(3000).fadeOut(500);

				}


			});

		}

	});

	$(document).on('click', '.social_share_link', function() {
	
		var type_s = $(this).data('type');
		var winHeight = 350;
		var winWidth = 500;

		if(type_s == 'facebook') {
			var url = 'https://www.facebook.com/sharer/sharer.php?display=popup&u='+encodeURIComponent($(this).data('page'));
		}

		if(type_s == 'google') {
			var url = 'https://plus.google.com/share?url='+encodeURIComponent($(this).data('page'));
		}

		if(type_s == 'twitter') {
			var url = 'https://twitter.com/intent/tweet?url='+encodeURIComponent($(this).data('page'));
		}

		if(type_s == 'pinterest') {
			var url = 'http://pinterest.com/pin/create/button/?url='+encodeURIComponent($(this).data('page'))+'&media='+encodeURIComponent($(this).data('media'));
		}

		var winTop = (screen.height / 2) - (winHeight / 2);
		var winLeft = (screen.width / 2) - (winWidth / 2);
		window.open(url, 'sharer', 'top=' + winTop + ',left=' + winLeft + ',toolbar=0,status=0,width=' + winWidth + ',height=' + winHeight);

	});
