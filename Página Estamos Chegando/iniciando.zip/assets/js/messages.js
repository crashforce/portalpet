	
	var msg_limit = 15;

	function get_messages(type) {

		if(type == 1) {
			$('.messages_results').append('<div class="messages_loading"></div>');
		}

		if(typeof $('.messages_results .messages_result:last')[0] != 'undefined') {
			var last = $('.messages_results .messages_result:last').attr('data-id');
		} else {
			var last = '999999999999999999';
		}
			
		$.post('inc/load_conversations.php', { page: last }, function(get) {

			$('#cvs_count').text('('+get.count+')');
			var data = 'data';

			if(typeof get[data] != 'undefined' && get[data].length > 0) {

				$('.messages_results .messages_no_results').remove();

				msg_limit = get[data].length;

				for(i=0;i<=get[data].length-1;i++) {

					if(!$('.messages_results #_msg_'+get[data][i].to)[0]) {

						if(get[data][i].online == 1) {
							var online = '<div class="online_icon"></div>';
						} else {
							var online = '<div class="online_icon offline"></div>';
						}

						if(type > 1) {
							$('.messages_results').append('<div class="messages_result '+get[data][i].unread+'" data-id="'+get[data][i].id+'" id="_msg_'+get[data][i].to+'"><div class="messages_result_pic"><img src="'+get[data][i].pic+'" /></div><div class="messages_result_details"><div class="messages_result_details_name">'+get[data][i].name+'</div>'+online+'<div class="messages_result_details_date">'+get[data][i].date+'</div><div class="messages_result_message">'+get[data][i].message+'</div></div></div>');
						} else {
							$('.messages_results').prepend('<div class="messages_result '+get[data][i].unread+'" data-id="'+get[data][i].id+'" id="_msg_'+get[data][i].to+'"><div class="messages_result_pic"><img src="'+get[data][i].pic+'" /></div><div class="messages_result_details"><div class="messages_result_details_name">'+get[data][i].name+'</div>'+online+'<div class="messages_result_details_date">'+get[data][i].date+'</div><div class="messages_result_message">'+get[data][i].message+'</div></div></div>');
						}

					}

				}

			} else {

				$('.messages_results').append('<div class="messages_no_results">'+lang['messages_no_results']+'</div>');

			}

			$('.messages_results .messages_loading').remove();
			$('.messages_box').perfectScrollbar('update');

		}, 'json');

	}

	$(document).on('click','.messaging, .chat_notifications', function(e) {

		$('.messages').show();
		$('.round_chat').addClass('menu_active');
		$('.round_chat').parent().find('.m_item').addClass('m_item_selected');

		$('.messages_box').scrollTop(0);
		$('.messages_results').html('');

		if(!$('.messages_results .messages_loading')[0]) {

			get_messages('3');

		}

	});

       	$('.messages_box').on('mousewheel', function() {
		
		var position = $('.messages_box .messages_result:last').position().top;

		if(position < 400 && msg_limit == 15) {
			
			if(!$('.messages_results .messages_loading')[0]) {

				get_messages('3');

			}

		}

	});

	$(document).on('click', function(e) {

		var target = e.target;

		if(!$(target).hasClass('round_chat') && !$(target).hasClass('chat_notifications')) {

			if(mobile == 0) {
				$('.messages_results').html('');
				$('.messages').hide();
				$('.round_chat').removeClass('menu_active');
			}

		}

	});
