
	$(document).on('click', '.call_settings', function() {

		window.history.pushState("", "", '/settings');
		$('.settings_pop').show();
	
		$('#current_password, #new_password, #repeat_new_password').val('');
	
		if(mobile == 1) {
			$('.site, .footer').hide();
		} else {
			$('body').css('overflow','hidden');
			$('.settings').css('height',$('.settings_content').height()+8).css('top','0').css('margin','auto');
		}

	});

	$(document).on('click', '.settings_menu_item', function() {

		$('.settings_error_box, .settings_success_box').hide();

		$('.settings_menu_item_selected').removeClass('settings_menu_item_selected');
		$('.settings_contents').hide();

		$(this).addClass('settings_menu_item_selected');

		var page = $(this).attr('data-page');

		$('#settings_'+page).show();

		if(mobile == 0) {
			$('body').css('overflow','hidden');
			$('.settings').css('height',$('.settings_content').height()+8).css('top','0').css('margin','auto');
		}

	});

	$(document).on('click', '.settings_cancel',function() {

		$('.pop_content').click();
		if(mobile == 1) { $('.site, .footer').show(); } else { $('body').css('overflow','auto'); }

	});

	$(document).on('click', '.settings_general_save', function() {

		$('.settings_error_box, .settings_success_box').hide();

		var name = $('#name_field').val();
		var username = $('#username_field').val();
		var email = $('#email_field').val();

		if(name.length < 4) {

			$('#settings_err_1').stop().fadeIn(1).delay(3000).fadeOut(500);

		} else {

			if(!validateEmail(email)) {

				$('#settings_err_2').stop().fadeIn(1).delay(3000).fadeOut(500);

			} else {

				$.post('inc/save_settings.php', { type: '1', name: name, username: username, email: email }, function(get) {

					if(get == 3) {
						$('#settings_err_3').stop().fadeIn(1).delay(3000).fadeOut(500);
					}

					if(get == 2 || get == 0) { 
						$('#settings_err_4').stop().fadeIn(1).delay(3000).fadeOut(500);
					}

					if(get == 1) {

						$('.header_profile_link').data('profileuser', username);
						$('#settings_suc_1').stop().fadeIn(1).delay(3000).fadeOut(500);

					}

				});

			}

		}

	});

	$(document).on('click', '.settings_privacy_save', function() {

		$('.settings_error_box, .settings_success_box').hide();

		var privacy_1 = $('#select_1_field').val();
		var privacy_2 = $('#select_2_field').val();	
		var privacy_3 = $('#select_3_field').val();

		$.post('inc/save_settings.php', { type: '5', privacy_3: privacy_3, privacy_1: privacy_1, privacy_2: privacy_2 }, function(get) {

			if(get == 1) {
				$('#settings_suc_1').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

		});

	});

	$(document).on('click', '.settings_about_save', function() {

		$('.settings_error_box, .settings_success_box').hide();

		var birthday = $('#birthday_field').val();
		var birthmonth = $('#birthmonth_field').val();
		var birthyear = $('#birthyear_field').val();
		var country = $('#country_field').val();
		var city = $('#city_field').val();
		var gender = $('#gender_field').val();
		var desc = $('#desc_field').val();

		var birthdate = birthday+'-'+birthmonth+'-'+birthyear;

		$.post('inc/save_settings.php', { type: '2', desc: desc, gender: gender, birthdate: birthdate, country: country, city: city }, function(get) {

			if(get == 2 || get == 0) { 
				$('#settings_err_4').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

			if(get == 1) {
				$('#settings_suc_1').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

		});

	});

	$(document).on('click', '.settings_social_save', function() {

		$('.settings_error_box, .settings_success_box').hide();

		var facebook = $('#facebook_field').val();
		var twitter = $('#twitter_field').val();
		var google = $('#google_field').val();
		var pinterest = $('#pinterest_field').val();

		$.post('inc/save_settings.php', { type: '3', facebook: facebook, twitter: twitter, google: google, pinterest: pinterest }, function(get) {
			
			if(get == 1) {
				$('#settings_suc_1').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

			if(get == 0) {
				$('#settings_err_4').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

			if(get == 5) {
				$('#settings_err_8').stop().fadeIn(1).delay(3000).fadeOut(500);
			}
	
			if(get == 6) {
				$('#settings_err_9').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

			if(get == 7) {
				$('#settings_err_10').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

			if(get == 8) {
				$('#settings_err_11').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

		});

	});

	$(document).on('click', '.settings_password_save', function() {

		$('.settings_error_box, .settings_success_box').hide();

		var current_pass = $('#current_password').val();
		var new_pass = $('#new_password').val();
		var repeat_new_pass = $('#repeat_new_password').val();

		if(new_pass != repeat_new_pass) {

			$('#settings_err_6').stop().fadeIn(1).delay(3000).fadeOut(500);

		} else {

			if(new_pass.length < 6) {

				$('#settings_err_7').stop().fadeIn(1).delay(3000).fadeOut(500);

			} else {

				$.post('inc/save_settings.php', { type: '4', new: new_pass, current_pass: current_pass }, function(get) {

					if(get == 1) {
						$('#settings_suc_2').stop().fadeIn(1).delay(3000).fadeOut(500);
					}

					if(get == 2) {
						$('#settings_err_5').stop().fadeIn(1).delay(3000).fadeOut(500);
					}

					if(get == 0) {
						$('#settings_err_4').stop().fadeIn(1).delay(3000).fadeOut(500);
					}

					if(get == 5) {
						$('#settings_err_12').stop().fadeIn(1).delay(3000).fadeOut(500);
					}

				});

			}

		}

	});