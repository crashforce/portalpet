
	$(document).on('click', '#about_menu, #photos_menu, #followers_menu, #following_menu', function() {

		$('.user_menu_buttons_scroll').stop().animate({left: $(this).position().left, width: $(this).width()+40},'100');
		$('.user_menu_buttons_scroll').width($(this).width()+40).data('curl', $('.user_menu_buttons_scroll').position().left).data('curw', $('.user_menu_buttons_scroll').width());

	});

	function slide_cover() {

		console.log('load '+Math.floor(new Date().getTime() / 1000));

		var covers_count = 0;

		if(typeof ($('.user_cover').attr('data-cover0')) != 'undefined') {

			if($('.user_cover').attr('data-cover0').length > 1) { covers_count++; }
			if($('.user_cover').attr('data-cover1').length > 1) { covers_count++; }
			if($('.user_cover').attr('data-cover2').length > 1) { covers_count++; }
			if($('.user_cover').attr('data-cover3').length > 1) { covers_count++; }
			if($('.user_cover').attr('data-cover4').length > 1) { covers_count++; }

		}

		var current_slide = $('.user_cover').attr('data-current');

		if(typeof current_slide != 'undefined' || current_slide == '') {

			if(covers_count > 1) {
		
				var old_image = current_slide;
				current_slide++;

				if(current_slide == covers_count) {
					current_slide = 0;
				}

				$('.user_cover').attr('data-current', current_slide);

				var next_image = $('.user_cover').attr('data-cover'+current_slide);

				if(next_image.length > 1) {
					$('.data_cover_'+old_image).fadeTo( "2000", 0 );
					$('.data_cover_'+current_slide).fadeTo('2000','1');
				}

			}

		}

	}

	function load_user(current_id) {

		$.post('inc/load_user.php', { id: current_id }, function(get) {

			$('#_current_id').val(get.id);
			$('#_followerid').val(get.id);
					
			load_photos('x','1');

			if(typeof get.covers.length != 'undefined' && get.covers.length > 0) {

				for(i=0;i<=get.covers.length-1;i++) {
					$('.user_cover').attr('data-cover'+i, get.covers[i]);
					$('.data_cover_'+i).attr('src',site_url+'/uploads/covers/'+get.covers[i]+'.jpg');
					$('.data_cover_'+i).attr('data-cover',get.covers[i]);
				}

				$('.data_cover_0').show().css('opacity','1');

			}

			$('.user_profile_pic').attr('src',get.pic);

			if($('#_loggedid').val() == $('#_current_id').val()) {

				if(get.pic_count == 0) {
					$('.option_1').hide();
					$('.option_2').show();
				} else {
					$('.option_2').hide();
					$('.option_1').show();
				}

				if(mobile == 1) {

					if(get.pic_count == 0) {
						$('.pop_picture_button_2').hide();
						$('.pop_picture_button_1').show();
					} else {
						$('.pop_picture_button_1').hide();
						$('.pop_picture_button_2').show();
					}

				}

			}

		}, 'json');

	}

	$(document).on('click', function(e) {

		var target = e.target;

		if(!$(target).hasClass('user_photo_item_options')) {
			$('.user_photo_item_options_menu').hide();
		}

		if(!$(target).hasClass('pop_covers_box_admin')) {
			$('.pop_covers_box_admin_menu').hide();
		}

	});

	$(document).on('click', '.user_profile_pic', function() {

		if(mobile == 1 && $('#_loggedid').val() == $('#_current_id').val()) {

			$('.pop_picture_menu').show();
			$('body').css('overflow','hidden');

		}

	});
	
	$(document).on('click', '.pop_picture_cancel', function() {

		if(mobile == 1) {
		
			$('.pop_picture_menu').hide();
			$('body').css('overflow','auto');

		}

	});

	$(document).on('click', '.user_photo_item_options', function() {

		if(mobile == 0) {

			if($(this).find('.user_photo_item_options_menu').is(':hidden')) {
				$('.user_photo_item_options_menu').hide();
				$(this).find('.user_photo_item_options_menu').stop().show();
			} else {
				$(this).find('.user_photo_item_options_menu').stop().hide();
			}

		} else {

			$('.pop_user_menu').show();
			$('body').css('overflow','hidden');

			if($(this).data('type') == 1 && mobile == 1) { $('.pop_options_2').show(); $('.pop_options_1').hide(); }
			if($(this).data('type') != 1 && mobile == 1) { $('.pop_options_1').show(); $('.pop_options_2').hide(); }

			$('.pop_user_button_1, .pop_user_button_2').data('eid', $(this).data('jid'));

		}

	});

	$(document).on('click', '.pop_covers_box_admin', function() {

		if($(this).find('.pop_covers_box_admin_menu').is(':hidden')) {
			$('.pop_covers_box_admin_menu').hide();
			$(this).find('.pop_covers_box_admin_menu').stop().show();
		} else {
			$(this).find('.pop_covers_box_admin_menu').stop().hide();
		}

	});

	function load_photos(id,type) {

		reload_footer();

		if($('.user_privacy').val() == 1 && $('#_loggedid').val() != $('#_current_id').val()) {

			$('.user_photos .user_no_results').hide();
			$('.user_photos .user_privacy_results').show();

		} else {

		if(!$('.user_loading')[0] && last_count_photos == 16) {

			$('.user_photos').append('<div class="the_clear">&nbsp;</div><div class="user_loading"></div>');

			$.getJSON('inc/user_photos.php?uid='+$('#_followerid').val()+'&id='+id, function(json){

				last_count_photos = json.length;

				if(json.length == 0) {

					if(type == 1) { $('.user_photos .user_no_results').show(); }

				} else {

					for ( tid = 0; tid <=(json.length)-1; tid++) {
						if(json[tid].id != '') {
							if (!$('#_' + json[tid].url)[0]) {
							
								if($('#_loggedid').val() == $('#_current_id').val()) {
									if(json[tid].type == 1) { var t_type = 'video' } else { var t_type = 'photo'; }
									var logged_data = '<div class="user_photo_item_options" data-jid="'+json[tid].url+'" data-type="'+json[tid].type+'"><div class="user_photo_item_options_menu"><div class="user_photo_item_options_delete" id="del_'+json[tid].url+'" data-type="'+json[tid].type+'">'+lang['user_remove_'+t_type+'']+'</div><div class="user_photo_item_options_edit" id="edit_'+json[tid].url+'" data-type="'+json[tid].type+'">'+lang['user_edit_'+t_type+'']+'</div></div></div><div class="photo_large" data-id="'+json[tid].url+'"></div>';
								} else {
									var logged_data = '<div class="photo_large larger" data-id="'+json[tid].url+'"></div>';
								}

								if(rating_system != 1) {
									var rate_col = '<div class="user_photos_item_stats_views user_rate_1_col">'+json[tid].views+'</div><div class="user_photos_item_stats_votes user_rate_1_col">'+json[tid].votes+'</div><div class="user_photos_item_stats_rating user_rate_1_col">'+json[tid].score+'</div><div class="user_photos_item_stats_comments user_rate_1_col">'+json[tid].comments+'</div>';
								} else {
									var rate_col = '<div class="user_photos_item_stats_views user_rate_2_col">'+json[tid].views+'</div><div class="user_photos_item_stats_votes user_rate_2_col">'+json[tid].votes+'</div><div class="user_photos_item_stats_comments user_rate_2_col">'+json[tid].comments+'</div>';
								}

								if(json[tid].type == 1) {
									var play_icon = '<div class="play_icon play_icon_user" data-id="'+json[tid].url+'"></div>';
								} else {
									var play_icon = '';
								}

								var results = '<div class="user_photos_item" data-id="'+json[tid].url+'" data-type="'+json[tid].type+'" data-lid="'+json[tid].id+'" id="_'+json[tid].url+'" style="background:url('+json[tid].photo+') no-repeat center center">'+play_icon+'<div class="user_photos_item_black">'+json[tid].time+'</div>'+logged_data+'<div class="user_photos_item_stats">'+rate_col+'</div></div>';
								$('.user_photos').append(results);

							}
						}
					}

				}

				$('.user_photos .user_loading, .user_photos .the_clear').remove();
				if($('.pop').is(':hidden')) { $('body').css('overflow','auto'); }

				reload_footer();

			});

		}

		}

	}

	function onScroll(event) {

		var current_user = $('#selected_user').text();

        	var winHeight = window.innerHeight ? window.innerHeight : $(window).height();

		if(mobile == 0) {
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
		} else {
			var closeToBottom = ($(window).scrollTop() >= $(document).height() - $(window).height() - 60);
		}

		if(current_user == 'followers' && $('#_main_now').val() == 'user') {

        		if (closeToBottom) {

				var id = $('.user_followers .user_follow_result:last').data('fid');
				load_follows(id,$('#_followerid').val(),'followers',$('#_loggedid').val());

			}

		}

		if(current_user == 'following' && $('#_main_now').val() == 'user') {

        		if (closeToBottom) {

				var id = $('.user_following .user_follow_result:last').data('fid');
				load_follows(id,$('#_followerid').val(),'following',$('#_loggedid').val());

			}

		}

        	if (current_user == 'photos' && $('#_main_now').val() == 'user') {

			if(closeToBottom) {

				var id = $('.user_photos .user_photos_item:last').data('lid');
				load_photos(id,'2');

			}

		}

	}

	$(document).on('click', '.user_photos_item_black, .user_photos_item_stats', function() {

		$(this).parent().find('.photo_large').click();

	});

	$(window).bind('scroll', onScroll);

	function set_menu(tab) {

		$('#selected_user').text(tab);
		$('body').find('.user_menu_buttons_item_selected').removeClass('user_menu_buttons_item_selected');

		$('#'+tab+'_menu').addClass('user_menu_buttons_item_selected');

	}

	$(document).on('click', '.user_menu_buttons_item', function() {

		var id = $(this).attr('id');
		var new_id = id.replace('_menu','');
		$('.user_tab').hide();

		$('.user_'+new_id).show();

		if(new_id == 'about') {

			window.history.pushState("", "", '/'+$('#_current_user').val()+'/about-me');
			reload_footer();

		}

		if(new_id == 'photos') {

			f_sleep = 0;
			last_count_photos = 16;

			window.history.pushState("", "", '/'+$('#_current_user').val());

			$('.user_photos .user_photos_item').each(function() {
				$(this).remove();
			});

			load_photos('x','1');

		}

		if(new_id == 'followers') {

			f_sleep = 0;
			last_count_follow = 21;
	
			window.history.pushState("", "", '/'+$('#_current_user').val()+'/followers');

			$('.user_followers .user_follow_result').each(function() {
    				$(this).remove();
			});

			load_follows('99999999999999',$('#_followerid').val(),'followers',$('#_loggedid').val());

		}

		if(new_id == 'following') {

			f_sleep = 0;
			last_count_follow = 21;

			window.history.pushState("", "", '/'+$('#_current_user').val()+'/following');
			
			$('.user_following .user_follow_result').each(function() {
    				$(this).remove();
			});


			load_follows('99999999999999',$('#_followerid').val(),'following',$('#_loggedid').val());
		}


		if(mobile == 0) {

			if($('#_ad_728_active').val() == 1) {
				tag_728_90 = $('.user_'+$('#selected_user').text()+' .ad_728_90_home').html();
				$('.user_'+$('#selected_user').text()+' .ad_728_90_home').html('');
				if(tag_728_90.length > 5) {
					$('.user_'+new_id+' .ad_728_90_home').html(tag_728_90);
				}
			}

		}

		set_menu(new_id);

		$('#selected_user').text(new_id);

		if($('.pop').is(':hidden')) { $('body').css('overflow','auto'); }

	});

	var f_sleep = 0;

	function load_follows(id,fid,page,loggedid) {

		reload_footer();

		if(page == 'following') { var query = 'fid'; } else { var query = 'uid'; }

		if(!$('.user_'+page+' .user_loading')[0] && f_sleep == 0 && last_count_follow == 21) {

			f_sleep = 1;

			$('.user_'+page).append('<div class="user_loading"></div>');

			$.getJSON('inc/user_'+page+'.php?id='+id+'&'+query+'='+$('#_followerid').val(), function(json){

				last_count_follow = json.length;

				if(json.length == 0) {

					$('.user_'+page+' .user_no_results').show();

				} else {

					if(json.length < 25) { f_sleep = 1; }

					$('.user_'+page+' .user_no_results').hide();

					for ( tid = 0; tid <=(json.length)-1; tid++) {
						if(typeof json[tid].id != 'undefined') {
							if (!$('.user_'+page+' #fol_' + json[tid].id)[0]) {

								if($('#_loggedid').val() != json[tid].id) {
									var follow_button = '<div class="'+json[tid].follow_2+'" data-uid="'+json[tid].id+'"><div class="follows_op">'+ucwords(json[tid].follow)+'</div><div class="follows_count">'+json[tid].follows_count+'</div></div>';
								} else {
									var follow_button = '';
								}

								var result_data1 = '<div class="user_follow_result" data-fid="'+json[tid].id+'" id="fol_'+json[tid].id+'"><div class="user_follow_result_pic"><img src="'+json[tid].pic+'" class="call_live_profile" data-profileuser="'+json[tid].profileuser+'" /></div><div class="user_follow_result_cover" '+json[tid].background_cover+'>'+follow_button+'</div><div class="user_follow_result_name"><div class="user_follow_result_col_1 call_live_profile" data-profileuser="'+json[tid].profileuser+'">'+json[tid].name+'</div><div class="user_follow_result_verified">'+json[tid].verified+'</div></div></div>';
								$('.user_'+page).append(result_data1);

							}
						}
					}

				}

				$('.user_'+page+' .user_loading').remove();
				f_sleep = 0;

				reload_footer();

			});

		}

	}

	$(document).on('click', '.verify_user_button', function() {

		$.post('inc/verify_user.php', { uid: $('#_current_id').val() }, function(get) {

			if(get == 1) {
				$('#succ_6').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

			if(get == 4) {
				$('#erro_9').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

			if(get == 2) {
				$('#erro_11').stop().fadeIn(1).delay(3000).fadeOut(500);
			}

			close_pops();

		});

	});

	$(document).on('click', '.remove_profile_pic', function() {

		$('.user_profile_pic').attr('src',site_url+'/uploads/profiles/no_profile_pic.jpg');

		$.post('inc/remove_profile_pic.php', function(get) {

			$('.option_1').hide();
			$('.option_2').show();
			$('.profile_pic_small').attr('src',site_url+'/thumbs.php?src=uploads/profiles/no_profile_pic.jpg&w=26&h=26&zc=1');
			$('#succ_4').stop().fadeIn(1).delay(3000).fadeOut(500);

			if(mobile == 1) {
				$('.pop_picture_button_2').hide();
				$('.pop_picture_button_1').show();
				$('.pop_picture_menu').hide();
				$('body').css('overflow','auto');
			}

		});

	});

	
	$(document).on('click', '.upload_profile_pic', function() {

		if(mobile == 1) {
			$('.pop_picture_menu').hide();
			$('body').css('overflow','auto');
		}

		$('#profile_pic').click();

	});

	$('#profile_pic').on("change", function(){

		$('.option_1, .option_2').hide();
		$('.user_head_profile_pic_admin').append('<div class="user_upload_profile_pic"></div>');

		$("#upload_profile_pic").ajaxForm({
				
			clearForm: true,
        		resetForm: true,
			success: function(e) {

				if(e == 2) {

					$('#erro_4').stop().fadeIn(1).delay(3000).fadeOut(500);
					$('.user_head_profile_pic_admin .user_upload_profile_pic').remove();
					$('.option_1').hide();
					$('.option_2').show();

					if(mobile == 1) {
						$('.pop_picture_button_2').hide();
						$('.pop_picture_button_1').show();
					}

				}

				if(e == 3) {

					$('#erro_3').stop().fadeIn(1).delay(3000).fadeOut(500);

					$('.user_head_profile_pic_admin .user_upload_profile_pic').remove();
					$('.option_1').hide();
					$('.option_2').show();

					if(mobile == 1) {
						$('.pop_picture_button_2').hide();
						$('.pop_picture_button_1').show();
					}

				}

				if(e == 4) {

					$('#erro_2').stop().fadeIn(1).delay(3000).fadeOut(500);

					$('.user_head_profile_pic_admin .user_upload_profile_pic').remove();
					$('.option_1').hide();
					$('.option_2').show();

					if(mobile == 1) {
						$('.pop_picture_button_2').hide();
						$('.pop_picture_button_1').show();
					}

				}

				if(e.length > 1) {

					$('.profile_pic_small').attr('src',site_url+'/thumbs.php?src=uploads/profiles/'+e+'.jpg&w=26&h=26&zc=1');

					$('#succ_3').stop().fadeIn(1).delay(3000).fadeOut(500);

					$('.user_head_profile_pic_admin .user_upload_profile_pic').remove();
					$('.option_2').hide();
					$('.option_1').show();

					if(mobile == 1) {
						$('.pop_picture_button_1').hide();
						$('.pop_picture_button_2').show();
					}

					$('.user_profile_pic').attr('src',site_url+'/uploads/profiles/'+e+'.jpg');

				}

			}

		 }).submit();

	});

	$(document).on('click','.user_cover_admin_manage', function() {

		$('.pop').show();
		$('.pop_covers').show();
		$('.pop_covers_details').show();
		$('body').css('overflow','hidden');

		reorder();
	
	});

	$('#cover').on("change", function(){

		var next = 0;
		
		for(j=0;j<=4;j++) {
			
			if($('.user_cover').attr('data-cover'+j).length > 0) {
				next++;
			}

		}

		$('#cover_id').val(next);
		$('#_cover_'+next).addClass('pop_covers_box_uploading');

		$("#upload_cover").ajaxForm({
				
			clearForm: true,
        		resetForm: true,
			success: function(e) {

				$('body').find('.pop_covers_box_uploading').removeClass('pop_covers_box_uploading');

				if(e == 2) {

					$('.pop_covers_error_box').hide();
					$('#_er_1').stop().fadeIn(1).delay(3000).fadeOut(500);

				}

				if(e == 3) {

					$('.pop_covers_error_box').hide();
					$('#_er_2').stop().fadeIn(1).delay(3000).fadeOut(500);
				}

				if(e == 4) {

					$('.pop_covers_error_box').hide();
					$('#_er_3').stop().fadeIn(1).delay(3000).fadeOut(500);

				}

				if(e.length > 1) {

					$('.crop_me').attr('src', 'uploads/covers/'+e+'.jpg');

					$('.crop_me').load(function() {

						$('body').css('overflow','hidden');
						$('.pop_covers').hide();
						$('.user_update_cover').show();

						$('.crop_me').jWindowCrop({
							targetWidth: 1135,
							targetHeight: 300,
							onChange: updateCoords
						});

					});

				}

			}

		}).submit();

	});

	$(document).on('click', '.pop_covers_box_upload', function() {

		if($('.user_cover').attr('data-cover0').length != 0 && $('.user_cover').attr('data-cover1').length != 0 && $('.user_cover').attr('data-cover2').length != 0 && $('.user_cover').attr('data-cover3').length != 0 && $('.user_cover').attr('data-cover4').length != 0) {
			
			$('.pop_covers_error_box').hide();
			$('.pop_covers_success_box').hide();
			$('#_er_4').stop().fadeIn(1).delay(3000).fadeOut(500);

		} else {

			$('#cover').click();

		}
		
	});

	function reorder_covers() {

		var cover_order = [];

		var last = 0;

		for(d=0;d<=4;d++) {

			if($('.user_cover').attr('data-cover'+d).length > 1) {
				cover_order[last] = $('.user_cover').attr('data-cover'+d);
				last++;
			}

		}

		$('.user_cover').attr({'data-cover0':'', 'data-cover1':'', 'data-cover2':'', 'data-cover3':'', 'data-cover4':''});

		$('.cover_slide').each( function() {
			$(this).attr('src','');
			$(this).attr('data-cover','');
		});

		for(e=0;e<=cover_order.length-1;e++) {

			if(cover_order[e].length > 0) {
				$('.user_cover').attr('data-cover'+e, cover_order[e]);
				$('.data_cover_'+e).attr('src',site_url+'/uploads/covers/'+cover_order[e]+'.jpg');
				$('.data_cover_'+e).attr('data-cover',cover_order[e]);
			}

		}

	}

	function reorder() {

		$('.cover_boxes').html('');

		for(k=0;k<=4;k++) {
				
			$('.cover_boxes').append('<div class="pop_covers_box" id="_cover_'+k+'"><div class="pop_covers_box_options"><div class="pop_covers_box_admin"><div class="pop_covers_box_admin_menu"><div class="pop_covers_box_admin_menu_item1" id="_primary_cover_'+k+'">'+lang['user_make_primary']+'</div><div class="pop_covers_box_admin_menu_item2" id="_remove_cover_'+k+'">'+lang['user_remove_cover']+'</div></div></div></div></div>');

		}

		for(c=0;c<=4;c++) {

			if($('.user_cover').attr('data-cover'+c).length > 0) {

				var box_active = $('.user_cover').attr('data-cover'+c);

				$('#_cover_'+c).css({'background':'url('+site_url+'/thumbs.php?src=uploads/covers/'+box_active+'.jpg&w=65&h=65&zc=1) no-repeat'});
				$('#_cover_'+c+' .pop_covers_box_options').addClass('pop_covers_box_options_display');


			}

		}

	}

	$(document).on('click', '.pop_covers_box_admin_menu_item2', function() {

		var id = $(this).attr('id');
		var the_id = id.replace('_remove_cover_','');
		
		$('.user_cover').attr('data-cover'+the_id, '');
		reorder();
		reorder_covers();

		$.post('inc/remove_cover.php', { id: the_id }, function(get) {

			if($('.user_cover').attr('data-cover0').length == 0 && $('.user_cover').attr('data-cover1').length == 0 && $('.user_cover').attr('data-cover2').length == 0 && $('.user_cover').attr('data-cover3').length == 0 && $('.user_cover').attr('data-cover4').length == 0) {

				$('.user_cover').css({'background':'#e1e7ea'});

			}

			reorder();

			$('.pop_covers_error_box').hide();
			$('#_su_2').stop().fadeIn(1).delay(3000).fadeOut(500);

		});

	});

	$(document).on('click', '.pop_covers_box_admin_menu_item1', function() {

		var id = $(this).attr('id');
		var the_id = id.replace('_primary_cover_','');

		$.post('inc/primary_cover.php', { id: the_id }, function(get) {

			for(c=0;c<=get.length-1;c++) {

				$('.user_cover').attr('data-cover'+c, get[c]);

			}
		
			reorder();
			reorder_covers();

			$('.pop_covers_error_box').hide();
			$('#_su_3').stop().fadeIn(1).delay(3000).fadeOut(500);

		}, 'json');

	});

	$(document).on('click', '.user_update_cover_buttons_cancel', function() {

		$('.pop_covers').show();
		$('.user_update_cover').hide();

	});

		
	$(document).on('click', '.user_update_cover_buttons_save', function() {

		$(this).html('<img src="assets/img/loading_2.gif" style="border:0;" />').addClass('user_update_cover_buttons_save_load');

		var cropx = $('#cropx').text();
		var cropy = $('#cropy').text();
		var cropw = $('#cropw').text();
		var croph = $('#croph').text();
		var img = $('.crop_me').attr('src');

		$.post('inc/update_cover.php', { x: cropx, y: cropy, w: cropw, h: croph, img: img }, function(get) {

			$('.pop_covers').show();
			$('.user_update_cover').hide();

			if(get.error == 0) {

				var box_active = $('.user_cover').attr('data-cover'+get.id, get.fit);
				reorder_covers();

				$('#_cover_'+get.id).removeClass('pop_covers_box_uploading');

				$('#_cover_'+get.id).css({'background':'url('+site_url+'/thumbs.php?src=uploads/covers/'+get.fit+'.jpg&w=65&h=65&zc=1) no-repeat'});
				$('#_cover_'+get.id+' .pop_covers_box_options').addClass('pop_covers_box_options_display');

				if(get.id == 0) {
					$('.data_cover_0').show().css('opacity','1');
				}

				$('.pop_covers_error_box').hide();
				$('#_su_1').stop().fadeIn(1).delay(3000).fadeOut(500);

				$('.user_update_cover_buttons_save').html('Save cover').removeClass('user_update_cover_buttons_save_load');

			}

		}, 'json');

	});


	$(document).on('click','.user_photo_item_options_delete, .pop_user_button_1', function() {

		if(mobile == 1) {
			var id = $(this).data('eid');
			$('.pop_user_menu').hide();
			$('body').css('overflow','auto');
		} else {
			var t_id = $(this).attr('id');
			var d_id = t_id.split('_');
			var id = d_id[1];
		}

		var type = $(this).data('type');

		$.post('inc/delete_photo.php', { id: id }, function(get) {

			if(get == 1) {

				if(type == 1) {
					$('#succ_10').stop().fadeIn(1).delay(3000).fadeOut(500);
				} else {
					$('#succ_2').stop().fadeIn(1).delay(3000).fadeOut(500);
				}

				$('.user_photos_item[data\-id="'+id+'"]').fadeOut(300, function() {

					var pnr = $('#pnr').text();
					pnr--;
					$('#pnr').text(pnr);

					if($('#pnr').text() == 0) {
						$('.user_photos .user_no_results').show();
					}

				});

			}

		});

	});

	$(document).on('click','.user_photo_item_options_edit, .pop_user_button_2', function() {

		if($(this).data('type') == 1) {
			$('.pop_edit .pop_box_header .pop_box_title').text(lang['pop_edit_video']);
			$('.pop_edit .pop_box_content .pop_edit_form .pop_edit_form_content .pop_edit_details #pop_edit_description').prop('placeholder', lang['pop_edit_video_desc']);
			$('.pop_edit .pop_box_content .pop_edit_form .pop_edit_form_content .pop_edit_details .pop_edit_photo_buttons .pop_edit_save').text(lang['pop_edit_save_video']).data('type','1');
		} else {
			$('.pop_edit .pop_box_header .pop_box_title').text(lang['pop_edit_photo']);
			$('.pop_edit .pop_box_content .pop_edit_form .pop_edit_form_content .pop_edit_details #pop_edit_description').prop('placeholder', lang['pop_edit_photo_desc']);
			$('.pop_edit .pop_box_content .pop_edit_form .pop_edit_form_content .pop_edit_details .pop_edit_photo_buttons .pop_edit_save').text(lang['pop_edit_save_photo']).data('type','0');
		}

		if(mobile == 1) {
			var the_id = $(this).data('eid');
			$('.pop_user_menu').hide();
			$('body').css('overflow','auto');
		} else {
			var id = $(this).attr('id');
			var the_id = id.replace('edit_','');
		}

		$('.pop, .pop_edit').show();

		if(mobile == 1) { $('.site, .footer').hide(); }

		$('.pop_edit_details').hide();
		$('.pop_edit_form_content').append('<div class="pop_edit_loading"></div>');

		$.post('inc/photo_description.php', { id: the_id }, function(get) {

			$('#pop_edit_description').val(get);
			$('#pop_edit_photo').val(the_id);

			$('.pop_edit_form_content .pop_edit_loading').remove();
			$('.pop_edit_details').show();

		});

	});

    	$('#pop_edit_description').bind('keyup input paste', function() {

        	var limit = 200;  
        	var text = $(this).val();  
        	var chars = text.length;  
  
        	if(chars > limit){  
            		var new_text = text.substr(0, limit);   
            		$(this).val(new_text);  
        	}  

    	}); 

	$(document).on('click', '.pop_edit_cancel', function() {
			
		$('.pop, .pop_edit').hide();

		if(mobile == 1) { $('.site, .footer').show(); }

		$('body').css('overflow','auto');
		$('#pop_edit_description').val('');

	});

	$(document).on('click', '.pop_edit_save', function() {
		
		var desc = $('#pop_edit_description').val();
		var photo = $('#pop_edit_photo').val();
		var type = $(this).data('type');

		$.post('inc/edit_photo.php', { id: photo, desc: desc }, function(get) {

			if(get == '1') {

				var id = get;

				if(type == 1) {
					$('#succ_9').stop().fadeIn(1).delay(3000).fadeToggle(500);
				} else {
					$('#succ_1').stop().fadeIn(1).delay(3000).fadeToggle(500);
				}

				$('.pop, .pop_edit').hide();
				if(mobile == 1) { $('.site, .footer').show(); }
				$('body').css('overflow','auto');
				$('#pop_edit_description').val('');

			} else {

				$('#erro_1').stop().fadeIn(1).delay(3000).fadeOut(500);

				$('.pop, .pop_edit').hide();
				if(mobile == 1) { $('.site, .footer').show(); }
				$('body').css('overflow','auto');
				$('#pop_edit_description').val('');

			}

		});

	});
