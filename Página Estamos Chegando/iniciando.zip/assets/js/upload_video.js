
	$(document).on('click', '#select_video', function() {

		$('.pop').show();
		if(mobile == 0) { $('body').css('overflow','hidden'); }
		$('.pop_upload_video').show();
		$('.pop_upload_video_details').show();
		$('.video_uploaded').stop().html('');
		$('#pop_upload_video_description, #pop_upload_video_url').val('');
		$('.video_upload_list').stop().html('');
		$('.upload_more2').click();
		$('.pop_upload_video_2').hide();
		$('.pop_upload_video_1').show();

		if(mobile == 0) { $('.pop_upload_video').css('height','167px'); }
		if(mobile == 1) { close_mobile_menu(); }
		if(mobile == 1) { $('.main').hide(); }

	});

	$(document).on('click', '.upload_more2', function() {

		var total_more = $('.video_item').length;
		if(total_more < 5) {
			$('.video_upload_list').append('<div class="video_item"><textarea name="video_url" class="pop_upload_video_url" placeholder="'+lang['pop_upload_video_url']+'"></textarea></div>');
			if(total_more == 4) {
				$('.upload_more2').hide();
			}
		}

		if(mobile == 0) {
			var form_height_2 = $('.video_item').length;
			var form_height = (50 * form_height_2) + 116;
			$('.pop_upload_video').css('height',form_height+'px');
		}

	});

	$(document).on('click', '.pop_upload_video_check', function(){

		$('.pop_upload_video_details').hide();
		$('.pop_upload_video_form_content').append('<div class="pop_upload_video_loading"></div>');

		var selected_videos_url = new Array();

		$('.video_upload_list .video_item').each(function() {

			selected_videos_url[selected_videos_url.length] = $(this).find('textarea').val();

		});

		$('#upload_video_error_2').stop().hide();

		$.post('inc/check_video.php', { video_url: selected_videos_url }, function(e) {

			$('.pop_upload_video_form_content .pop_upload_video_loading').remove();

			if(e['files'].length > 0) {

				$('.pop_upload_video_details').show();
				$('.pop_upload_video_1').hide();	
				$('.pop_upload_video_2').show();

				for(i=0;i<=(e['files'].length)-1;i++) {
					$('.video_uploaded').append('<div class="uploaded_video" id="uploaded_'+e['files'][i].url+'" data-video="'+e['files'][i].id+'"><div class="uploaded_video_left"><img src="'+site_url+'/thumbs.php?src=uploads/photos/'+e['files'][i].id+'.jpg&w=80&h=60&zc=1" /></div><div class="uploaded_video_right"><textarea name="description" class="pop_upload_video_description" placeholder="'+lang['pop_upload_video_description']+'"></textarea></div></div>');
				}
					
				if(mobile == 0) {
					var form_height_2 = e['files'].length;
					var form_height = (80 * form_height_2) + 116;
					$('.pop_upload_video').css('height',form_height+'px');
				}


			} else {

				$('#upload_video_error_2').stop().fadeIn(1).delay(3000).fadeOut(500);
				$('.pop_upload_video_details').show();
				$('#pop_upload_video_description, #pop_upload_video_url').val('');
				$('.pop_upload_video_2').hide();
				$('.pop_upload_video_1').show();

			}

		}, 'json');

	});

	$(document).on('click', '.pop_upload_video_cancel', function() {
			
		$('.pop').hide();
		$('.pop_upload_video').hide();
		$('body').css('overflow','auto');
		$('#pop_upload_video_description,#pop_upload_video_url').val('');

		if(mobile == 1 && $('#_main_now').val() != 'home') { $('.main').show(); }

	});

	$(document).on('click', '.pop_upload_video_final', function() {
		
		var selected_videos_id = new Array();
		var selected_videos_desc = new Array();
		var selected_videos_u = new Array();

		$('.video_uploaded .uploaded_video').each(function() {

			var file_id_2 = $(this).attr('id');
			var file_id = file_id_2.replace('uploaded_','');
			var video_u  = $(this).data('video');

			selected_videos_id[selected_videos_id.length] = file_id;
			selected_videos_u[selected_videos_u.length] = video_u;
			selected_videos_desc[selected_videos_desc.length] = $(this).find('textarea').val();

		});

		$.post('inc/upload_video.php', { video_id: selected_videos_id, video_desc: selected_videos_desc, video_u: selected_videos_u }, function(get) {

			if(get.error == 0) {

				for(i=0;i<=(get['files'].length)-1;i++) {

					var id = get['files'][i].id;

					if($('#_loggedid').val() == $('#_current_id').val()) {
						var logged_data = '<div class="user_photo_item_options" data-jid="'+get['files'][i].url+'" data-type="'+get['files'][i].type+'"><div class="user_photo_item_options_menu"><div class="user_photo_item_options_delete" id="del_'+get['files'][i].url+'" data-type="1">'+lang['user_remove_video']+'</div><div class="user_photo_item_options_edit" id="edit_'+get['files'][i].url+'" data-type="1">'+lang['user_edit_video']+'</div></div></div><div class="photo_large" data-id="'+get['files'][i].url+'"></div>';
					} else {
						var logged_data = '<div class="photo_large larger" data-id="'+get['files'][i].url+'"></div>';
					}
	
					if($('#_loggedid').val() == $('#_current_id').val()) {

						$('.user_photos .user_no_results').hide();

						if(rating_system != 1) {
							var rate_col = '<div class="user_photos_item_stats_views user_rate_1_col">0</div><div class="user_photos_item_stats_votes user_rate_1_col">0</div><div class="user_photos_item_stats_rating user_rate_1_col">0</div><div class="user_photos_item_stats_comments user_rate_1_col">0</div>';
						} else {
							var rate_col = '<div class="user_photos_item_stats_views user_rate_2_col">0</div><div class="user_photos_item_stats_votes user_rate_2_col">0</div><div class="user_photos_item_stats_comments user_rate_2_col">0</div>';
						}

						var play_icon = '<div class="play_icon play_icon_user" data-id="'+get['files'][i].url+'"></div>';
					
						var results = '<div class="user_photos_item" data-id="'+get['files'][i].url+'" id="_'+get['files'][i].url+'" style="background:url('+get['files'][i].photo+') no-repeat center center">'+play_icon+''+logged_data+'<div class="user_photos_item_black">'+get['files'][i].time+'</div><div class="user_photos_item_stats">'+rate_col+'</div></div>';
						if($('.user_photos')[0]) {
							$('.user_photos').prepend(results);
						}

						var first_one = $('.user_photos .user_photo_item:first');
				
						$(first_one).hide();
						$(first_one).fadeIn(1000);

					}

				}

				var pnr = $('#pnr').text();
				for(j=1;j<=get['files'].length;j++) {
					pnr++;
				}

				$('#pnr').text(pnr);

				$('#succ_8').stop().fadeIn(1).delay(2000).fadeToggle(500);

				$('.pop').hide();
				$('.pop_upload_video').hide();
				$('body').css('overflow','auto');

			} else {

				$('#erro_8').stop().fadeIn(1).delay(2000).fadeOut(500);

				$('.pop').hide();
				$('.pop_upload_video').hide();
				$('body').css('overflow','auto');
				$('#pop_upload_video_description').val('');

			}

		}, 'json');

	});

    	$('#pop_upload_video_description').bind('keyup input paste', function() {

        	var limit = 200;  
        	var text = $(this).val();  
        	var chars = text.length;  
  
        	if(chars > limit){  
            		var new_text = text.substr(0, limit);   
            		$(this).val(new_text);  
        	}  

    	});  
