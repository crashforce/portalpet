
	$(document).on('click', '.browse_filters_list_filter', function() {

		if($(this).attr('id') == 'filter_3_0') {
			var filter_3 = 0;
		}

		if($(this).attr('id') == 'filter_3_1') {
			var filter_3 = 1;
		}

		if($(this).attr('id') == 'filter_3_2') {
			var filter_3 = 2;
		}

		$('#filter_3_0, #filter_3_1, #filter_3_2').find('.browse_filters_list_checkbox_selected').removeClass('browse_filters_list_selcheck');
		$('#filter_3_0, #filter_3_1, #filter_3_2').find('.browse_filters_list_check_name').removeClass('browse_filters_list_name_sel');

		$(this).find('.browse_filters_list_checkbox_selected').addClass('browse_filters_list_selcheck');
		$(this).find('.browse_filters_list_check_name').addClass('browse_filters_list_name_sel');

		$('#_filter_3').val(filter_3);

		$('.browse').html('');
	
		load_browse('0','1','1',filter_3);

	});

	function load_browse(id,type,first,filter) {
	
		reload_footer();

		if(type == 1) { $('.loading_browse').show(); }

		$.post('inc/load_browse.php', { id: id, filter: filter }, function(json) {

			browse_limit = json.length;

			if(json.length == 0) {

				$('.loading_browse').hide();
				if(first == 1) { $('.no_browse').show(); }

			} else {

				$('.no_browse').hide();

				for(tid=0;tid<=(json.length)-1;tid++) {
					if(json[tid].id != '') {

						if(!$('#_browse_'+json[tid].url)[0]) {

							if(rating_system != 1) {
								var rate_col = '<div class="browse_item_stats_views feed_rate_1_col">'+json[tid].views+'</div><div class="browse_item_stats_votes feed_rate_1_col">'+json[tid].votes+'</div><div class="browse_item_stats_rating feed_rate_1_col">'+json[tid].score+'</div><div class="browse_item_stats_comments feed_rate_1_col">'+json[tid].comments+'</div>';
							} else {
								var rate_col = '<div class="browse_item_stats_views feed_rate_2_col">'+json[tid].views+'</div><div class="browse_item_stats_votes feed_rate_2_col">'+json[tid].votes+'</div><div class="browse_item_stats_comments feed_rate_2_col">'+json[tid].comments+'</div>';
							}

							if(json[tid].type == 1) {
								var play_icon = '<div class="play_icon play_icon_feed" data-id="'+json[tid].url+'"></div>';
							} else {
								var play_icon = '';
							}

							var results = '<div class="browse_item" data-uid="'+json[tid].time_count+'" data-lid="'+json[tid].id+'" id="_browse_'+json[tid].url+'">'+play_icon+'<div class="browse_item_pic"><img src="'+json[tid].photo+'" class="browse_img" id="browse_img_'+json[tid].url+'" /></div><div class="browse_item_stats">'+rate_col+'</div><div class="browse_item_info"><div class="browse_item_info_arrow"></div><div class="browse_item_info_details"><div class="browse_item_info_avatar"><img src="'+json[tid].uphoto+'" class="call_live_profile" data-profileuser="'+json[tid].profileuser+'" /></div><div class="browse_item_info_data"><div class="browse_item_info_data_name call_live_profile" data-profileuser="'+json[tid].profileuser+'">'+json[tid].name+'</div><div class="browse_item_info_data_time">'+json[tid].time+'</div></div></div></div></div>';
							$('.browse').append(results);

						}

					}
				}

			}

			$('.loading_browse').hide();

			if($('.pop').is(':hidden')) { $('body').css('overflow','auto'); }
			reload_footer();

		}, 'json');

	}

       	function onScroll(event) {

          	var winHeight = window.innerHeight ? window.innerHeight : $(window).height();

		if(mobile == 0) {
			var closeToBottom = ($(window).scrollTop() == $(document).height() - $(window).height());
		} else {
			var closeToBottom = ($(window).scrollTop() >= $(document).height() - $(window).height() - 60);
		}
        				
		if (closeToBottom && $('#_main_now').val() == 'browse' && browse_limit == 15) {

			$('.loading_browse').show();
			var filter_3 = $('#_filter_3').val();
			var id = $('.browse .browse_item:last').data('lid');
			load_browse(id,'1','2',filter_3);

		}

      	};

        $(window).bind('scroll', onScroll);
