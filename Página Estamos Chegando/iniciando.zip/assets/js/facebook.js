
	$(document).on('click','.pop_join_social_facebook, .pop_login_social_facebook, .home_2_join_social_facebook', function() {
  	
		var cb = function(response) {
    
			if (response.status === 'connected') {
      
				FB.api('/me', function(response) {
      	
					$.post('inc/facebook.php', { response: response }, function(data) {

						if(data['error'] == 0) {

							update_header(1,data['logged'],data['profile']);
							$('#_logged').val(1);
							$('#_loggedid').val(data['id']);
							load_settings_box();
							load_live_page('feed');

						}				

					}, 'json');
    
				});

			}

		};

		FB.login(cb, { scope: 'email' });
  
	});