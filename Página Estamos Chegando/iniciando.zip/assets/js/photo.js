
	var live_comments = null;
	var com_limit = 10;

	function load_comments(id,page,status) {

		if(status == 'live') {

			$.getJSON('inc/comments.php?id='+id+'&page=0&live=1', function(get) {

				if(get.length > 0) { 

					for(i=0;i<=get.length-1;i++) {

						if(!$('#comment_'+get[i].id)[0]) {

							if(get[i].mine == 1 && remove_comment_option == 1) {
								var comment_remove = '<div style="float:left;color:#ccc;">&nbsp;&nbsp;-&nbsp;&nbsp;</div><div class="comment_remove" data-id="'+get[i].id+'">'+lang['remove_comment']+'</div>';
							} else {
								var comment_remove = '';
							}

							var results = '<div class="comment" id="comment_'+get[i].id+'"><div class="comment_pic"><a href="'+get[i].profile+'"><img src="'+get[i].pic+'" /></a></div><div class="left"><div class="comment_details"><div class="comment_name"><a href="'+get[i].profile+'">'+get[i].name+'</a></div>'+get[i].verified+'</div><div class="clearfix"></div><div class="comment_msg">'+get[i].msg+'</div><div class="comment_options"><div class="comment_date">'+get[i].time+'</div>'+comment_remove+'</div></div></div>';
							$(results).hide().fadeIn(1500).prependTo('#comments');

							var old = $('.photo_stats_comments_count').text();
							$('.photo_stats_comments_count').text(++old);

						}

					}

				}
	
			});

		} else {

			var check = $('#no_comments').text();

			$.getJSON('inc/comments.php?id='+id+'&page='+page, function(get) {

				com_limit = get.length;

				if(get.length > 0) { 

					for(i=0;i<=get.length-1;i++) {

						if(!$('#comment_'+get[i].id)[0]) {

							if(get[i].mine == 1 && remove_comment_option == 1) {
								var comment_remove = '<div style="float:left;color:#ccc;">&nbsp;&nbsp;-&nbsp;&nbsp;</div><div class="comment_remove" data-id="'+get[i].id+'">'+lang['remove_comment']+'</div>';
							} else {
								var comment_remove = '';
							}

							$('#comments').append('<div class="comment" id="comment_'+get[i].id+'"><div class="comment_pic"><img src="'+get[i].pic+'" class="call_live_profile" data-profileuser="'+get[i].profileuser+'" /></div><div class="left"><div class="comment_details"><div class="comment_name call_live_profile" data-profileuser="'+get[i].profileuser+'">'+get[i].name+'</div>'+get[i].verified+'</div><div class="clearfix"></div><div class="comment_msg">'+get[i].msg+'</div><div class="comment_options"><div class="comment_date">'+get[i].time+'</div>'+comment_remove+'</div></div></div>');
						}

					}
	
					if(page != 0) { $('#comments_page').text(page); }

				} else {
		
					$('#no_comments').text('1');

				}

				$('#comments #comments_loading').remove();

			});

		}

		if(mobile == 0) { $('#comments_area').perfectScrollbar('update'); }

	}

	$(document).on('click', '.comment_remove', function() {

		var id = $(this).data('id');
		
		$.post('inc/remove_comment.php', { id: id }, function(get) {

			var old = $('.photo_stats_comments_count').text();
			old--;
			$('.photo_stats_comments_count').text(old);

			if(get == 1) { $('#comment_'+id).fadeOut(500); }

		});

	});

	$(document).on('click','.photo_comments_submit', function() {

		var msg = $('#photo_comments_new').val();	
		var to = $('.pop').attr('id');

		var test_msg = msg.replace(/ /g,'');

		if(test_msg.length > 0) {

			$.post('inc/new_comment.php', { to: to, msg: msg }, function(get) {

				if(get.error == 3) {
					alert(lang.spam_filter);
				} else {

					if(get.error == 0 && !$('#comment_'+get.id)[0]) {

						if(remove_comment_option == 1) {
							var comment_remove = '<div style="float:left;color:#ccc;">&nbsp;&nbsp;-&nbsp;&nbsp;</div><div class="comment_remove" data-id="'+get.id+'">'+lang['remove_comment']+'</div>';
						} else {
							var comment_remove = '';
						}

						var results = '<div class="comment" id="comment_'+get.id+'"><div class="comment_pic call_live_profile" data-profileuser="'+get.profileuser+'"><img src="'+get.pic+'" /></div><div class="left"><div class="comment_details"><div class="comment_name call_live_profile" data-profileuser="'+get.profileuser+'">'+get.name+'</div></div><div class="clearfix"></div><div class="comment_msg">'+get.msg+'</div><div class="comment_options"><div class="comment_date">'+get.time+'</div>'+comment_remove+'</div></div></div>';
						$(results).hide().fadeIn(1500).prependTo('#comments');

					}

					$('#photo_comments_new').val('').focus();
					$('#comments_area').scrollTop(0);
					if(mobile == 0) { $('#comments_area').perfectScrollbar('update'); }

					var old = $('.photo_stats_comments_count').text();
					$('.photo_stats_comments_count').text(++old);

				}

			}, 'json');

		}
	
	});

	$(document).keydown(function(e){
    
		var ch = $('.pop').attr('id');
		if(typeof ch != 'undefined') {

			if(e.which == 37) {

				if($('.photo_nav_left').attr('id') != '') {
        				$('.photo_nav_left').click();
				}
    	
			} else if(e.which == 39) { 

				if($('.photo_nav_right').attr('id') != '') {
					$('.photo_nav_right').click();
				}
    
			}

		}

	});

	$(document).on('click', '.share_button', function() {
		
		if($('.share_button_options').is(':hidden')) {
			$('.share_button_options').show();
		} else {
			$('.share_button_options').hide();
		}

	});

	function load_photo(id) {

		if($('#_logged').val() == 1) {
			if(mobile == 1) {
				$('.photo_comments_type').show();
			} else {
				$('.photo_add_comment').show();
			}
		} else {
			if(mobile == 1) {
				$('.photo_comments_type').hide();
			} else {
				$('.photo_add_comment').hide();
			}
		}

		$('.photo_display .youtube-player').remove();

		if(!$('#progress')[0]) {
			$("body").append($("<div><dt/><dd/></div>").attr("id", "progress"));
			$("#progress").width((50 + Math.random() * 30) + "%");
		}

		if(mobile == 0) { $('body').css('overflow','hidden'); } else { $('.photo').scrollTop(0); }
		$('.pop').attr('id',id);
		
		$('.photo_display').css('background','#f7f7f7');
		$('.view_fullsize').html('');
		$('.report_button').removeClass('reported');

		$.getJSON('inc/load_photo.php?id='+id+'&m='+mobile, function(get) {

			if(get.rate_status == 1) { $('.photo_ratings').stop().show(); } else { $('.photo_ratings').stop().hide(); }
			$('.photo_rate_message').hide();

			$('.share_button_options').html(get.p_social);

			if(get.type == 0) {
				window.history.pushState("", "", '/photos/'+id);
				$('.fullsize_button').html(get.p_fullsize).show();
				$('.buttons_space_2').show();
			} else {
				window.history.pushState("", "", '/videos/'+id);
				$('.view_fullsize, .fullsize_button').html(get.p_fullsize).hide();
				$('.buttons_space_2').hide();
			}

			if(rating_system == 1) {
				$('.like_button').data('status',get.rate_status);
				if(get.rate_status == 1) {
					$('.like_button').text(lang['like_button']);
				} else {
					$('.like_button').text(lang['unlike_button']);
				}
			}

			if(report_setting == 1) {
				$('.report_button').data('type',get.type);
			}

			if(get.type == 0) {

				if(mobile == 0) {
			
					$('.photo_display').append('<div class="pop_photo_loading"></div>');

					if($('.pop_photo_display')[0]) {
						$('.photo_display .pop_photo_display').remove();
						$('.photo_display').append('<img class="pop_photo_display" />');
					} else {
						$('.photo_display').append('<img class="pop_photo_display" />');
					}

					$('.pop_photo_display').stop().attr('src', 'uploads/photos/'+get.p_photo+'.jpg').load(function() {
						$('.photo_display .pop_photo_loading').remove();
						$('.photo_display').stop().css('background', 'url("uploads/photos/'+get.p_photo+'.jpg") no-repeat scroll center center #f7f7f7').fadeIn(1);
						$('.photo_display').stop().css({ 'background-size':'contain' });
					});

				} else {
					$('#pop_photo_src').attr('src','thumbs.php?src=uploads/photos/'+get.p_photo+'.jpg&w=320');
				}

			} else {

				if(mobile == 0) {

					$('.photo_display').prepend('<iframe width="'+video_size_w+'" class="youtube-player" type="text/html" height="'+video_size_h+'" src="https://www.youtube.com/embed/'+get.p_photo+'?theme='+video_skin+'&wmode=transparent" wmode="opaque" frameborder="0" allowfullscreen style="margin:auto;left:0;bottom:0;right:0;top:0;position:absolute;"></iframe>');

				} else {

					$('.photo_display').prepend('<iframe width="320" class="youtube-player" type="text/html" height="250" src="https://www.youtube.com/embed/'+get.p_photo+'?theme='+video_skin+'&wmode=transparent" wmode="opaque" frameborder="0" allowfullscreen></iframe>');
				
				}

			}
			
			$('.comments_login').css('margin-top','0px');

			$('.photo_description').html(get.p_desc);
			var height_v = 410 - $('.photo_description').height() - $('.photo_main_options').height();

			if(get.p_desc == '' || get.p_desc.length < 1) {
				var height_y = 390 - $('.photo_main_options').height() - 30;
				$('.photo_description').css('border-bottom','0px solid #e1e1e1');
				$('.comments_login').css('margin-top','10px');
				$('.photo_description').hide();
				$('.comments_login').css('height',height_y);
			} else {
				$('.photo_description').css('border-bottom','1px solid #e1e1e1');
				$('.photo_description').show();
				$('.comments_login').css('height',height_v - 68);
			}

			if($('#_logged').val() == 0) {
				$('.comments_login').css('height', $('.comments_login').height() + 62);
			}

			$('.pop_photo_name').html('<span class="call_live_profile" data-profileuser="'+get.profileuser+'">'+get.u_name+'</span>');
			$('.pop_photo_time').text(get.u_time);

			$('.photo_stats_views_count').text(get.p_views);
			$('.photo_stats_votes_count').text(get.p_votes);
			$('.photo_stats_score_count').text(get.p_score);
			$('.photo_stats_comments_count').text(get.p_comments);

			$('.photo_details_author_pic img').attr('src',get.u_pic).data('profileuser', get.profileuser);

			if(get.p_nright != '') {
				$('.photo_nav_left').attr('id','n_'+get.p_nright);
				$('.photo_nav_left').show();
			} else {
				$('.photo_nav_left').attr('id','');
				$('.photo_nav_left').hide();
			}

			if(get.p_nleft != '') {
				$('.photo_nav_right').attr('id','n_'+get.p_nleft);
				$('.photo_nav_right').show();
			} else {
				$('.photo_nav_right').attr('id','');
				$('.photo_nav_right').hide();
			}


			$('#comments').html('');
			$('#comments').stop().prepend('<div id="comments_loading"></div>');

			if(mobile == 0) {
				$('#comments').scrollTop(0);
			 	$('#comments').perfectScrollbar(); 
			}

			load_comments(id,'0','x');

			$("#progress").width("101%").delay(100).fadeOut(200, function() {
        			$(this).remove();
    			});

		});

		live_comments = setInterval(function () { load_comments(id,'x','live'); }, 5000); 

	}

	if(mobile == 0) {

       		$('#comments').on('mousewheel', function() {
		
			var position = $('#comments .comment:last').position().top;

			if(position < 400 && com_limit == 10) {

				var page = $('#comments_page').text();
				var id = $('.pop').attr('id');

				if(!$('#comments #comments_loading')[0]) {

					$('#comments').append('<div id="comments_loading"></div>');
					load_comments(id,++page,'x');

				}

			}

      		});

	}

	$(document).on('click', '.report_button', function() {

		var pid = $('.pop').attr('id');
		var type = $(this).data('type');

		$.post('inc/report.php', { pid: pid, type: type }, function(get) {

			if(get == 1) {

				$('.report_button').addClass('reported');

			}

		});

	});

	function onScroll(event) {

		var current_user = $('#selected_user').text();

        	var winHeight = window.innerHeight ? window.innerHeight : $(window).height();
		var closeToBottom = ($(window).scrollTop() >= $(document).height() - $(window).height() - 60);

		if(closeToBottom && com_limit == 10) {

			var page = $('#comments_page').text();
			var id = $('.pop').attr('id');

			if(!$('#comments #comments_loading')[0]) {

				$('#comments').append('<div id="comments_loading"></div>');
				load_comments(id,++page,'x');

			}

		}

	}

	if(mobile == 1) { $(window).bind('scroll', onScroll); }
