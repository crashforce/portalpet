
	<div class="pages">

		<div class="pages_box">

			<div class="pages_box_title_2">
				<div class="pages_box_title"></div>
				<?php if($settings['ad_468_15']!='') { ?><div class="users_ads_468_15"></div><?php } ?>
			</div>
			<div class="pages_box_content">

				<div class="pages_box_content_about page_content" id="_page_about"><?=$settings['about_page'];?></div>	
				<div class="pages_box_content_faq page_content" id="_page_faq"><?=$settings['faq_page'];?></div>
				<div class="pages_box_content_terms page_content" id="_page_terms"><?=$settings['terms_page'];?></div>
				<div class="pages_box_content_privacy page_content" id="_page_privacy"><?=$settings['privacy_page'];?></div>
		
			</div>
	
		</div>

		<div class="right_side_pages">

			<?php if($settings['ad_300_250']!='') { ?><div class="ad_300_250"></div><?php } ?>

			<div class="menu_box">

				<div class="menu_box_item menu_page_about unselect" data-page="about"><?=$lang['pages_about'];?></div>
				<div class="menu_box_item menu_page_faq unselect" data-page="faq"><?=$lang['pages_faq'];?></div>
				<div class="menu_box_item menu_page_terms unselect" data-page="terms"><?=$lang['pages_terms'];?></div>
				<div class="menu_box_item menu_page_privacy unselect" data-page="privacy"><?=$lang['pages_privacy'];?></div>

			</div>

		</div>

	</div>