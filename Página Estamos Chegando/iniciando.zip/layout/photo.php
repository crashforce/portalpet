
		<div class="photo_nav_left unselect"></div>
		<div class="photo_nav_right unselect"></div>

		<div class="pop_photo">

			<div class="close_photo">x</div>

			<div class="photo">

				<div class="photo_display unselect">

					<?php if(isset($_COOKIE['logged']) && $settings['rating_system'] != 1) { ?>
					<div class="photo_rate_message photo_rate_message_success"><?=$lang['photo_rating_success'];?></div>
					<div class="photo_rate_message photo_rate_message_error"><?=$lang['photo_rating_error'];?></div>
					<div class="photo_ratings tooltip" title="<?=$lang['photo_your_rate'];?>">
						<?php for($b=10;$b>0;$b--) { echo '<div id="rate_'.$b.'" class="photo_ratings_rate">'.$b.'</div>'; } ?>		
					</div>
					<?php } ?>

				</div>
		
				<div class="photo_details">

					<div class="photo_details_author">

						<div class="photo_details_author_pic">	
							<img class="call_live_profile" data-profileuser="" />
						</div>

						<div class="photo_details_author_data">
							<div class="pop_photo_name"></div>
							<div class="pop_photo_time"></div>		
						</div>

					</div>	

					<div class="photo_stats unselect">
						<?php if($settings['rating_system'] == 1) { ?>
						<div class="photo_stats_views rate_2_col">
							<div class="photo_stats_views_count"></div>
							<div class="photo_stats_text"><?=$lang['photo_views_count'];?></div>
						</div>
						<div class="photo_stats_votes rate_2_col">
							<div class="photo_stats_votes_count"></div>
							<div class="photo_stats_text"><?=$lang['photo_likes_count'];?></div>
						</div>
						<div class="photo_stats_comments rate_2_col">
							<div class="photo_stats_comments_count"></div>
							<div class="photo_stats_text"><?=$lang['photo_comments_count'];?></div>
						</div>
						<?php } else { ?>
						<div class="photo_stats_views rate_1_col">
							<div class="photo_stats_views_count"></div>
							<div class="photo_stats_text"><?=$lang['photo_views_count'];?></div>
						</div>
						<div class="photo_stats_votes rate_1_col">
							<div class="photo_stats_votes_count"></div>
							<div class="photo_stats_text"><?=$lang['photo_votes_count'];?></div>
						</div>
						<div class="photo_stats_score rate_1_col">
							<div class="photo_stats_score_count"></div>
							<div class="photo_stats_text"><?=$lang['photo_score_count'];?></div>
						</div>
						<div class="photo_stats_comments rate_1_col">
							<div class="photo_stats_comments_count"></div>
							<div class="photo_stats_text"><?=$lang['photo_comments_count'];?></div>
						</div>
						<?php } ?>
					</div>
				
					<div class="photo_description"></div>
	
					<?php if($settings['rating_system'] == 1 || $settings['social_photos'] == 1 || $settings['report_setting'] == 1 || $settings['fullsize_photos'] == 1) { ?>
					<div class="photo_main_options unselect" style="display:block;">
						<?php if($settings['rating_system'] == 1) { ?>
						<div class="like_button buttons_type_1" data-status=""><?=$lang['like_button'];?></div>
						<?php if($settings['social_photos'] == 1) { ?><div class="buttons_space">-</div><?php } ?>
						<?php } ?>
						<?php if($settings['social_photos'] == 1) { ?>
						<div class="share_button buttons_type_1">
							<?=$lang['photo_social'];?>
							<div class="share_button_options"></div>
						</div>
						<?php } ?>
						<?php if($settings['report_setting'] == 1) { ?>
						<div class="report_button buttons_type_2"><?=$lang['photo_report'];?></div>
						<?php if($settings['fullsize_photos'] == 1) { ?><div class="buttons_space buttons_space_2">-</div><?php } ?>
						<?php } ?>
						<?php if($settings['fullsize_photos'] == 1) { ?>
						<div class="fullsize_button buttons_type_2"><?=$lang['photo_fullsize'];?></div>
						<?php } ?>
					</div>
					<?php } ?>

					<?php if(isset($_COOKIE['logged'])) { ?>
					<div class="photo_add_comment">
						<form action="javascript:void(0);" method="post">
							<input name="msg" type="text" size="10" id="photo_comments_new" placeholder="<?=$lang['photo_new_comment'];?>" />	
							<input name="submit" type="submit" class="photo_comments_submit" value="" />
						</form>
					</div>
					<?php } ?>

					<div class="photo_comments">

						<div id="comments_page">0</div>
						<div id="no_comments">0</div>

						<div class="comments_login" id="comments_area">
							<div id="comments"></div>
						</div>

					</div>
					
				</div>
			</div>

		</div>
		