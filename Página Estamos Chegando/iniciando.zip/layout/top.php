		<div class="header">

			<div class="logo unselect <?php if(isset($_COOKIE['logged']) && is_numeric($_COOKIE['logged'])) { echo 'call_live_feed'; } else { echo 'call_live_home'; } ?>"><div class="sub_logo"><?php echo $settings['logo_text']; ?></div></div>

			<div class="header_user_logged <?php echo 'cp_'.$settings['custom_3'].'_hover' ;?>" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?>>
				<img src="<?php if(isset($_COOKIE['logged'])) { echo get_current_host().'/picture/'.$_COOKIE['logged'].'/35/35'; } ?>" class="header_user_logged_pic" />
				<div class="user_menus_load"></div>
				<div class="user_menus">
					<div class="user_menus_item <?php echo 'cp_'.$settings['custom_3'].'_hover' ;?> unselect call_live_profile header_profile_link" data-profileid="<?php if(isset($_COOKIE['logged'])) { echo $_COOKIE['logged']; } ?>" data-profileuser="<?php if(isset($_COOKIE['logged_user'])) { echo $_COOKIE['logged_user']; } ?>"><div class="user_menus_item_link"><?=$lang['header_menu_profile'];?></div></div>
					<div class="user_menus_item unselect call_settings"><div class="user_menus_item_link <?php echo 'cp_'.$settings['custom_3'].'_hover' ;?>"><?=$lang['header_menu_settings'];?></div></div>
					<div class="user_menus_item unselect user_menus_item_last"><div class="user_menus_item_link <?php echo 'cp_'.$settings['custom_3'].'_hover' ;?> call_live_logout"><?=$lang['header_menu_logout'];?></div></div>
				</div>
			</div>

			<div class="menu">
	
				<?php if($settings['custom_4'] == 1 && $settings['video'] == 1) { ?>
				<div class="upload_plus unselect <?php echo 'cp_'.$settings['custom_2'];?>" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;position:relative;"'; } else { echo 'style="position:relative;"'; } ?> id="select_upload" title="<?=$lang['header_menu_photo'];?>">
					<div class="round2 round2_upload"></div>
					<div class="upload_menus">
						<div class="upload_menus_item unselect" id="select_photo"><div class="upload_menus_item_link upload_menu_1 <?php echo 'cp_'.$settings['custom_2'].'_hover' ;?>"><?=$lang['header_menu_new_photo'];?></div></div>
						<div class="upload_menus_item upload_menus_item_last unselect" id="select_video"><div class="upload_menus_item_link upload_menu_2 <?php echo 'cp_'.$settings['custom_2'].'_hover' ;?>"><?=$lang['header_menu_new_video'];?></div></div>
					</div>
				</div>
				<?php } else { ?>
				<?php if($settings['video'] == 1) { ?>
				<div class="upload_video unselect<?php echo ' cp_'.$settings['custom_2'];?>" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?> id="select_video" title="<?=$lang['pop_upload_video_title'];?>"><div class="round2 round2_video"></div></div>
				<?php } ?>
				<div class="upload unselect<?php echo ' cp_'.$settings['custom_2'];?>" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?> id="select_photo" title="<?=$lang['header_menu_photo'];?>"><div class="round2 round2_photo"></div></div>
				<?php } ?>
				<div class="m_item searching unselect" title="<?=$lang['header_menu_search'];?>" style="position:relative;">
					<div class="round round_search"></div>
					
					<div class="search">

						<div style="position:relative;" class="the_search">

						<form autocomplete="off" action="javascript:void(0);" method="post">
							
							<div class="search_box">
								<div class="left"><input type="text" id="search" placeholder="<?=$lang['header_search_text'];?>" /></div>
							</div>

							<input type="hidden" id="sleep" value="" />
							<input type="hidden" id="searchf" value="" />

						</form>

						<div class="search_results"></div>

						</div>
	
					</div>
				</div>
				<div class="m_item m_item_1 call_live_feed unselect" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?> title="<?=$lang['header_menu_feed'];?>"><div class="round round_feed"></div></div>

				<div class="m_item m_item_2 messaging unselect" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;position:relative;"'; } ?> title="<?=$lang['header_menu_chat'];?>" style="position:relative;">

					<div class="round round_chat"></div>

					<div class="chat_notifications"></div>

					<div class="messages">

						<div class="conversations_title"><?=$lang['header_menu_chat'];?> <span id="cvs_count"></span></div>

						<div class="messages_box">
							<div class="messages_results"></div>
						</div>

					</div>

				</div>
				<div class="m_item m_item_3 activitytab unselect" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;position:relative;"'; } ?> title="<?=$lang['header_menu_activity'];?>" style="position:relative;">

					<div class="round round_activity"></div>

					<div class="activity_notifications"></div>

					<div class="activity_tab">

						<div class="activitys_tab_pages">0</div>

						<div class="activity_title"><?=$lang['header_menu_activity'];?> <span id="act_count"></span></div>

						<div class="activity_box">
							<div class="activity_results"></div>
						</div>

					</div>

				</div>
				<div class="m_item unselect call_live_browse" title="<?php if($settings['video'] == 1) { echo $lang['browse_title_posts']; } else { echo $lang['browse_title_photos']; } ?>"><div class="round round_browse"></div></div>
				<div class="m_item unselect call_live_users" title="<?=$lang['header_menu_users'];?>"><div class="round round_users"></div></div>
				<div class="m_item unselect invite" onclick="FacebookInviteFriends()" title="<?=$lang['header_menu_invite'];?>"><div class="round round_invite"></div></div>
				<div class="m_item m_item_4 unselect" <?php if(isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?> title="<?=$lang['header_menu_login'];?>" id="login_but"><div class="round round_login"></div></div>
				<div class="m_item m_item_5 unselect" <?php if(isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?> title="<?=$lang['header_menu_join'];?>" id="join_but"><div class="round round_join"></div></div>

			</div>


		</div>