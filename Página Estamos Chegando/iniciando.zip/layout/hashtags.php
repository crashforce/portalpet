	<div class="hashtags_page">
	
		<div class="hashtags_left">

			<div class="hashtags_buttons_list">
	
				<div class="hashtags_buttons_list_content">
					<div class="hashtags_button hashtags_button_s unselect" id="hashtags"></div>
				</div>
				<?php if($settings['ad_468_15']!='') { ?><div class="users_ads_468_15 ad_468_15"></div><?php } ?>

			</div>

			<div class="hashtags_side">

				<div class="no_hashtags">

					<div class="hashtags_text_1"><?=$lang['hashtags_no_results'];?></div>

				</div>

				<div class="hashtagss">

					<div id="scrolling"><?php echo time(); ?></div>
					<div class="hashtags"></div>

				</div>

				<div class="loading_items loading_hashtags"></div>
	
			</div>


		</div>

		<div class="right_side_browse">

			<?php if($settings['ad_300_250']!='') { ?><div class="ad_300_250"></div><?php } ?>

			<div class="suggestions">

				<div class="suggestions_title">
					<div class="left"><?=$lang['feed_suggestions'];?></div>
					<div class="suggestions_reload tooltip" title="<?=$lang['feed_suggestions_reload'];?>"></div>
				</div>

				<div class="no_suggestions"><?=$lang['feed_suggestions_no_results'];?></div>
	
				<div class="suggestions_holder">
					<div class="suggestions_box"></div>
				</div>

				<div class="load_suggestions"></div>

			</div>
		
		</div>

	</div>
