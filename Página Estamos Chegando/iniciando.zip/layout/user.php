	<div class="user">

		<div class="user_head<?php if($blank == 1) { echo ' user_head_no_cover'; } ?>">

			<div class="user_head_top">

				<?php if($blank == 0) { ?>

				<div class="user_cover" data-cover0="" data-cover1="" data-cover2="" data-cover3="" data-cover4="" data-current="">

					<img data-cover="" class="cover_slide data_cover_0" />
					<img data-cover="" class="cover_slide data_cover_1" />
					<img data-cover="" class="cover_slide data_cover_2" />
					<img data-cover="" class="cover_slide data_cover_3" />
					<img data-cover="" class="cover_slide data_cover_4" />

					<?php if(isset($_COOKIE['logged']) && $user_id == $user['id']) { ?>
					<div class="user_cover_admin">

						<div class="user_cover_admin_manage unselect"><?=$lang['user_manage_covers'];?></div>
				
					</div>
					<?php } else { ?>
					<div class="user_menu_options">
						<div class="user_menu_options_buttons">
							<div class="user_menu_button unselect"><?=message_button($user['id'],$user['privacy_2']);?></div>
							<div class="user_menu_button unselect"><?=follow_button($user['id'],'user');?></div>
						</div>
					</div>
					<?php } ?>

				</div>

				<?php } else { ?>

				<div class="user_no_cover_buttons">
					<div class="user_no_cover_buttons_content">
						<div class="user_menu_button unselect"><?=message_button($user['id'],$user['privacy_2']);?></div>
						<div class="user_menu_button unselect"><?=follow_button($user['id'],'user');?></div>
					</div>
						
				</div>
				<?php } ?>

				<div class="user_menu<?php if($blank == 1) { echo ' user_menu_no_cover'; } ?>">

					<div class="user_menu_bar">

						<div class="user_menu_details">
							<div class="user_menu_name"><a href="<?=$settings['site_url'];?>/<?=$user['username'];?>"><?=$user['name'];?></a></div>
							<?php if($settings['verified'] == 1) { ?>
							<div class="user_menu_verified unselect">
							<?php if($user['verified'] == 1) { ?>
								<img src="<?=get_current_host();?>/assets/img/verified_small.png" />
							<?php } ?>
							<?php if(isset($_COOKIE['logged']) && $user_id == $user['id'] && $user['verified'] == 0) { ?>
								<img src="<?=get_current_host();?>/assets/img/verified_small.png" class="unverified_user" />
							<?php } ?>
							</div>
							<?php } ?>
						</div>

						<div class="user_menu_buttons unselect">

							<div id="user_menu_buttons_selected">photos</div>

							<div class="user_menu_buttons_item" id="about_menu">
								<div class="user_menu_buttons_item_count user_menu_buttons_item_about"></div>
								<div class="user_menu_buttons_item_name"><?=$lang['user_about'];?></div>
							</div>

 							<div class="user_menu_buttons_item" id="following_menu">
								<div class="user_menu_buttons_item_count"><span id="finr"><?=following_count($user['id']);?></span></div>
								<div class="user_menu_buttons_item_name"><?=$lang['user_following'];?></div>
							</div>

							<div class="user_menu_buttons_item" id="followers_menu">
								<div class="user_menu_buttons_item_count"><span id="fnr"><?=$user['followers'];?></span></div>
								<div class="user_menu_buttons_item_name"><?=$lang['user_followers'];?></div>
							</div>
								
							<div class="user_menu_buttons_item user_menu_buttons_item_selected" id="photos_menu">
								<div class="user_menu_buttons_item_count"><span id="pnr"><?=get_photos_nr($user['id']);?></span></div>
								<div class="user_menu_buttons_item_name"><?php if($settings['video'] == 1) { echo $lang['user_posts']; } else { echo $lang['user_photos']; } ?></div>
							</div>

							<div data-curl="0" data-curw="0" class="user_menu_buttons_scroll"></div>

						</div>

					</div>

				</div>

			</div>

			<div class="user_head_profile_pic<?php if($blank == 1) { echo ' user_head_profile_pic_no_cover'; }?>">

				<div class="user_head_profile_pic_box">

					<?php if(isset($_COOKIE['logged']) && $user_id == $user['id']) { ?>
					<div class="user_head_profile_pic_admin">

						<img class="user_profile_pic" />

						<div class="option_1">
							<div class="user_head_profile_pic_admin_remove unselect"><div class="remove_profile_pic"><?=$lang['user_profile_pic_remove'];?></div></div>
						</div>
						<div class="option_2">
							<div class="user_head_profile_pic_admin_upload unselect"><div class="upload_profile_pic"><?=$lang['user_profile_pic_upload'];?></div></div>
						</div>

					</div>
					<?php } else { ?>
					<img class="user_profile_pic" />
					<?php } ?>

				</div>

			</div>
		
		</div>

		<div id="selected_user">photos</div>

		<div class="user_photos user_tab">
			<?php if($settings['ad_728_90']!='') { ?><div class="ad_728_90_home" style="margin-top:0;"></div><?php } ?>
			<input type="hidden" class="user_privacy" value="<?php if($user['privacy_1'] == 0) { echo 0; } else { if(check_follower($user['id'])) { echo 0; } else { echo 1; } } ?>" />
			<div class="user_no_results"><?=$user['name'].' '.$lang['user_no_photos'];?></div>
			<div class="user_privacy_results"><?=$lang['only_followers_restrict_2'];?></div>
		</div>

		<div class="user_followers user_tab">
			<?php if($settings['ad_728_90']!='') { ?><div class="ad_728_90_home" style="margin-top:0;"></div><?php } ?>
			<div class="user_no_results"><?=$user['name'].' '.$lang['user_no_followers'];?></div>
		</div>

		<div class="user_following user_tab">
			<?php if($settings['ad_728_90']!='') { ?><div class="ad_728_90_home" style="margin-top:0;"></div><?php } ?>
			<div class="user_no_results"><?=$user['name'].' '.$lang['user_no_following'];?></div>
		</div>

		<div class="user_about user_tab">
			<?php if($settings['ad_728_90']!='') { ?><div class="ad_728_90_home" style="margin-top:0;"></div><?php } ?>
			<div class="user_about_tab">
				<div class="user_about_tab_title"><?=$lang['user_about_general'];?></div>
				<div class="user_about_tab_row"><?=$lang['user_about_gender'];?>: <?=$user['gender'];?></div>
				<div class="user_about_tab_row"><?=$lang['user_about_birthdate'];?>: <?=$user['born'];?></div>
			</div>	
			<div class="user_about_tab">
				<div class="user_about_tab_title"><?=$lang['user_about_location'];?></div>
				<div class="user_about_tab_row"><?=$lang['user_about_city'];?>: <?=$user['location']['city'];?></div>
				<div class="user_about_tab_row"><?=$lang['user_about_country'];?>: <?=$user['location']['country'];?></div>
			</div>	
			<div class="user_about_tab">
				<div class="user_about_tab_title"><?=$lang['user_about_activity'];?></div>
				<div class="user_about_tab_row"><?=$lang['user_about_since'];?>: <?=$user['since'];?></div>
				<div class="user_about_tab_row"><?=$lang['user_about_seen'];?>: <?=$user['seen'];?></div>
			</div>
			<div class="user_about_tab">
				<div class="user_about_tab_title"><?=$lang['user_about_social'];?></div>
				<?php if(count($user['social']) == 0) {
					echo '<div class="user_about_tab_row">'.$lang['user_about_no_social'].'</div>';
				} else {
					foreach($user['social'] as $social_name=>$social_value) {
						echo '<div class="user_about_tab_row">'.$social_value.'</div>';
					}
				} ?>
			</div>	
			<?php if($settings['about_me'] == 1 && $user['about_me'] != '') { ?>
			<div class="user_about_space"></div>
			<div class="user_about_tab user_about_tab_large">
				<div class="user_about_tab_title user_about_tab_title_large"><?=$lang['user_about_description'];?></div>
				<div class="user_about_tab_row"><?=$user['about_me'];?></div>
			</div>
			<?php } ?>
		</div>

	</div>

	</div>
	