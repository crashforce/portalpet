<div class="pop_chat">

			<div class="pop_box_header">
				<div class="pop_box_title"></div>
				<div class="onliner"></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div id="_message_info" data-fromname="<?php if(isset($_COOKIE['logged_name'])) { echo $_COOKIE['logged_name']; } ?>" data-fromprofile="<?php if(isset($_COOKIE['logged_user'])) { echo $_COOKIE['logged_user']; } ?>" data-frompic="<?php if(isset($_COOKIE['logged'])) { echo get_current_host().'/picture/'.$_COOKIE['logged'].'/35/35'; } ?>"></div>

			<div class="pop_box_content">

				<div class="pop_chat_form">

					<div class="pop_chat_form_content">

						<div id="conversation">
							<div class="conversation"></div>
						</div>

						<div class="pop_chat_form_message">

							<form action="javascript:void(0);" method="post">

								<input name="chat" type="text" id="chat_message" placeholder="<?=$lang['chat_new_message'];?>" />
								<input name="to" type="hidden" id="chat_to" value="" />
								<input name="submit" id="send" type="submit" value="" />

							</form>
		
						</div>

					</div>

				</div>

			</div>

		</div>
