
	<div class="pop">

		<div class="pop_content"></div>

		<?php
		include('layout/photo.php');
		include('layout/contact.php');
		include('layout/edit_photo.php');
		include('layout/message.php');
		include('layout/update_cover.php');
		include('layout/new_photo.php');
		include('layout/new_video.php');
		include('layout/verify_user.php');
		include('layout/manage_covers.php');
		include('layout/login.php');
		include('layout/join.php');
		include('layout/lostpw.php');
		?>

	</div>

	<?php include('layout/settings.php'); ?>

	<div class="site">