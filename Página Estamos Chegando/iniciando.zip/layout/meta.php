<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>

	<base href="<?=get_current_host();?>" />

	<?php if($page == 'home' && !isset($_GET['photo'])) { ?>
<title><?=$settings['meta_1'];?></title>
	<meta name="keywords" content="<?=$settings['meta_2'];?>" />
	<meta name="description" content="<?=$settings['meta_3'];?>" />

	<meta property="og:image" content="<?=$settings['site_url'];?>/assets/img/selfie.png" />
	<meta property="og:description" content="<?=$settings['meta_3'];?>" />
	<meta property="og:title" content="<?=$settings['meta_1'];?>" />
	<meta property="og:url" content="<?=get_current_host();?>" />
	<?php } if($page == 'index' && !isset($_GET['photo'])) { ?>
	<title>Feed</title>
	<?php } if($page == 'users') { ?><title><?=$settings['meta_4'];?></title>
	<meta name="keywords" content="<?=$settings['meta_5'];?>" />
	<meta name="description" content="<?=$settings['meta_6'];?>" />

	<meta property="og:image" content="<?=get_current_host();?>/assets/img/selfie.png" />
	<meta property="og:description" content="<?=$settings['meta_6'];?>" />
	<meta property="og:title" content="<?=$settings['meta_4'];?>" />
	<meta property="og:url" content="<?=get_current_url();?>" />
	<?php } if($page == 'user') { ?><title><?=str_replace('%name%',$user['name'],$settings['meta_7']);?></title>
	<meta name="keywords" content="<?=str_replace('%name%',$user['name'],$settings['meta_8']);?>" />
	<meta name="description" content="<?=str_replace('%name%',$user['name'],$settings['meta_9']);?>" />

	<meta property="og:image" content="<?=$settings['site_url'];?>/uploads/profiles/<?php if($user['pic'] == '') { echo 'no_profile_pic'; } else { echo $user['pic']; } ?>.jpg" />
	<meta property="og:description" content="<?=str_replace('%name%',$user['name'],$settings['meta_9']);?>" />
	<meta property="og:title" content="<?=str_replace('%name%',$user['name'],$settings['meta_7']);?>" />
	<meta property="og:url" content="<?=get_current_host().'/'.$user['user'];?>" />
	<?php } if(isset($_GET['photo']) && $_GET['photo'] != '') {
	$id_photo = safe_string($_GET['photo']);
	$sql_112 = mysqli_query($db,"SELECT `id`,`url`,`type`,`uid`,`desc`,`photo` FROM `photos` WHERE `url` = '".$id_photo."' LIMIT 1");
	$fetch_112 = mysqli_fetch_array($sql_112);
	$sql_122 = mysqli_query($db,"SELECT `id`,`name` FROM `users` WHERE `id` = '".$fetch_112['uid']."' LIMIT 1");
	$fetch_122 = mysqli_fetch_array($sql_122);
	?><title><?=str_replace('%name%',$fetch_122['name'],$settings['meta_10']);?></title>
	<meta name="keywords" content="<?=str_replace('%name%',$fetch_122['name'],$settings['meta_11']);?>" />
	<meta name="description" content="<?=str_replace('%photodesc%',$fetch_112['desc'],$settings['meta_12']);?>" />

	<meta property="og:image" content="<?=get_current_host();?>/uploads/photos/<?=$fetch_112['photo'];?>.jpg" />
	<meta property="og:description" content="<?=str_replace('%photodesc%',$fetch_112['desc'],$settings['meta_12']);?>" />
	<meta property="og:title" content="<?=str_replace('%name%',$fetch_122['name'],$settings['meta_10']);?>" />
	<meta property="og:url" content="<?=get_current_host();?>/photos/<?=$id_photo;?>" />

	<meta name="twitter:image" content="<?=get_current_host();?>/uploads/photos/<?=$fetch_112['photo'];?>.jpg" />
	<meta name="twitter:url" content="<?=get_current_host();?>/photos/<?=$id_photo;?>" />
	<?php } ?>

	<link rel="shortcut icon" href="<?=get_current_host();?>/assets/img/selfie.ico"> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="assets/css/style.css" />
	<link rel="stylesheet" href="assets/css/home_<?=$settings['home_style'];?>.css" />

</head>

<body<?php if($page == 'home') { ?> class="background"<?php } ?>>