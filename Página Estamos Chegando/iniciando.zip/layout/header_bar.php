	
	<?=get_form('upload_profile_pic');?>
	<?=get_form('upload_cover');?>

	<div class="background_slide" data-current="0" <?php if(isset($home) && $home == 0 && !isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?>>
		<img src="assets/img/bg/<?=rand(1,5);?>.jpg" class="bg_1 bg_slide" />
	</div>

	<div class="opacity_home" style="background:rgba(0, 0, 0, 0.5);<?php if(isset($home) && $home == 0 && !isset($_COOKIE['logged'])) { echo 'display:none;'; } ?>"></div>

	<div class="main<?php if($settings['custom_6'] == 1) { echo ' cp_shadow'; } ?>">

		<div class="main_opac <?php echo 'cp_'.$settings['custom_1']; if($settings['custom_5'] == 1) { echo ' cp_opacity'; } ?>"></div>

		<?php include('layout/top.php'); ?>
	
	</div>

	<div class="header_bar_space"></div>

	<div class="live_load"></div>