
	<div class="browse_users">

		<div class="users_box">
	
			<div class="users_box_title">
				<div class="users_box_name user_box_name_selected unselect" data-page="users"><?=$lang['users_browse'];?></div>
				<?php if($settings['ad_468_15']!='') { ?><div class="users_ads_468_15 ad_468_15"></div><?php } ?>
			</div>

			<div id="scrolling">0</div>
			<div class="users"></div>
			<div id="users_page">0</div>
			<div class="no_users"><?=$lang['users_no_results'];?></div>
			<div class="users_loading"></div>

		</div>

		<div class="right_side_users">

			<?php if($settings['ad_300_250']!='') { ?><div class="ad_300_250"></div><?php } ?>

			<div class="filters_box">
	
				<div class="filters_box_title"><?=$lang['users_filter_name'];?></div>

				<div class="filters_box_content unselect">

					<div class="filters_list filtering_1">

						<div class="users_search_box">
							<form action="javascript:void(0);" method="post">
								<input name="search" id="search_i" type="input" placeholder="<?=$lang['users_search_box'];?>" value="<?php if(isset($tag) && $tag!='') { echo str_replace('+',' ',$tag); } ?>" class="users_search" autocomplete="off" />
								<input name="search_progress" id="search_enter" type="submit" />
							</form>
							<div class="users_search_box_x"></div>
						</div>

					</div>

				</div>

				<div class="filters_box_title filters_box_sp"><?=$lang['users_filters_gender'];?></div>

				<div class="filters_box_content unselect">

					<div class="filters_list filtering_1">
						<div class="filters_list_filter" id="filter_1_0">
							<div class="filters_list_checkbox"><div class="filters_list_checkbox_selected filters_list_selcheck"></div></div>
							<div class="filters_list_check_name filters_list_name_sel"><?=$lang['users_filters_gender_all'];?></div>
						</div>
						<div class="filters_list_filter" id="filter_1_1">
							<div class="filters_list_checkbox"><div class="filters_list_checkbox_selected"></div></div>
							<div class="filters_list_check_name"><?=$lang['users_filters_gender_female'];?></div>
						</div>
						<div class="filters_list_filter" id="filter_1_2">
							<div class="filters_list_checkbox"><div class="filters_list_checkbox_selected"></div></div>
							<div class="filters_list_check_name"><?=$lang['users_filters_gender_male'];?></div>
						</div>
						<input type="hidden" id="_filter_1" value="0" />
					</div>

				</div>

				<div class="filters_box_title filters_box_sp"><?=$lang['users_filters_sortedby'];?></div>

				<div class="filters_box_content unselect">

					<div class="filters_list filtering_2">
						<div class="filters_list_filter" id="filter_2_1">
							<div class="filters_list_checkbox"><div class="filters_list_checkbox_selected filters_list_selcheck"></div></div>
							<div class="filters_list_check_name filters_list_name_sel"><?=$lang['users_filters_sortedby_name_az'];?></div>
						</div>
						<div class="filters_list_filter" id="filter_2_2">
							<div class="filters_list_checkbox"><div class="filters_list_checkbox_selected"></div></div>
							<div class="filters_list_check_name"><?=$lang['users_filters_sortedby_name_za'];?></div>
						</div>
						<div class="filters_list_filter" id="filter_2_3">
							<div class="filters_list_checkbox"><div class="filters_list_checkbox_selected"></div></div>
							<div class="filters_list_check_name"><?=$lang['users_filters_sortedby_regdate_new'];?></div>
						</div>
						<div class="filters_list_filter" id="filter_2_4">
							<div class="filters_list_checkbox"><div class="filters_list_checkbox_selected"></div></div>
							<div class="filters_list_check_name"><?=$lang['users_filters_sortedby_regdate_old'];?></div>
						</div>
						<input type="hidden" id="_filter_2" value="1" />
					</div>

				</div>
	
			</div>

		</div>

	</div>