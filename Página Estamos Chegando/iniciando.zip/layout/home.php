
	<div class="home_area">	

		<div class="logo logo_home"><a href="<?=$settings['site_url'];?>"><?php echo $settings['logo_text']; ?></a></div>

		<div class="home_slogan"><?=$lang['home_slogan'];?></div>

		<div class="home_top_content">

			<div class="not_logged">

				<div class="home_box_content">

					<div class="home_box_inside">
						
						<div class="home_box_title"><?=$lang['home_box_title'];?></div>
						<div class="home_box_description"><?=$lang['home_box_description'];?></div>

						<div class="home_buttons_before">
							<div class="home_buttons">

								<div class="home_buttons_login unselect" id="login_but"><?=$lang['home_buttons_login'];?></div>
								<div class="home_buttons_join unselect" id="join_but"><?=$lang['home_buttons_join'];?></div>
							</div>
						</div>

					</div>

				</div>

			</div>

		</div>

	</div>
