
	<div class="home_area">	

		<div class="failed_msg_2 unselect" id="erro_13"><div class="msg_up"><?=$lang['login_error_box'];?></div></div>

		<div class="home_topbox">
			<div class="home_subtopbox">
				<div class="call_live_home logo_homes2"><?php echo $settings['logo_text']; ?></div>
				<div class="home_slogantop">
					<div class="home_slogan"><?=$lang['home_slogan'];?></div>
				</div>
				<div class="home_toplogin">

					<form action="javascript:void(0);" method="post">

						<div class="home_2_login_recover unselect">
							<?=$lang['login_recover'];?>
						</div>

						<div class="pop_login_form_input_2">
							<input name="email" type="text" class="home_top_input" id="email_2_focus" placeholder="<?=$lang['login_email'];?>" />
						</div>

						<div class="pop_login_form_input_2">
							<input name="password" type="password" class="home_top_input" id="password_2_focus" placeholder="<?=$lang['login_password'];?>" />
						</div>

						<div class="left">
							<input name="login" type="submit" class="pop_login_button_2" value="<?=$lang['login_button'];?>" />
						</div>

					</form>

				</div>
			</div>
		</div>

		<div class="home_top_content">

			<div class="not_logged">

				<div class="home_box_content">

					<div class="home_box_inside">
						
						<div class="home_box_title"><?=$lang['home_box_title'];?></div>
						<div class="home_box_description"><?=$lang['home_box_description'];?></div>

						<div class="new_stuff">
							
							<div class="home_new">
								<div class="home_new_1"><?=$lang['home_new_posts'];?></div>
								<div class="home_new_2"><?=$lang['home_new_posts_desc'];?></div>
							</div>
	
							<?php
							$sql_183 = mysqli_query($db,"SELECT `id`,`url`,`type`,`photo` FROM `photos` ORDER BY `id` DESC LIMIT 8");
							while($fetch=mysqli_fetch_array($sql_183)) {

								if($fetch['type'] == 0) {
									$play_icon = '';
								} else {
									$play_icon = '<div class="play_icon play_icon_user" data-id="'.$fetch['url'].'"></div>';
								}

								echo '
								<div class="home_photo_item" data-id="'.$fetch['url'].'">
									<div class="home_photo_item_opacity"></div>
									'.$play_icon.'
									<img src="'.get_current_host().'/thumbs.php?src=uploads/photos/'.$fetch['photo'].'.jpg&w=170&h=150&zc=1" />
								</div>';

							}
							?>

						</div>
					</div>

				</div>

			</div>

			<div class="home_rightjoin">
				<div class="home_rightjoinopac"></div>
				<div class="home_rightjoinsub">

						<div class="pop_join_error_box_2" id="error_box_2_2"><?=$lang['join_error_name'];?></div>
						<div class="pop_join_error_box_2" id="error_box_3_2"><?=$lang['join_error_email'];?></div>
						<div class="pop_join_error_box_2" id="error_box_4_2"><?=$lang['join_error_password'];?></div>
						<div class="pop_join_error_box_2" id="error_box_5_2"><?=$lang['join_error_email_exists'];?></div>

						<form action="javascript:void(0);" method="post">

							<div class="pop_join_form_input_2">
								<input id="name_focus_2" class="input_home home_2_name" name="name" type="text" placeholder="<?=$lang['join_name'];?>" />
							</div>

							<div class="pop_join_form_input_2">
								<input id="email_j_focus_2" class="input_home home_2_email" name="email" type="text" placeholder="<?=$lang['join_email'];?>" />
							</div>

							<div class="pop_join_form_input_2">
								<input id="password_j_focus_2" class="input_home home_2_password" name="password" type="password" placeholder="<?=$lang['join_password'];?>" />
							</div>

							<div class="pop_join_form_input_2">

								<div class="pop_join_input_genders unselect home_2_join_input_genders">
									<div class="pop_join_genderm home_2_join_genderm">
										<div class="pop_join_checkbox home_2_join_checkbox"><div class="pop_join_checkbox_selected pop_join_selcheck home_2_join_checkbox_selected home_2_join_selcheck"></div></div>
										<div class="pop_join_check_name pop_join_check_name_sel home_2_join_check_name home_2_join_check_name_sel"><?=$lang['join_gender_m'];?></div>
									</div>
									<div class="pop_join_genderf home_2_join_genderf">
										<div class="pop_join_checkbox home_2_join_checkbox"><div class="pop_join_checkbox_selected home_2_join_checkbox_selected"></div></div>
										<div class="pop_join_check_name home_2_join_check_name"><?=$lang['join_gender_f'];?></div>
									</div>
									<input type="hidden" id="home_gender_j" value="pop_join_genderm" />
								</div>
						
								<div class="pop_join_buttons home_2_join_buttons">
									<div class="register_loading"></div>
									<input name="join" type="submit" class="pop_join_button home_2_join_button home_2_join_button_touch" value="<?=$lang['join_button'];?>" />
								</div>

							</div>

						</form>

						<div class="home_terms_agree">
							<?=$lang['home_terms'];?>
						</div>

						<div class="home_social_log">

							<div class="home_2_join_social_description">
								<div class="home_2_join_form_or"><?=$lang['join_or'];?></div>
								<div class="home_2_join_social_text"><?=$lang['join_social'];?></div>
							</div>

							<div class="home_2_join_social_button">
								<div class="home_2_join_social_facebook"></div>
							</div>
						</div>
				</div>

			</div>

		</div>

		<div class="home_clearfix2"></div>
		<?php if($settings['ad_728_90']!='') { ?><div class="ad_728_90_home"></div><?php } ?>

		<div class="home_usersbox">
							
			<?php
			$sql_183 = mysqli_query($db,"SELECT `id`,`user`,`name` FROM `users` ORDER BY `id` DESC LIMIT 9");
			while($fetch=mysqli_fetch_array($sql_183)) {

				echo '
				<div class="home_user_item">
					<div class="home_user_item_opacity call_live_profile" data-profileuser="'.$fetch['user'].'"></div>
					<img src="'.get_current_host().'/picture/'.$fetch['id'].'/108/108" class="call_live_profile" data-profileuser="'.$fetch['user'].'" />
					<div class="home_user_item_name call_live_profile" data-profileuser="'.$fetch['user'].'"><div class="home_user_item_name_limit">'.strip_spam($fetch['name']).'</div></div>
				</div>';

			}
			?>

		</div>

	</div>
	
	<div class="home_clearfix"></div>
