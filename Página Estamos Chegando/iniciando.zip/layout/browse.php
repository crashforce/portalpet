	<div class="browse_page">
	
		<div class="browse_left">

			<div class="browse_box_title">
	
				<div class="browse_box_name unselect" id="browse"><?php if($settings['video'] == 1) { echo $lang['browse_title_posts']; } else { echo $lang['browse_title_photos']; } ?></div>
				<?php if($settings['ad_468_15']!='') { ?><div class="users_ads_468_15 ad_468_15"></div><?php } ?>

			</div>

			<div class="browse_side">

				<div class="no_browse">

					<div class="browse_text_1"><?php if($settings['video'] == 1) { echo $lang['browse_no_posts']; } else { echo $lang['browse_no_photos']; } ?></div>

				</div>

				<div class="browses">

					<div id="scrolling"><?php echo time(); ?></div>
					<div class="browse"></div>

				</div>

				<div class="loading_items loading_browse"></div>
	
			</div>


		</div>

		<div class="right_side_browse">

			<?php if($settings['ad_300_250']!='') { ?><div class="ad_300_250"></div><?php } ?>

			<div class="browse_filters_box">
	
				<div class="browse_filters_box_title"><?=$lang['browse_filter'];?></div>

				<div class="browse_filters_box_content unselect">

					<div class="browse_filters_list browse_filtering_1">
						<div class="browse_filters_list_filter" id="filter_3_0">
							<div class="browse_filters_list_checkbox"><div class="browse_filters_list_checkbox_selected browse_filters_list_selcheck"></div></div>
							<div class="browse_filters_list_check_name browse_filters_list_name_sel"><?=$lang['browse_filter_1'];?></div>
						</div>
						<div class="browse_filters_list_filter" id="filter_3_1">
							<div class="browse_filters_list_checkbox"><div class="browse_filters_list_checkbox_selected"></div></div>
							<div class="browse_filters_list_check_name"><?=$lang['browse_filter_2'];?></div>
						</div>
						<div class="browse_filters_list_filter" id="filter_3_2">
							<div class="browse_filters_list_checkbox"><div class="browse_filters_list_checkbox_selected"></div></div>
							<div class="browse_filters_list_check_name"><?=$lang['browse_filter_3'];?></div>
						</div>
						<input type="hidden" id="_filter_3" value="0" />
					</div>

				</div>

			</div>

			<div class="suggestions">

				<div class="suggestions_title">
					<div class="left"><?=$lang['feed_suggestions'];?></div>
					<div class="suggestions_reload tooltip" title="<?=$lang['feed_suggestions_reload'];?>"></div>
				</div>

				<div class="no_suggestions"><?=$lang['feed_suggestions_no_results'];?></div>
	
				<div class="suggestions_holder">
					<div class="suggestions_box"></div>
				</div>

				<div class="load_suggestions"></div>
		
			</div>

		</div>

	</div>
