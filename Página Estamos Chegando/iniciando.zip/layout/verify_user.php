<div class="pop_verify">

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['pop_verify_title'];?></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content">

				<div class="pop_verify_form">

					<div class="pop_verify_form_content">

						<div class="pop_verify_details">

							<div class="pop_verify_box unselect"><div class="verify_user_button"><?=$lang['pop_verify_button'];?></div></div>

						</div>

					</div>

				</div>


			</div>

		</div>
