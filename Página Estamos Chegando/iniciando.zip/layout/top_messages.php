

	<div class="success_msg unselect" id="succ_1"><div class="msg_up"><?=$lang['user_success_1'];?></div></div>
	<div class="success_msg unselect" id="succ_2"><div class="msg_up"><?=$lang['user_success_2'];?></div></div>
	<div class="success_msg unselect" id="succ_3"><div class="msg_up"><?=$lang['user_success_3'];?></div></div>
	<div class="success_msg unselect" id="succ_4"><div class="msg_up"><?=$lang['user_success_4'];?></div></div>
	<div class="success_msg unselect" id="succ_5"><div class="msg_up"><?=$lang['pop_upload_success_1'];?></div></div>
	<div class="success_msg unselect" id="succ_6"><div class="msg_up"><?=$lang['verify_user_sent'];?></div></div>
	<div class="success_msg unselect" id="succ_7"><div class="msg_up"><?=$lang['verify_user_success'];?></div></div>
	<div class="success_msg unselect" id="succ_8"><div class="msg_up"><?=$lang['pop_upload_video_success'];?></div></div>
	<div class="success_msg unselect" id="succ_9"><div class="msg_up"><?=$lang['user_success_5'];?></div></div>
	<div class="success_msg unselect" id="succ_10"><div class="msg_up"><?=$lang['user_success_6'];?></div></div>

	<div class="failed_msg unselect" id="erro_1"><div class="msg_up"><?=$lang['user_error_1'];?></div></div>
	<div class="failed_msg unselect" id="erro_2"><div class="msg_up"><?=$lang['user_error_2'];?></div></div>
	<div class="failed_msg unselect" id="erro_3"><div class="msg_up"><?=$lang['user_error_3'];?></div></div>
	<div class="failed_msg unselect" id="erro_4"><div class="msg_up"><?=$lang['user_error_4'];?></div></div>
	<div class="failed_msg unselect" id="erro_5"><div class="msg_up"><?=$lang['pop_upload_error_1'];?></div></div>
	<div class="failed_msg unselect" id="erro_6"><div class="msg_up"><?=$lang['pop_upload_error_2'];?></div></div>
	<div class="failed_msg unselect" id="erro_7"><div class="msg_up"><?=$lang['pop_upload_error_3'];?></div></div>
	<div class="failed_msg unselect" id="erro_8"><div class="msg_up"><?=$lang['pop_upload_error_4'];?></div></div>
	<div class="failed_msg unselect" id="erro_9"><div class="msg_up"><?=$lang['verify_user_notsent'];?></div></div>
	<div class="failed_msg unselect" id="erro_10"><div class="msg_up"><?=$lang['verify_user_nosuccess'];?></div></div>
	<div class="failed_msg unselect" id="erro_11"><div class="msg_up"><?=$lang['verify_user_email'];?></div></div>
	<div class="failed_msg unselect" id="erro_12"><div class="msg_up"><?=$lang['only_followers_restrict'];?></div></div>
	<div class="failed_msg unselect" id="erro_14"><div class="msg_up"><?=$lang['upload_error'];?></div></div>

