<div class="settings_pop">

	<div class="settings">

		<div class="settings_errors">
			<div class="settings_error_box" id="settings_err_1"><?=$lang['settings_err_1'];?></div>
			<div class="settings_error_box" id="settings_err_2"><?=$lang['settings_err_2'];?></div>
			<div class="settings_error_box" id="settings_err_3"><?=$lang['settings_err_3'];?></div>
			<div class="settings_error_box" id="settings_err_4"><?=$lang['settings_err_4'];?></div>
			<div class="settings_error_box" id="settings_err_6"><?=$lang['settings_err_6'];?></div>
			<div class="settings_error_box" id="settings_err_7"><?=$lang['settings_err_7'];?></div>
			<div class="settings_error_box" id="settings_err_8"><?=$lang['settings_err_8'];?></div>
			<div class="settings_error_box" id="settings_err_9"><?=$lang['settings_err_9'];?></div>
			<div class="settings_error_box" id="settings_err_10"><?=$lang['settings_err_10'];?></div>
			<div class="settings_error_box" id="settings_err_11"><?=$lang['settings_err_11'];?></div>

			<div class="settings_success_box" id="settings_suc_1"><?=$lang['settings_suc_1'];?></div>
			<div class="settings_success_box" id="settings_suc_2"><?=$lang['settings_suc_2'];?></div>
		</div>

		<div class="pop_box_header">
			<div class="pop_box_title"><?=$lang['settings_menu_title'];?></div>
			<div class="pop_box_close unselect">x</div>
		</div>

		<div class="pop_box_content nopad">

			<div class="settings_menu">

				<div class="settings_menu_item settings_menu_item_selected unselect" data-page="general"><?=$lang['settings_menu_general'];?></div>
				<div class="settings_menu_item unselect" id="settings_button_about" data-page="about"><?=$lang['settings_menu_about'];?></div>
				<div class="settings_menu_item unselect" id="settings_button_social" data-page="social"><?=$lang['settings_menu_social'];?></div>
				<div class="settings_menu_item unselect" id="settings_button_password" data-page="password"><?=$lang['settings_menu_password'];?></div>
			
			</div>

			<div class="clearfix"></div>

			<div class="settings_content_general settings_contents" id="settings_general">

				<div class="settings_content_tab">

					<div class="settings_content_tab_title"><?=$lang['settings_general_profile'];?></div>

					<div class="settings_content_tab_input">
						<input name="name_field" type="text" class="settings_text_focus" id="name_field" placeholder="<?=$lang['settings_general_name'];?>" value="" />
					</div>	

					<div class="settings_content_tab_input">
						<input name="username_field" type="text" class="settings_text_focus" id="username_field" placeholder="<?=$lang['settings_general_username'];?>" value="" />
					</div>

					<div class="settings_content_tab_title"><?=$lang['settings_general_contact'];?></div>

					<div class="settings_content_tab_input">
						<input name="email_field" type="text" class="settings_email_focus" id="email_field" placeholder="<?=$lang['settings_general_email'];?>" value="" />
					</div>	

					<div class="settings_save settings_general_save unselect"><?=$lang['settings_save'];?></div>
					<div class="settings_cancel unselect"><?=$lang['settings_cancel'];?></div>			

				</div>

			</div>

			<div class="settings_content_about settings_contents" id="settings_about">

				<div class="settings_content_tab">

					<div class="settings_content_tab_title"><?=$lang['settings_about_gender'];?></div>

					<div class="settings_content_tab_input">
						<div class="settings_content_tab_input_box settings_content_tab_input_gender">
							<label class="gender_field" for="gender_field">
							<select name="settings_gender" class="settings_select settings_select_gender" id="gender_field">
								<?=get_gender();?>
							</select>
							</label>
						</div>
					</div>	

					<div class="clearfix"></div>

					<div class="settings_content_tab_title"><?=$lang['settings_about_birthdate'];?></div>

					<div class="settings_content_tab_input">
						<div class="settings_content_tab_input_birthday settings_content_tab_input_box">
							<label class="birthday_field" for="birthday_field">
							<select name="settings_birthday" class="settings_select settings_select_day" id="birthday_field">
								<?=get_birthday();?>
							</select>
							</label>
						</div>
						<div class="settings_content_tab_input_birthmonth settings_content_tab_input_box">
							<select name="settings_birthmonth" class="settings_select settings_select_month" id="birthmonth_field">
								<?=get_birthmonth();?>
							</select>
						</div>
						<div class="settings_content_tab_input_birthyear settings_content_tab_input_box">
							<select name="settings_birthyear" class="settings_select settings_select_year" id="birthyear_field">
								<?=get_birthyear();?>
							</select>
						</div>
					</div>	

					<div class="clearfix"></div>

					<div class="settings_content_tab_title"><?=$lang['settings_about_location'];?></div>

					<div class="settings_content_tab_input">
						<input name="country_field" type="text" value="" class="settings_text_focus" id="country_field" placeholder="<?=$lang['settings_about_country'];?>" />
					</div>	

					<div class="settings_content_tab_input">
						<input name="city_field" type="text" value="" class="settings_text_focus" id="city_field" placeholder="<?=$lang['settings_about_city'];?>" />
					</div>	

					<div class="settings_save settings_about_save unselect"><?=$lang['settings_save'];?></div>
					<div class="settings_cancel unselect"><?=$lang['settings_cancel'];?></div>			

				</div>

			</div>

			<div class="settings_content_social settings_contents" id="settings_social">

				<div class="settings_content_tab">

					<div class="settings_content_tab_title"><?=$lang['settings_social_title'];?></div>

					<div class="settings_content_tab_input">
						<input name="facebook_field" type="text" value="" class="settings_text_focus" id="facebook_field" placeholder="<?=$lang['settings_social_facebook'];?>" />
					</div>	

					<div class="settings_content_tab_input">
						<input name="twitter_field" type="text" value="" class="settings_text_focus" id="twitter_field" placeholder="<?=$lang['settings_social_twitter'];?>" />
					</div>	

					<div class="settings_content_tab_input">
						<input name="google_field" type="text" value="" class="settings_text_focus" id="google_field" placeholder="<?=$lang['settings_social_google'];?>" />
					</div>	

					<div class="settings_content_tab_input">
						<input name="pinterest_field" type="text" value="" class="settings_text_focus" id="pinterest_field" placeholder="<?=$lang['settings_social_pinterest'];?>" />
					</div>	

					<div class="settings_save settings_social_save unselect"><?=$lang['settings_save'];?></div>
					<div class="settings_cancel unselect"><?=$lang['settings_cancel'];?></div>			

				</div>

			</div>

			<div class="settings_content_password settings_contents" id="settings_password">

				<div class="settings_content_tab">

					<div class="settings_content_tab_title"><?=$lang['settings_password_title_new'];?></div>

					<div class="settings_content_tab_input">
						<input name="new_password" type="password" class="settings_password_focus" id="new_password" placeholder="<?=$lang['settings_password_new'];?>" />
					</div>	

					<div class="settings_content_tab_input">
						<input name="repeat_password" type="password" class="settings_password_focus" id="repeat_new_password" placeholder="<?=$lang['settings_password_repeat'];?>" />
					</div>	

					<div class="settings_save settings_password_save unselect"><?=$lang['settings_save'];?></div>
					<div class="settings_cancel unselect"><?=$lang['settings_cancel'];?></div>			

				</div>

			</div>

		</div>

	</div>

</div>