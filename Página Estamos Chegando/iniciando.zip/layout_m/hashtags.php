	<div class="hashtags_page">
	
		<div class="hashtags_left">

			<div class="hashtags_buttons_list">
	
				<div class="hashtags_buttons_list_content">
					<div class="hashtags_button hashtags_button_s unselect" id="hashtags"></div>
				</div>

			</div>

			<?php if($settings['ad_320_50']!='') { ?><div style="clear:both;margin-top:1px;height:1px;width:100%;"></div><div class="ad_320_50_users"></div><?php } ?>

			<div class="hashtags_side">

				<div class="no_hashtags">

					<div class="hashtags_text_1"><?=$lang['hashtags_no_results'];?></div>

				</div>

				<div class="hashtagss">

					<div id="scrolling"><?php echo time(); ?></div>
					<div class="hashtags"></div>

				</div>

				<div class="loading_items loading_hashtags"></div>
	
			</div>


		</div>

	</div>
