<div class="pop_covers">

			<div class="pop_covers_error_box" id="_er_1"><?=$lang['pop_covers_er_1'];?></div>
			<div class="pop_covers_error_box" id="_er_2"><?=$lang['pop_covers_er_2'];?></div>
			<div class="pop_covers_error_box" id="_er_3"><?=$lang['pop_covers_er_3'];?></div>
			<div class="pop_covers_error_box" id="_er_4"><?=$lang['pop_covers_er_4'];?></div>

			<div class="pop_covers_success_box" id="_su_1"><?=$lang['pop_covers_su_1'];?></div>
			<div class="pop_covers_success_box" id="_su_2"><?=$lang['pop_covers_su_2'];?></div>
			<div class="pop_covers_success_box" id="_su_3"><?=$lang['pop_covers_su_3'];?></div>

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['pop_covers_title'];?></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content pop_covers_visible">

				<div class="pop_covers_form">

					<div class="pop_covers_form_content">

						<div class="pop_covers_details">

							<div class="pop_covers_box_upload unselect"><div class="upload_new_cover"><?=$lang['pop_covers_upload'];?></div></div>

							<div class="cover_boxes"></div>

						</div>

					</div>

				</div>


			</div>

		</div>
