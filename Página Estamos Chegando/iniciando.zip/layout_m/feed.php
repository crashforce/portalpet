
	<div class="feed_page">
	
		<div class="feed_left">

			<div class="feed_buttons_list">
	
				<div class="feed_buttons_list_content">
					<div class="feed_button feed_button_s unselect" id="feed"><?=$lang['feed_buttons_feed'];?></div>
					<div class="feed_button unselect" id="trending"><?=$lang['feed_buttons_trending'];?></div>
					<div class="feed_button unselect" id="activity"><?=$lang['feed_buttons_activity'];?></div>
					<div data-curl="0" data-curw="0" class="feed_scroll"></div>
				</div>

			</div>

			<?php if($settings['ad_320_50']!='') { ?><div style="clear:both;margin-top:1px;height:1px;width:100%;"></div><div class="ad_320_50_users"></div><?php } ?>

			<div class="activityside">

				<div class="no_activity">

					<div class="feed_text_1"><?=$lang['feed_activity_no_results'];?></div>

				</div>

				<div class="feeds">

					<div class="activity"></div>

				</div>

				<div class="loading_items loading_activity"></div>
	
			</div>

			<div class="trendingside">

				<div class="no_trending">

					<div class="feed_text_1"><?=$lang['feed_trending_no_results'];?></div>
					<div class="feed_text_2"><?=$lang['feed_trending_no_results_text'];?></div>
					<div class="feed_users_button unselect call_live_users"><div class="feed_users_button_a"><?=$lang['feed_browse_users'];?></div></div>

				</div>

				<div class="feeds">

					<div id="scrollings"><?php echo time(); ?></div>
					<div class="trending"></div>

				</div>

				<div class="loading_items loading_trending"></div>
	
			</div>

			<div class="feedside">

				<div class="no_feed">

					<div class="feed_text_1"><?=$lang['feed_no_results'];?></div>
					<div class="feed_text_2"><?=$lang['feed_no_results_text'];?></div>
					<div class="feed_users_button unselect call_live_users"><div class="feed_users_button_a"><?=$lang['feed_browse_users'];?></div></div>

				</div>

				<div class="feeds">

					<div id="scrolling"><?php echo time(); ?></div>
					<div class="feed"></div>

				</div>

				<div class="loading_items loading_feed"></div>
	
			</div>


		</div>

	</div>
