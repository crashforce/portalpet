<div class="pop_login">

			<div class="pop_login_error_box" id="error_box_1"><?=$lang['login_error_box'];?></div>
			<div class="pop_login_success_box"><?=$lang['login_success_box'];?></div>

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['login_box_title'];?></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content nopad">

				<div class="pop_login_form nopad">

					<div class="pop_login_form_content nopad">

						<form action="javascript:void(0);" method="post">

							<div class="pop_login_form_input nopad">
								<input name="email" type="text" id="email_focus" class="nopad" placeholder="<?=$lang['login_email'];?>" />
							</div>

							<div class="pop_login_form_input">
								<input name="password" type="password" id="password_focus" placeholder="<?=$lang['login_password'];?>" />
							</div>

							<div class="pop_login_form_buttons">
								<div class="left">
									<input name="login" type="submit" class="pop_login_button" value="<?=$lang['login_button'];?>" />
								</div>

								<div class="pop_login_recover unselect">
									<?=$lang['login_recover'];?>
								</div>
							</div>

						</form>

					</div>

					<div class="pop_login_socialbox">

						<div class="pop_login_social_description">
							<div class="pop_login_form_or"><?=$lang['login_or'];?></div>
							<div class="pop_login_social_text"><?=$lang['login_social'];?></div>
						</div>

						<div class="pop_login_social_button">
							<div class="pop_login_social_facebook"></div>
						</div>

					</div>

				</div>
			</div>

		</div>
