<div class="pop_lostpw">

			<div class="pop_lostpw_error_box" id="lostpw_err_1"><?=$lang['lostpw_err_1'];?></div>
			<div class="pop_lostpw_error_box" id="lostpw_err_2"><?=$lang['lostpw_err_2'];?></div>
			<div class="pop_lostpw_error_box" id="lostpw_err_3"><?=$lang['lostpw_err_3'];?></div>
			<div class="pop_lostpw_error_box" id="lostpw_err_4"><?=$lang['lostpw_err_4'];?></div>

			<div class="pop_lostpw_success_box"><?=$lang['lostpw_success_box'];?></div>

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['lostpw_box_title'];?></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content">

				<div class="pop_lostpw_form">

					<div class="pop_lostpw_form_content">

						<form action="javascript:void(0);" method="post">

							<div class="pop_lostpw_form_input">
								<input name="lostpw_email" type="text" id="lostpw_email_focus" placeholder="<?=$lang['lostpw_email'];?>" />
							</div>

							<div class="pop_lostpw_form_input">
								<input name="lostpw" type="submit" class="pop_lostpw_button" value="<?=$lang['lostpw_button'];?>" />
							</div>

						</form>

					</div>

				</div>

			</div>

		</div>
