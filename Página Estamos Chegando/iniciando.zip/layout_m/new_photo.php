<div class="pop_upload">

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['pop_upload_title'];?></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content">

				<div class="pop_upload_form">

					<div class="pop_upload_form_content unselect">

						<form id="upload_photo" method="post" enctype="multipart/form-data" action="inc/upload_photo.php">
							<input name="file_pic[]" multiple type="file" id="new_photo"/>
							<input name="percent" id="percent" type="hidden" value="0" />
						</form>

						<div class="pop_upload_details_3"></div>

						<div class="pop_upload_details_1">

							<div class="upload_details_1_1"><?=$lang['upload_photos_1'];?></div>
							<div class="upload_details_1_2"><?=$lang['upload_photos_2'];?></div>

						</div>

						<div class="pop_upload_details pop_upload_details_4">

							<div class="upload_url_list">
								<div class="upload_url"><textarea name="url_upload" class="upload_url_text" placeholder="<?=$lang['upload_photo_input'];?>"></textarea></div>
							</div>

							<div class="pop_upload_buttons">
								<div class="pop_upload_url_more upload_more"><?=$lang['upload_more'];?></div>
								<div class="pop_upload_saves unselect"><?=$lang['upload_photos_button'];?></div>
								<div class="pop_upload_cancel unselect"><?=$lang['pop_upload_cancel'];?></div>
							</div>

						</div>

						<div class="pop_upload_details pop_upload_details_2">

							<div class="uploaded_list"></div>

							<div class="pop_upload_buttons">
								<div class="pop_upload_save unselect"><?=$lang['pop_upload_save'];?></div>
								<div class="pop_upload_cancel unselect"><?=$lang['pop_upload_cancel'];?></div>
							</div>

						</div>

					</div>

				</div>


			</div>

		</div>
