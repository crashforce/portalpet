	<?php if(!isset($_GET['option'])) { ?>

		<div class="header">

			<div class="logo unselect <?php if(isset($_COOKIE['logged']) && is_numeric($_COOKIE['logged'])) { echo 'call_live_feed'; } else { echo 'call_live_home'; } ?>"><div class="sub_logo"><?php echo $settings['logo_text']; ?></div></div>

			<div class="menu">

				<div class="m_menu unselect"></div>

			</div>


		</div>

	<?php } ?>