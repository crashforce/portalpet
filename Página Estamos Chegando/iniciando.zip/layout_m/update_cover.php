	
			<div id="cropx"></div>
			<div id="cropy"></div>
			<div id="cropw"></div>
			<div id="croph"></div>

			<div class="user_update_cover">

				<div class="user_update_cover_move">

					<img class="crop_me" />

				</div>

				<div class="user_update_cover_options">

					<div class="user_update_cover_text">
						<?=$lang['update_cover_text'];?>
					</div>

					<div class="user_update_cover_buttons">
	
						<div class="user_update_cover_buttons_save unselect"><?=$lang['update_cover_save'];?></div>
						<div class="user_update_cover_buttons_cancel unselect"><?=$lang['update_cover_cancel'];?></div>
	
					</div>
	
				</div>

			</div>