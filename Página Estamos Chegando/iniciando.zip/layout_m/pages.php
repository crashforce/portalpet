
	<div class="pages">

		<div class="menu_box">

			<div class="pages_box_title"></div>

		</div>
			
		<?php if($settings['ad_320_50']!='') { ?><div style="clear:both;margin-top:1px;height:1px;width:100%;"></div><div class="ad_320_50_users"></div><?php } ?>

		<div class="pages_box">

			<div class="pages_box_content">

				<div class="pages_box_content_about page_content" id="_page_about"><?=$settings['about_page'];?></div>
				<div class="pages_box_content_faq page_content" id="_page_faq"><?=$settings['faq_page'];?></div>
				<div class="pages_box_content_terms page_content" id="_page_terms"><?=$settings['terms_page'];?></div>
				<div class="pages_box_content_privacy page_content" id="_page_privacy"><?=$settings['privacy_page'];?></div>
		
			</div>
	
		</div>

	</div>