
	<div class="home_area">	

		<div class="logo logo_home call_live_home"><?php echo $settings['logo_text']; ?></div>

		<div class="home_slogan"><?=$lang['home_slogan'];?></div>

		<div class="home_top_content">

			<div class="not_logged">

				<div class="home_box_content">

					<div class="home_box_inside">
						
						<div class="home_box_title"><?=$lang['home_box_title'];?></div>
						<div class="home_box_description"><?=$lang['home_box_description'];?></div>

						<div class="home_buttons_before">
							<div class="home_buttons">

								<div class="home_buttons_login unselect" id="login_but"><?=$lang['home_buttons_login'];?></div>
								<div class="home_buttons_join unselect" id="join_but"><?=$lang['home_buttons_join'];?></div>
							</div>
						</div>

					</div>

				</div>

			</div>

		</div>

		<?php if($settings['home_style'] == 1) {?>
		<div class="home_new_posts">

			<div class="home_new">
				<div class="home_new_1"><?=$lang['home_new_posts'];?></div>
			</div>
	
			<div class="home_new_posts_box">
			<?php
			$sql_183 = mysqli_query($db,"SELECT `id`,`url`,`type`,`photo` FROM `photos` ORDER BY `id` DESC LIMIT 3");
			while($fetch=mysqli_fetch_array($sql_183)) {

				if($fetch['type'] == 0) {
					$play_icon = '';
				} else {
					$play_icon = '<div class="play_icon play_icon_user" data-id="'.$fetch['url'].'"></div>';
				}

				echo '
				<span class="home_photo_item">
					'.$play_icon.'
					<img class="home_photo_item2" data-id="'.$fetch['url'].'" src="'.get_current_host().'/thumbs.php?src=uploads/photos/'.$fetch['photo'].'.jpg&w=90&h=85&zc=1" />
				</span>';

			}
			?>
			</div>

			<div class="home_usersbox">
							
			<?php
			$sql_183 = mysqli_query($db,"SELECT `id`,`user`,`name` FROM `users` ORDER BY `id` DESC LIMIT 3");
			while($fetch=mysqli_fetch_array($sql_183)) {

				echo '
				<span class="home_user_item call_live_profile" data-profileuser="'.$fetch['user'].'"">
					<img src="'.get_current_host().'/picture/'.$fetch['id'].'/108/108" class="call_live_profile" data-profileuser="'.$fetch['user'].'" />
				</span>';

			}
			?>

			</div>

		</div>
		<?php } ?>

		<?php if($settings['ad_320_50']!='') { ?><div class="ad_320_50_users ad_320_50_home<?php if($settings['home_style'] == 1) { echo ' ad_space_home'; } ?>"></div><?php } ?>
	
	<?php if($mobile == 1 && $page == 'home') { } else { echo '</div>'; } ?>