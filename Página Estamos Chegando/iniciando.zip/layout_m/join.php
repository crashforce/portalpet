<div class="pop_join">

			<div class="pop_join_error_box" id="error_box_2"><?=$lang['join_error_name'];?></div>
			<div class="pop_join_error_box" id="error_box_3"><?=$lang['join_error_email'];?></div>
			<div class="pop_join_error_box" id="error_box_4"><?=$lang['join_error_password'];?></div>
			<div class="pop_join_error_box" id="error_box_5"><?=$lang['join_error_email_exists'];?></div>

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['join_box_title'];?></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content">

				<div class="pop_join_form">

					<div class="pop_join_form_content">

						<form action="javascript:void(0);" method="post">

							<div class="pop_join_form_input">
								<input id="name_focus" name="name" type="text" placeholder="<?=$lang['join_name'];?>" />
							</div>

							<div class="pop_join_form_input">
								<input id="email_j_focus" name="email" type="text" placeholder="<?=$lang['join_email'];?>" />
							</div>

							<div class="pop_join_form_input">
								<input id="password_j_focus" name="password" type="password" placeholder="<?=$lang['join_password'];?>" />
							</div>

							<div class="pop_join_form_input">
						
								<div class="pop_join_buttons">

									<div class="pop_join_input_genders unselect">
										<div class="pop_join_genderm">
											<div class="pop_join_checkbox"><div class="pop_join_checkbox_selected pop_join_selcheck"></div></div>
											<div class="pop_join_check_name pop_join_check_name_sel"><?=$lang['join_gender_m'];?></div>
										</div>
										<div class="pop_join_genderf">
											<div class="pop_join_checkbox"><div class="pop_join_checkbox_selected"></div></div>
											<div class="pop_join_check_name"><?=$lang['join_gender_f'];?></div>
										</div>
										<input type="hidden" id="gender_j" value="pop_join_genderm" />
									</div>
	
									<div class="right">
										<input name="join" type="submit" class="pop_join_button" value="<?=$lang['join_button'];?>" />
									</div>

								</div>

							</div>

						</form>

					</div>

					<div class="pop_join_socialbox">

						<div class="pop_join_social_description">
							<div class="pop_join_form_or"><?=$lang['join_or'];?></div>
							<div class="pop_join_social_text"><?=$lang['join_social'];?></div>
						</div>

						<div class="pop_join_social_button">
							<div class="pop_join_social_facebook"></div>
						</div>

					</div>

				</div>
			</div>

		</div>
