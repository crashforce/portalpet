	<div class="browse_page">
	
		<div class="browse_left">

			<div class="browse_box_title">
	
				<div class="browse_box_name unselect" id="browse"><?php if($settings['video'] == 1) { echo $lang['browse_title_posts']; } else { echo $lang['browse_title_photos']; } ?></div>

			</div>

			<?php if($settings['ad_320_50']!='') { ?><div style="clear:both;margin-top:1px;height:1px;width:100%;"></div><div class="ad_320_50_users"></div><?php } ?>

			<div class="browse_side">

				<div class="no_browse">

					<div class="browse_text_1"><?php if($settings['video'] == 1) { echo $lang['browse_no_posts']; } else { echo $lang['browse_no_photos']; } ?></div>

				</div>

				<div class="browses">

					<div id="scrolling"><?php echo time(); ?></div>
					<div class="browse"></div>

				</div>

				<div class="loading_items loading_browse"></div>
	
			</div>


		</div>

	</div>
