<div class="pop_upload_video">

			<div class="pop_upload_video_error_box" id="upload_video_error_2"><?=$lang['pop_upload_video_error_1'];?></div>

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['pop_upload_video_title'];?></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content">

				<div class="pop_upload_video_form">

					<div class="pop_upload_video_form_content">

						<div class="pop_upload_video_details">
				
							<input type="hidden" id="new_video" />

							<div class="pop_upload_video_1">

								<div class="video_upload_list">
									<div class="video_item"><textarea name="video_url" class="pop_upload_video_url" placeholder="<?=$lang['pop_upload_video_url'];?>"></textarea></div>
								</div>

								<div class="pop_upload_video_buttons">
									<div class="pop_upload_video_more upload_more2"><?=$lang['upload_more'];?></div>
									<div class="pop_upload_video_save pop_upload_video_check unselect"><?=$lang['pop_upload_video'];?></div>
									<div class="pop_upload_video_cancel unselect"><?=$lang['pop_upload_cancel'];?></div>
								</div>

							</div>

							<div class="pop_upload_video_2">

								<div class="video_uploaded"></div>

								<div class="pop_upload_video_buttons">
									<div class="pop_upload_video_save pop_upload_video_final unselect"><?=$lang['pop_upload_save'];?></div>
									<div class="pop_upload_video_cancel unselect"><?=$lang['pop_upload_cancel'];?></div>
								</div>

							</div>

						</div>

					</div>

				</div>


			</div>

		</div>
