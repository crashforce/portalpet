	<div class="user_page">

		<div class="user">

			<div class="user_cover" data-cover0="" data-cover1="" data-cover2="" data-cover3="" data-cover4="" data-current="">

				<div class="user_data_col">

					<div class="user_menu_button unselect"><?=follow_button($user['id'],'user');?></div>
					<?=message_button($user['id'],$user['privacy_2']);?>
					<div style="clear:both;height:15px;width:100%;margin-top:35px;"></div>
					<span class="user_menu_name"><?=$user['name'];?></span>
					<?php if($settings['verified'] == 1) { ?>
					<span class="user_menu_verified">
						<?php if($user['verified'] == 1) { ?>
							<img src="<?=get_current_host();?>/assets/img/verified_small.png" />
						<?php } ?>
					</span>
					<?php } ?>
					
				</div>

				<img class="user_profile_pic" />

				<img data-cover="" class="cover_slide data_cover_0" />
				<img data-cover="" class="cover_slide data_cover_1" />
				<img data-cover="" class="cover_slide data_cover_2" />
				<img data-cover="" class="cover_slide data_cover_3" />
				<img data-cover="" class="cover_slide data_cover_4" />

			</div>
	
		</div>

		<div class="user_menu_buttons unselect">


			<div class="user_menu_buttons_item user_menu_buttons_item_selected" id="photos_menu">
				<div class="user_menu_buttons_item_count"><span id="pnr"><?=get_photos_nr($user['id']);?></span></div>
				<div class="user_menu_buttons_item_name"><?php if($settings['video'] == 1) { echo $lang['user_posts']; } else { echo $lang['user_photos']; } ?></div>
			</div>


			<div class="user_menu_buttons_item" id="followers_menu">
				<div class="user_menu_buttons_item_count"><span id="fnr"><?=$user['followers'];?></span></div>
				<div class="user_menu_buttons_item_name"><?=$lang['user_followers'];?></div>
			</div>

 			<div class="user_menu_buttons_item" id="following_menu">
				<div class="user_menu_buttons_item_count"><span id="finr"><?=following_count($user['id']);?></span></div>
				<div class="user_menu_buttons_item_name"><?=$lang['user_following'];?></div>
			</div>

			<div id="user_menu_buttons_selected">photos</div>

			<div data-curl="0" data-curw="0" class="user_menu_buttons_scroll"></div>

		</div>

		<?php if($settings['ad_320_50']!='') { ?><div style="clear:both;margin-top:1px;height:1px;width:100%;"></div><div class="ad_320_50_users"></div><?php } ?>


		<div id="selected_user">photos</div>

		<div class="user_photos user_tab">
			<input type="hidden" class="user_privacy" value="<?php if($user['privacy_1'] == 0) { echo 0; } else { if(check_follower($user['id'])) { echo 0; } else { echo 1; } } ?>" />
			<div class="user_no_results"><?=$user['name'].' '.$lang['user_no_photos'];?></div>
			<div class="user_privacy_results"><?=$lang['only_followers_restrict_2'];?></div>
		</div>

		<div class="user_followers user_tab">
			<div class="user_no_results"><?=$user['name'].' '.$lang['user_no_followers'];?></div>
		</div>

		<div class="user_following user_tab">
			<div class="user_no_results"><?=$user['name'].' '.$lang['user_no_following'];?></div>
		</div>

	</div>
	