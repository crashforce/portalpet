<div class="pop_contact">

			<div class="pop_contact_error_box" id="contact_err_1"><?=$lang['contact_err_1'];?></div>
			<div class="pop_contact_error_box" id="contact_err_2"><?=$lang['contact_err_2'];?></div>
			<div class="pop_contact_error_box" id="contact_err_3"><?=$lang['contact_err_3'];?></div>
			<div class="pop_contact_error_box" id="contact_err_4"><?=$lang['contact_err_4'];?></div>

			<div class="pop_contact_success_box"><?=$lang['contact_success_box'];?></div>

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['contact_box_title'];?></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content">

				<div class="pop_contact_form">

					<div class="pop_contact_form_content">

						<form action="javascript:void(0);" method="post">

							<div class="pop_contact_form_input">
								<input name="contact_email" type="text" id="contact_email_focus" placeholder="<?=$lang['contact_email'];?>" />
							</div>

							<div class="pop_contact_form_input">
								<textarea name="contact_message" id="contact_text_focus" placeholder="<?=$lang['contact_message'];?>"></textarea>
							</div>

							<div class="pop_contact_form_buttons">
								<input name="contact" type="submit" class="pop_contact_button" value="<?=$lang['contact_button'];?>" />
							</div>

						</form>

					</div>

				</div>

			</div>

		</div>
