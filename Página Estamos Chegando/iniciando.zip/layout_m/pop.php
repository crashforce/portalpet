
	<div class="mask"></div>

	<div class="menu_swipe">

		<div class="menu_extended">

			<div class="scroll_menu_m">
	
			<div class="top_logged_pic" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?>>
				<img src="<?php if(isset($_COOKIE['logged'])) { echo get_current_host().'/picture/'.$_COOKIE['logged'].'/75/75'; } ?>" class="call_live_profile" data-profileuser="<?php if(isset($_COOKIE['logged_user'])) { echo $_COOKIE['logged_user']; } ?>" style="border-radius:75px;border:2px solid #fff;" />
			</div>

			<div class="m_item unselect swipe_1 call_live_home" title="<?=$lang['header_menu_home'];?>" <?php if(isset($_COOKIE['logged'])) { echo 'style="display:none;"'; }?>><div class="round round_home"><?=$lang['header_menu_home'];?></div></div>

			<?php if($settings['video'] == 1) { ?><div class="m_item unselect swipe_2" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; }?> id="select_video"><div class="round round_video"><?=$lang['header_menu_new_video'];?></div></div><?php } ?>
			<div class="m_item unselect swipe_3" id="select_photo" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; }?> title="<?=$lang['header_menu_photo'];?>"><div class="round round_photo"><?=$lang['header_menu_photo'];?></div></div>
			<div class="m_item unselect swipe_4 call_live_feed" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; }?> title="<?=$lang['header_menu_feed'];?>"><div class="round round_feed"><?=$lang['header_menu_feed'];?></div></div>
			<div class="m_item unselect swipe_5 call_live_profile" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; }?> data-profileuser="<?php if(isset($_COOKIE['logged_user'])) { echo $_COOKIE['logged_user']; }?>"><div class="round round_user"><?=$lang['header_menu_profile'];?></div></div>
			<div class="m_item unselect swipe_6" title="<?=$lang['header_menu_chat'];?>" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; }?>><div class="round round_chat"><?=$lang['header_menu_chat'];?></div></div>
			<div class="m_item unselect swipe_7 call_live_users" title="<?=$lang['header_menu_users'];?>"><div class="round round_users"><?=$lang['header_menu_users'];?></div></div>
			<div class="m_item unselect swipe_15 call_live_browse"><div class="round round_browse"><?php if($settings['video'] == 1) { echo $lang['browse_title_posts']; } else { echo $lang['browse_title_photos']; }?></div></div>
			<div class="m_item unselect swipe_16 invite" onclick="FacebookInviteFriends()"><div class="round round_invite"><?=$lang['header_menu_invite'];?></div></div>
			<div class="m_item unselect swipe_8 call_settings" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; }?>><div class="round round_settings"><?=$lang['header_menu_settings'];?></div></div>
			<div class="m_item unselect swipe_9 call_live_logout" <?php if(!isset($_COOKIE['logged'])) { echo 'style="display:none;"'; }?>><div class="round round_logout"><?=$lang['header_menu_logout'];?></div></div>
				
			<div class="m_item messaging unselect swipe_10" style="display:none;" title="<?=$lang['header_menu_chat'];?>" style="position:relative;">

					<div class="round round_chat"></div>

					<div class="chat_notifications"></div>


			</div>
			<div class="m_item activitytab unselect swipe_11" style="display:none;" title="<?=$lang['header_menu_activity'];?>" style="position:relative;">

					<div class="round round_activity"></div>

					<div class="activity_notifications"></div>

					<div class="activity_tab">

						<div class="activitys_tab_pages">0</div>

						<div class="activity_title">My activity <span id="act_count"></span></div>

						<div class="activity_box">
							<div class="activity_results"></div>
						</div>

					</div>

			</div>
			<div class="m_item unselect swipe_12" <?php if(isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?> title="<?=$lang['header_menu_login'];?>" id="login_but"><div class="round round_login"><?=$lang['header_menu_login'];?></div></div>
			<div class="m_item unselect swipe_13" <?php if(isset($_COOKIE['logged'])) { echo 'style="display:none;"'; } ?> title="<?=$lang['header_menu_join'];?>" id="join_but"><div class="round round_join"><?=$lang['header_menu_join'];?></div></div>
			
			</div>
	
		</div>

	</div>

	<div class="pop_user_menu">

		<div class="pop_opacity"></div>

		<div class="pop_user_menu_content">

			<div class="pop_opacity"></div>

			<div class="pop_options_1">
				<div class="pop_user_menu_button pop_user_button_2 unselect" data-type="0"><?=$lang['user_edit_photo'];?></div>
				<div class="pop_user_menu_button pop_user_button_1 unselect" data-type="0"><?=$lang['user_remove_photo'];?></div>
			</div>
			<div class="pop_options_2">
				<div class="pop_user_menu_button pop_user_button_2 unselect" data-type="1"><?=$lang['user_edit_video'];?></div>
				<div class="pop_user_menu_button pop_user_button_1 unselect" data-type="1"><?=$lang['user_remove_video'];?></div>
			</div>

			<div class="pop_user_menu_button unselect pop_user_cancel"><?=$lang['user_cancel'];?></div>

		</div>

	</div>

	<div class="pop_picture_menu">

		<div class="pop_opacity"></div>

		<div class="pop_picture_user_menu_content">

			<div class="pop_picture_opacity"></div>

			<div class="pop_picture_user_menu_button pop_picture_button_2 unselect remove_profile_pic"><?=$lang['user_profile_pic_remove'];?></div>
			<div class="pop_picture_user_menu_button pop_picture_button_1 unselect upload_profile_pic"><?=$lang['user_profile_pic_upload'];?></div>
			<div class="pop_picture_user_menu_button unselect pop_picture_cancel"><?=$lang['user_cancel'];?></div>

		</div>

	</div>

	<?php if($settings['allow_lang'] == 1) { ?>
	<div class="pop_menu_languages unselect">
		<div class="pop_opacity"></div>
		<div class="pop_menu_languages_box">
			<div class="pop_languages_opacity"></div>
				<?php
				for($i=1;$i<=count($languages_list);$i++) { 
				if(isset($_COOKIE['language'])) { 
					if($languages_list[$i]['file'] == $_COOKIE['language']) {
						$select_lang_class = 'menu_languages_box_item_selected';
					} else {
						$select_lang_class = '';
					}
				} else {
					if($languages_list[$i]['file'] == $settings['lang']) {
						$select_lang_class = 'menu_languages_box_item_selected';
					} else {
						$select_lang_class = '';
					}
				}
				?>
				<div data-file="<?=$languages_list[$i]['file'];?>" class="menu_languages_box_item <?=$select_lang_class;?>"><?=$languages_list[$i]['name'];?></div>
				<?php } ?>
				<div class="pop_languages_close close_nohover"><?=$lang['user_cancel'];?></div>
			</div>
		</div>
	</div>
	<?php } ?>

	<div class="pop">

		<div class="pop_content"></div>

		<div class="pop_messages">

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['header_menu_chat'];?> <span id="cvs_count"></span></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content nopad">

				<div class="pop_messages_form nopad">

					<div class="pop_messages_form_content nopad">

						<div class="messages">

							<div class="messages_box">
								<div class="messages_results"></div>
							</div>

						</div>

					</div>

				</div>

			</div>

		</div>

		<?php
		include('layout_m/photo.php');
		include('layout_m/contact.php');
		include('layout_m/edit_photo.php');
		include('layout_m/message.php');
		include('layout_m/new_photo.php');
		include('layout_m/new_video.php');
		include('layout_m/login.php');
		include('layout_m/join.php');
		include('layout_m/lostpw.php');
		?>

	</div>

	<?php
	include('layout_m/settings.php');
	?>

	<div class="site">