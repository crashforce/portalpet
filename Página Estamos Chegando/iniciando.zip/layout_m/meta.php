<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>

	<base href="<?=get_current_host();?>" />

	<?php if($page == 'home' && !isset($_GET['photo'])) { ?>
	<title><?=$settings['meta_1'];?></title>
	<?php } if($page == 'index' && !isset($_GET['photo'])) { ?>
	<title>Feed</title>
	<?php } if($page == 'users') { ?>
	<title><?=$settings['meta_4'];?></title>
	<?php } if($page == 'user') { ?>
	<title><?=str_replace('%name%',$user['name'],$settings['meta_7']);?></title>
	<?php } if(isset($_GET['photo']) && $_GET['photo'] != '') {
	$id_photo = safe_string($_GET['photo']);
	$sql_112 = mysqli_query($db,"SELECT `id`,`url`,`uid`,`desc`,`photo` FROM `photos` WHERE `url` = '".$id_photo."' LIMIT 1");
	$fetch_112 = mysqli_fetch_array($sql_112);
	$sql_122 = mysqli_query($db,"SELECT `id`,`name` FROM `users` WHERE `id` = '".$fetch_112['uid']."' LIMIT 1");
	$fetch_122 = mysqli_fetch_array($sql_122); ?>
	<title><?=str_replace('%name%',$fetch_122['name'],$settings['meta_10']);?></title>
	<?php } ?>

	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0" />
	<link rel="shortcut icon" href="<?=$settings['site_url'];?>/assets/img/selfie.ico"> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="assets/css_m/style.css" />
	<style type="text/css" id="head_style">.asd { width:1px; }</style>

</head>

<body<?php if($page == 'home') { ?> class="background"<?php } ?>>