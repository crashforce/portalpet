<div class="pop_edit">

			<div class="pop_box_header">
				<div class="pop_box_title"><?=$lang['edit_photo_title'];?></div>
				<div class="pop_box_close unselect">x</div>
			</div>

			<div class="pop_box_content">

				<div class="pop_edit_form">

					<div class="pop_edit_form_content">

						<div class="pop_edit_details">

							<input name="pop_edit_photo" type="hidden" id="pop_edit_photo" />
							<textarea name="description_edit" id="pop_edit_description" placeholder="<?=$lang['edit_photo_description'];?>"></textarea>

							<div class="pop_edit_photo_buttons">
								<div class="pop_edit_save unselect"><?=$lang['edit_photo_save_button'];?></div>
								<div class="pop_edit_cancel unselect"><?=$lang['edit_photo_cancel_button'];?></div>
							</div>

						</div>

					</div>

				</div>


			</div>

		</div>
