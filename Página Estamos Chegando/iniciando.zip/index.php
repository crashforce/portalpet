<?php
	if(isset($_GET['page']) && $_GET['page'] == 'users') {
		$page = 'users';
	}

	if(isset($_GET['page']) && $_GET['page'] == 'browse') {
		$page = 'browse';
	}

	if(isset($_GET['page']) && $_GET['page'] == 'pages') {
		$page = 'pages';
	}

	if(isset($_GET['id']) && $_GET['id']!='') {
		$page = 'user';
	}

	if(isset($_GET['hashtags']) && $_GET['hashtags'] != '') {
		$page = 'hashtags';
	}

	if(isset($_GET['page'])) {
		if($_GET['page'] == 'home') {
			$home = 1;
		} else {
			$home = 0;
		}
	} else {
		$home = 0;
	}

	if(!isset($home) || $home == 0) { $home = 0; }
	if(!isset($page)) { $page = 'home'; }

	require_once('config.php');
	
	if($mobile == 1) {
		$layout = '_m';
	} else {
		$layout = '';
	}

	if(isset($_GET['page']) && !isset($_GET['id'])) {
		if(isset($_COOKIE['logged'])) {
			$page = 'index';
		} else {
			if($_GET['page'] == 'home') {
				$page = 'home';
			}
		}
	}

	if(isset($_GET['id']) && $_GET['id']!='') {
		$id = mysqli_real_escape_string($db,$_GET['id']);
		$user = load_user($id);
		if(!isset($user['covers'][0])) { if($user['id'] == $user_id) { $blank = 0; } else { $blank = 1; } } else { $blank = 0; }
		if(!isset($user['id'])) { redirect($settings['site_url']); }
	}

	if(!isset($_GET['option'])) {
		include('layout'.$layout.'/meta.php');
	}

	include('layout'.$layout.'/top_messages.php');
	include('layout'.$layout.'/pop.php');
	include('layout'.$layout.'/header_bar.php');

	if(isset($_GET['page']) && $_GET['page'] == 'users') { 
		if(isset($_GET['tag']) && $_GET['tag']!='') {
			$tag = safe_string($_GET['tag']);
		}
		include('layout'.$layout.'/users.php');
	}

	if(isset($_GET['page']) && $_GET['page'] == 'pages' && isset($_GET['option']) && $_GET['option'] == 'live') { 
		include('layout'.$layout.'/pages.php');
	}

	if(isset($_GET['page']) && $_GET['page'] == 'hashtags' && isset($_GET['option']) && $_GET['option'] == 'live') {
		include('layout'.$layout.'/hashtags.php');
	}

	if(isset($_GET['page']) && $_GET['page'] == 'browse' && isset($_GET['option']) && $_GET['option'] == 'live') {
		include('layout'.$layout.'/browse.php');
	}

	if(isset($_GET['id']) && $_GET['id']!='' && isset($_GET['option']) && $_GET['option'] == 'live') {
		include('layout'.$layout.'/user.php');
	}

	if(isset($_GET['page']) && $_GET['page'] == 'home') {
		if(isset($_COOKIE['logged'])) {
			include('layout'.$layout.'/feed.php');
		} else {
			if($mobile == 0) {
				include('layout'.$layout.'/home_'.$settings['home_style'].'.php');
			} else {
				include('layout'.$layout.'/home.php');
			}
		}
	}

	if(isset($_GET['lostpw']) && $_GET['lostpw'] !='') {
		$lostpw_key = safe_string($_GET['lostpw']);
		if(check_lostpw($lostpw_key) == 1) {
			echo '<div class="success_msgs unselect" style="display:block;"><div class="msg_up">'.$lang['lostpw_success_2'].'</div></div>';
		} else {
			echo '<div class="failed_msgs unselect" style="display:block;"><div class="msg_up">'.$lang['lostpw_err_5'].'</div></div>';
		}
	}

	if(isset($_GET['verify_key']) && $_GET['verify_key'] !='') {
		$verify_key = safe_string($_GET['verify_key']);
		if(check_verifykey($verify_key) == 1) {
			echo '<div class="success_msgs unselect" style="display:block;"><div class="msg_up">'.$lang['verify_user_success'].'</div></div>';
		} else {
			echo '<div class="failed_msgs unselect" style="display:block;"><div class="msg_up">'.$lang['verify_user_nosuccess'].'</div></div>';
		}
	}
	
	include('footer.php');
?>