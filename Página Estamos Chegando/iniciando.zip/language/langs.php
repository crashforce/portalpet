<?php

	// Edit only if you want to add new language

	$languages_list = array(
		'1' => array('name' => 'Romanian', 'file' => 'romanian.php'),
		'2' => array('name' => 'English', 'file' => 'english.php'),
	);

?>