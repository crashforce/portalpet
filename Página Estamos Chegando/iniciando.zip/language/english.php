﻿<?php
	$lang = array();

	// Cookie 

	$lang['cookie_text'] = 'We use cookies. By browsing our site you agree to our use of cookies.';
	$lang['cookie_ok'] = 'Agree';

	// General

	$lang['follow'] = 'Follow';
	$lang['unfollow'] = 'Unfollow';

	$lang['birthmonth_1'] = 'January';
	$lang['birthmonth_2'] = 'February';
	$lang['birthmonth_3'] = 'March';
	$lang['birthmonth_4'] = 'April';
	$lang['birthmonth_5'] = 'May';
	$lang['birthmonth_6'] = 'June';
	$lang['birthmonth_7'] = 'July';
	$lang['birthmonth_8'] = 'August';
	$lang['birthmonth_9'] = 'September';
	$lang['birthmonth_10'] = 'Octomber';
	$lang['birthmonth_11'] = 'November';
	$lang['birthmonth_12'] = 'December';

	$lang['timeago'] = '% ago';
	$lang['timeago_few_seconds'] = 'a few seconds';
	$lang['timeago_minute'] = 'minute';
	$lang['timeago_minutes'] = 'minutes';
	$lang['timeago_hour'] = 'hour';
	$lang['timeago_hours'] = 'hours';
	$lang['timeago_day'] = 'day';
	$lang['timeago_days'] = 'days';
	$lang['timeago_week'] = 'week';
	$lang['timeago_weeks'] = 'weeks';
	$lang['timeago_month'] = 'month';
	$lang['timeago_months'] = 'months';
	$lang['timeago_year'] = 'year';
	$lang['timeago_years'] = 'years';

	// Header

	$lang['header_menu_home'] = 'Home';
	$lang['header_menu_search'] = 'Search';
	$lang['header_menu_feed'] = 'Feed';
	$lang['header_menu_profile'] = 'My profile';
	$lang['header_menu_activity'] = 'Activity';
	$lang['header_menu_photo'] = 'New photo';
	$lang['header_menu_users'] = 'Browse users';
	$lang['header_menu_settings'] = 'Settings';
	$lang['header_menu_login'] = 'Login';
	$lang['header_menu_logout'] = 'Logout';
	$lang['header_menu_join'] = 'Join';
	$lang['header_menu_chat'] = 'Conversations';
	$lang['header_menu_new_photo'] = 'New photo';
	$lang['header_menu_new_video'] = 'New video';
	$lang['header_messages_no_results'] = 'No recent conversations';
	$lang['header_activity_no_results'] = 'No recent activity';
	$lang['header_search_text'] = 'Search...';
	$lang['header_search_no_results'] = 'No results found';

	// Login 

	$lang['login_error_box'] = 'Your login data is incorrect';
	$lang['login_success_box'] = 'Register complete. You can login now';
	$lang['login_box_title'] = 'LOGIN INTO MY ACCOUNT';
	$lang['login_email'] = 'E-mail or username';
	$lang['login_password'] = 'Password';
	$lang['login_button'] = 'Login';
	$lang['login_recover'] = 'Lost password?';
	$lang['login_or'] = 'OR';
	$lang['login_social'] = 'Login with social account';

	// Contact

	$lang['contact_err_1'] = 'Invalid e-mail address';
	$lang['contact_err_2'] = 'Unexpected error, try again';
	$lang['contact_err_3'] = 'Please wait 60 seconds';
	$lang['contact_err_4'] = 'Complete all fields';
	$lang['contact_success_box'] = 'Your message has been sent';
	$lang['contact_box_title'] = 'Contact';
	$lang['contact_email'] = 'Your e-mail address';
	$lang['contact_message'] = 'Your message';
	$lang['contact_button'] = 'Send message';

	// Lost password

	$lang['lostpw_err_1'] = 'Invalid e-mail address';
	$lang['lostpw_err_2'] = 'Your e-mail was not found';
	$lang['lostpw_err_3'] = 'Unexpected error, try again';
	$lang['lostpw_err_4'] = 'You need to wait 60 seconds';
	$lang['lostpw_err_5'] = 'Invalid key';
	$lang['lostpw_success_box'] = 'We sent you an email with instructions';
	$lang['lostpw_success_2'] = 'Password has been changed, you can login now with new password';
	$lang['lostpw_box_title'] = 'Recover password';
	$lang['lostpw_email'] = 'E-mail address';
	$lang['lostpw_button'] = 'Recover';

	// Join

	$lang['join_error_name'] = 'Enter a valid name';
	$lang['join_error_email'] = 'Enter a valid e-mail address';
	$lang['join_error_password'] = 'Password must be at least 6 characters (A-Z - 0-9)';
	$lang['join_error_email_exists'] = 'E-mail adress already exists';
	$lang['join_box_title'] = 'CREATE NEW ACCOUNT';
	$lang['join_name'] = 'Your full name';
	$lang['join_email'] = 'Your e-mail address';
	$lang['join_password'] = 'Password';
	$lang['join_gender_m'] = 'Male';
	$lang['join_gender_f'] = 'Female';
	$lang['join_button'] = 'Register';
	$lang['join_or'] = 'OR';
	$lang['join_social'] = 'Join with social account';

	// Homepage

	$lang['home_slogan'] = 'You and Yourself';
	$lang['home_box_title'] = 'Join today! It\'s FREE.';
	$lang['home_box_description'] = '&laquo; Share your best moments from your life with friends and family &raquo;';
	$lang['home_buttons_login'] = 'Login';
	$lang['home_buttons_join'] = 'Register now';
	$lang['home_stats_users_registered'] = 'Users registered';
	$lang['home_stats_uploaded_photos'] = 'Uploaded photos';
	$lang['home_stats_viewed_photos'] = 'Viewed photos';
	$lang['home_stats_votes_given'] = 'Votes given';
	$lang['home_stats_comments_added'] = 'Comments added';
	$lang['home_stats_activity_made'] = 'Activity made';
	
	// Feed

	$lang['feed_browse_users'] = 'Browse users';
	$lang['feed_trending_no_results'] = 'No results found in Trending';
	$lang['feed_trending_no_results_text'] = 'Browse users and follow them to get more results';
	$lang['feed_no_results'] = 'No results found in your News feed';
	$lang['feed_no_results_text'] = 'Browse users and follow them to get more results';
	$lang['feed_buttons_activity'] = 'Activity';
	$lang['feed_buttons_trending'] = 'Trending';
	$lang['feed_buttons_feed'] = 'Feed';
	$lang['feed_activity_no_results'] = 'No recent activity';
	$lang['feed_suggestions'] = 'Suggestions';
	$lang['feed_suggestions_reload'] = 'Reload suggestions';
	$lang['feed_suggestions_no_results'] = 'No suggestions found';

	// Verify user

	$lang['pop_verify_title'] = 'Verify user';
	$lang['pop_verify_button'] = 'Confirm e-mail address';
	$lang['verify_user_sent'] = 'Confirmation link has been sent via e-mail';
	$lang['verify_user_success'] = 'Your account is now verified';
	$lang['verify_user_notsent'] = 'Please wait 60 seconds';
	$lang['verify_user_nosuccess'] = 'Error, please try again later';
	$lang['verify_user_email'] = 'Your e-mail is not set yet';

	// Hashtags 

	$lang['hashtags_no_results'] = 'No photos found';

	// Activity 

	$lang['activity_rated'] = 'rated your post';
	$lang['activity_commented'] = 'commented on your post';
	$lang['activity_like'] = 'liked your post';
	$lang['activity_unlike'] = 'unliked your post';
	$lang['activity_following'] = 'is following you';
	$lang['activity_no_following'] = 'is not following you anymore';
	$lang['activity_welcome'] = 'Welcome to Selfie';

	// Users

	$lang['users_browse'] = 'Browse users';
	$lang['users_results'] = 'results';
	$lang['users_reload'] = 'Reload list';
	$lang['users_no_results'] = 'No results found';
	$lang['users_filters_gender'] = 'Gender';
	$lang['users_filters_gender_all'] = 'All';
	$lang['users_filters_gender_male'] = 'Male';
	$lang['users_filters_gender_female'] = 'Female';
	$lang['users_filters_sortedby'] = 'Sorted by';
	$lang['users_filters_sortedby_name_az'] = 'Name (A-Z)';
	$lang['users_filters_sortedby_name_za'] = 'Name (Z-A)';
	$lang['users_filters_sortedby_regdate_new'] = 'Newest';
	$lang['users_filters_sortedby_regdate_old'] = 'Oldest';
	$lang['users_search_box'] = 'Search...';
	$lang['users_filters_title'] = 'Filters';
	$lang['users_load_more'] = 'Load more';

	// Edit photo

	$lang['edit_photo_title'] = 'Edit photo';
	$lang['edit_photo_description'] = 'Your photo description (200 characters max)';
	$lang['edit_photo_save_button'] = 'Edit photo';
	$lang['edit_video_title'] = 'Edit video';
	$lang['edit_video_description'] = 'Your video description (200 characters max)';
	$lang['edit_video_save_button'] = 'Edit video';
	$lang['edit_photo_cancel_button'] = 'Cancel';

	// Manage covers

	$lang['pop_covers_title'] = 'Manage covers';
	$lang['pop_covers_er_1'] = 'Your cover must be large than 600px X 300px';
	$lang['pop_covers_er_2'] = 'Unsupported extension, use only JPG, GIF, PNG';
	$lang['pop_covers_er_3'] = 'Unexpected error, please try again';
	$lang['pop_covers_er_4'] = 'Only 5 covers allowed';
	$lang['pop_covers_su_1'] = 'New cover has been uploaded';
	$lang['pop_covers_su_2'] = 'Cover has been deleted';
	$lang['pop_covers_su_3'] = 'Primary cover has been set';
	$lang['pop_covers_upload'] = 'Upload new cover';

	// Settings
	
	$lang['settings_err_1'] = 'You must use a real name';
	$lang['settings_err_2'] = 'Invalid e-mail address';
	$lang['settings_err_3'] = 'Username is not available';
	$lang['settings_err_4'] = 'Unexpected error, try again';
	$lang['settings_err_6'] = 'Repeated password is not the same';
	$lang['settings_err_7'] = 'New password must be minimum 6 characters';
	$lang['settings_err_8'] = 'Facebook profile must be valid URL';
	$lang['settings_err_9'] = 'Twitter profile must be valid URL';
	$lang['settings_err_10'] = 'Google profile must be valid URL';
	$lang['settings_err_11'] = 'Pinterest profile must be valid URL';
	$lang['settings_suc_1'] = 'Your settings has been saved';
	$lang['settings_suc_2'] = 'Password has been changed';
	$lang['settings_menu_general'] = 'General';
	$lang['settings_menu_about'] = 'About me';
	$lang['settings_menu_social'] = 'Social profiles';
	$lang['settings_menu_password'] = 'Change password';
	$lang['settings_general_profile'] = 'Profile';
	$lang['settings_general_contact'] = 'Contact';
	$lang['settings_general_name'] = 'Name';
	$lang['settings_general_username'] = 'Username';
	$lang['settings_general_email'] = 'E-mail address';
	$lang['settings_general_desc'] = 'A few words about me..';
	$lang['settings_about_birthdate'] = 'Birthdate';
	$lang['settings_about_gender'] = 'Gender';
	$lang['settings_about_location'] = 'Location';
	$lang['settings_about_city'] = 'City';
	$lang['settings_about_country'] = 'Country';
	$lang['settings_social_title'] = 'Social profiles';
	$lang['settings_social_facebook'] = 'Facebook';
	$lang['settings_social_twitter'] = 'Twitter';
	$lang['settings_social_google'] = 'Google+';
	$lang['settings_social_pinterest'] = 'Pinterest';
	$lang['settings_password_title_new'] = 'New password';
	$lang['settings_password_current'] = 'Your current password';
	$lang['settings_password_new'] = 'New password';
	$lang['settings_password_repeat'] = 'Repeat new password';	
	$lang['settings_save'] = 'Save';
	$lang['settings_cancel'] = 'Cancel';
	$lang['settings_menu_title'] = 'Settings';

	// Chat

	$lang['chat_new_message'] = 'Your message goes here...';

	// Upload video

	$lang['pop_upload_video_title'] = 'New video';
	$lang['pop_upload_video_description'] = 'Your video description (200 characters max)';
	$lang['pop_upload_video_url'] = 'https://www.youtube.com/watch?v=nrJtHemSPW4';
	$lang['pop_upload_video'] = 'Upload';
	$lang['pop_upload_video_error_1'] = 'Youtube URL is not valid';
	$lang['pop_upload_video_success'] = 'Your video has been uploaded';

	// Upload photo

	$lang['pop_upload_title'] = 'Upload new photo';
	$lang['pop_upload_description'] = 'Your photo description (200 characters max)';
	$lang['pop_upload_save'] = 'Save';
	$lang['pop_upload_cancel'] = 'Cancel';
	$lang['pop_upload_error_1'] = 'Unsupported extension, use only JPG, GIF, PNG';
	$lang['pop_upload_error_2'] = 'Unexpected error, please try again';
	$lang['pop_upload_error_3'] = 'Photo is too small, photo must be at least 300px x 300px (0,1MP)';
	$lang['pop_upload_error_4'] = 'Your photo has not been uploaded';
	$lang['pop_upload_success_1'] = 'Your photo has been uploaded';

	// Update cover 

	$lang['update_cover_text'] = 'Drag your cover up and down to get the best fit';
	$lang['update_cover_save'] = 'Save cover';
	$lang['update_cover_cancel'] = 'Cancel';

	// Photo

	$lang['photo_rating_success'] = 'Your rate has been saved';
	$lang['photo_rating_error'] = 'You already voted this photo';
	$lang['photo_your_rate'] = 'Your rate';
	$lang['photo_new_comment'] = 'Leave a comment..';
	$lang['photo_comment_spam'] = 'You must wait 3 seconds before sending another comment';
	$lang['photo_views_count'] = 'views';
	$lang['photo_votes_count'] = 'votes';
	$lang['photo_likes_count'] = 'likes';
	$lang['photo_score_count'] = 'score';
	$lang['photo_comments_count'] = 'comments';
	$lang['photo_fullsize'] = 'View fullsize';
	$lang['photo_report'] = 'Report';
	$lang['photo_social'] = 'Share';
	$lang['like_button'] = 'Like';
	$lang['unlike_button'] = 'Unlike';
	$lang['remove_comment'] = 'Remove';

	// User

	$lang['user_no_photos'] = 'has no photos';
	$lang['user_no_followers'] = 'has no followers';
	$lang['user_no_following'] = 'is not following any user';
	$lang['user_profile_pic_remove'] = 'Remove';
	$lang['user_profile_pic_upload'] = 'Upload picture';
	$lang['user_about'] = 'About me';
	$lang['user_followers'] = 'Followers';
	$lang['user_following'] = 'Following';
	$lang['user_photos'] = 'Photos';
	$lang['user_posts'] = 'Posts';
	$lang['user_manage_covers'] = 'Manage covers';
	$lang['user_message'] = 'Message';
	$lang['user_success_1'] = 'Your photo has been edited';
	$lang['user_success_5'] = 'Your video has been edited';
	$lang['user_success_2'] = 'Your photo has been deleted';
	$lang['user_success_6'] = 'Your video has been deleted';
	$lang['user_success_3'] = 'Your profile picture has been updated';
	$lang['user_success_4'] = 'Your profile picture has been removed';
	$lang['user_error_1'] = 'Your photo has not been edited';
	$lang['user_error_2'] = 'Unexpected error, please try again';
	$lang['user_error_3'] = 'Unsupported extension, use only JPG, GIF, PNG';
	$lang['user_error_4'] = 'Your profile picture must be large than 180px X 185px';
	$lang['user_edit_photo'] = 'Edit photo';
	$lang['user_edit_video'] = 'Edit video';
	$lang['user_remove_photo'] = 'Remove photo';
	$lang['user_remove_video'] = 'Remove video';
	$lang['user_remove_cover'] = 'Remove cover';
	$lang['user_make_primary'] = 'Make primary';
	$lang['user_cancel'] = 'Cancel';
	$lang['user_about_general'] = 'General information';
	$lang['user_about_gender'] = 'Gender';
	$lang['user_about_birthdate'] = 'Birthdate';
	$lang['user_about_location'] = 'Location';
	$lang['user_about_country'] = 'Country';
	$lang['user_about_city'] = 'City';
	$lang['user_about_activity'] = 'Activity';
	$lang['user_about_since'] = 'Member since';
	$lang['user_about_seen'] = 'Last seen';
	$lang['user_about_social'] = 'Social profiles';
	$lang['user_about_no_social'] = 'No profiles available';
	$lang['user_about_description'] = 'About me';

	// Pages
	
	$lang['pages_about'] = 'About';
	$lang['pages_terms'] = 'Terms of use';
	$lang['pages_privacy'] = 'Privacy';
	$lang['pages_contact'] = 'Contact';
	$lang['menu_language'] = 'Language';

	// Extra field 1.0.4

	$lang['settings_err_12'] = 'Current password is wrong';
	$lang['pages_faq'] = 'Faq';
	$lang['browse_title_photos'] = 'Browse photos';
	$lang['browse_title_posts'] = 'Browse posts';
	$lang['browse_no_posts'] = 'No posts found';
	$lang['browse_no_photos'] = 'No photos';
	$lang['browse_filter'] = 'Filter by type';
	$lang['browse_filter_1'] = 'All';
	$lang['browse_filter_2'] = 'Photo';
	$lang['browse_filter_3'] = 'Video';
	$lang['home_new_posts'] = 'What\'s new?';
	$lang['home_new_posts_desc'] = 'Lastest public posts shared by users';
	$lang['home_terms'] = 'By clicking Register, you agree to our <span style="font-weight:bold;">Terms</span>';
	$lang['footer_copyright'] = 'All rights reserved BindCode';
	$lang['upload_photos_1'] = 'Select photos';
	$lang['upload_photos_2'] = 'Upload by URL';
	$lang['upload_photo_input'] = 'Your photo URL';
	$lang['upload_more'] = '+ Add more';
	$lang['upload_photos_button'] = 'Upload';
	$lang['settings_privacy_title_1'] = 'Who can see my posts';
	$lang['settings_privacy_title_2'] = 'Who can message me';
	$lang['settings_privacy_title_3'] = 'E-mail notifications';
	$lang['settings_privacy_option_1'] = 'Anyone';
	$lang['settings_privacy_option_2'] = 'Followers';
	$lang['settings_privacy_option_3'] = 'Yes';
	$lang['settings_privacy_option_4'] = 'No';
	$lang['header_menu_invite'] = 'Invite';
	$lang['only_followers_restrict'] = 'Only followers are allowed to message me';
	$lang['only_followers_restrict_2'] = 'Only followers are allowed to see the posts';
	$lang['users_filter_name'] = 'Filter by name';
	$lang['uploading'] = 'Uploading';
	$lang['upload_limit'] = 'Uploading limit %limit%';
	$lang['upload_error'] = 'Your photo(s) has not been uploaded';
?>