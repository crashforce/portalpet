<?php
	$lang = array();

	// Cookie 

	$lang['cookie_text'] = 'Folosim cookie. Prin navigarea site-ul nostru sunteti de acord cu utilizarea nostru de cookie-uri.';
	$lang['cookie_ok'] = 'Da';

	// General

	$lang['follow'] = 'Abonare';
	$lang['unfollow'] = 'Dezabonare';

	$lang['birthmonth_1'] = 'Ianuarie';
	$lang['birthmonth_2'] = 'Februarie';
	$lang['birthmonth_3'] = 'Martie';
	$lang['birthmonth_4'] = 'Aprilie';
	$lang['birthmonth_5'] = 'Mai';
	$lang['birthmonth_6'] = 'Iunie';
	$lang['birthmonth_7'] = 'Julie';
	$lang['birthmonth_8'] = 'August';
	$lang['birthmonth_9'] = 'Septembrie';
	$lang['birthmonth_10'] = 'Octombrie';
	$lang['birthmonth_11'] = 'Noiembrie';
	$lang['birthmonth_12'] = 'Decembrie';

	$lang['timeago'] = 'acum %';
	$lang['timeago_few_seconds'] = 'secunde';
	$lang['timeago_minute'] = 'minut';
	$lang['timeago_minutes'] = 'minute';
	$lang['timeago_hour'] = 'ora';
	$lang['timeago_hours'] = 'ore';
	$lang['timeago_day'] = 'zi';
	$lang['timeago_days'] = 'zile';
	$lang['timeago_week'] = 'sapt';
	$lang['timeago_weeks'] = 'sapt';
	$lang['timeago_month'] = 'luna';
	$lang['timeago_months'] = 'luni';
	$lang['timeago_year'] = 'an';
	$lang['timeago_years'] = 'ani';

	// Header

	$lang['header_menu_home'] = 'Acasa';
	$lang['header_menu_search'] = 'Cauta';
	$lang['header_menu_feed'] = 'Feed';
	$lang['header_menu_profile'] = 'Profilul meu';
	$lang['header_menu_activity'] = 'Activitate';
	$lang['header_menu_photo'] = 'Poza noua';
	$lang['header_menu_users'] = 'Lista utilizatori';
	$lang['header_menu_settings'] = 'Setari';
	$lang['header_menu_login'] = 'Conectare';
	$lang['header_menu_logout'] = 'Iesire';
	$lang['header_menu_join'] = 'Inregistrare';
	$lang['header_menu_chat'] = 'Conversatii';
	$lang['header_menu_new_photo'] = 'Poza noua';
	$lang['header_menu_new_video'] = 'Video nou';
	$lang['header_messages_no_results'] = 'Nu exista conversatii';
	$lang['header_activity_no_results'] = 'Nu exista activitate';
	$lang['header_search_text'] = 'Cauta...';
	$lang['header_search_no_results'] = 'Nu s-au gasit rezultate';

	// Login 

	$lang['login_error_box'] = 'Datele sunt incorecte';
	$lang['login_success_box'] = 'Inregistrare completa';
	$lang['login_box_title'] = 'INTRA IN CONT';
	$lang['login_email'] = 'E-mail sau Utilizator';
	$lang['login_password'] = 'Parola';
	$lang['login_button'] = 'Intra';
	$lang['login_recover'] = 'Parola?';
	$lang['login_or'] = 'SAU';
	$lang['login_social'] = 'Conecteaza-te cu social';

	// Contact

	$lang['contact_err_1'] = 'E-mail invalid';
	$lang['contact_err_2'] = 'Eroare, incearca din nou';
	$lang['contact_err_3'] = 'Asteapta 60 secunde';
	$lang['contact_err_4'] = 'Completeaza tot';
	$lang['contact_success_box'] = 'Mesajul a fost trimis';
	$lang['contact_box_title'] = 'Contact';
	$lang['contact_email'] = 'Adresa de e-mail';
	$lang['contact_message'] = 'Mesajul tau';
	$lang['contact_button'] = 'Trimite';

	// Lost password

	$lang['lostpw_err_1'] = 'E-mail invalid';
	$lang['lostpw_err_2'] = 'E-mail nu a fost gasit';
	$lang['lostpw_err_3'] = 'Eroare, incearca din nou';
	$lang['lostpw_err_4'] = 'Asteapta 60 secunde';
	$lang['lostpw_err_5'] = 'Cheie invalida';
	$lang['lostpw_success_box'] = 'Am trimis pe mail instructiuni';
	$lang['lostpw_success_2'] = 'Parola a fost schimba, te poti loga cu noua parola';
	$lang['lostpw_box_title'] = 'Recupereaza parola';
	$lang['lostpw_email'] = 'Adresa e-mail';
	$lang['lostpw_button'] = 'Trimite';

	// Join

	$lang['join_error_name'] = 'Nume invalid';
	$lang['join_error_email'] = 'E-mail invalid';
	$lang['join_error_password'] = 'Parola trebuie sa fie minim 6 (A-Z - 0-9)';
	$lang['join_error_email_exists'] = 'Acest e-mail exista';
	$lang['join_box_title'] = 'CONT NOU';
	$lang['join_name'] = 'Numele tau';
	$lang['join_email'] = 'Adresa de e-mail';
	$lang['join_password'] = 'Parola';
	$lang['join_gender_m'] = 'Barbat';
	$lang['join_gender_f'] = 'Femeie';
	$lang['join_button'] = 'Inregistrare';
	$lang['join_or'] = 'SAU';
	$lang['join_social'] = 'Inregistreaza-te prin social';

	// Homepage

	$lang['home_slogan'] = 'TU SI PRIETENII TAI';
	$lang['home_box_title'] = 'Hai si tu, este gratis!';
	$lang['home_box_description'] = '&laquo; Imparte cele mai bune momente din viata cu prietenii tai &raquo;';
	$lang['home_buttons_login'] = 'Intra';
	$lang['home_buttons_join'] = 'Inregistrare';
	
	// Feed

	$lang['feed_browse_users'] = 'Lista utilizatori';
	$lang['feed_trending_no_results'] = 'Nu sunt rezultate';
	$lang['feed_trending_no_results_text'] = 'Aboneaza-te la mai multi utilizatori pentru rezultate';
	$lang['feed_no_results'] = 'Nu sunt rezultate';
	$lang['feed_no_results_text'] = 'Aboneaza-te la mai multi utilizatori pentru rezultate';
	$lang['feed_buttons_activity'] = 'Activitate';
	$lang['feed_buttons_trending'] = 'Populare';
	$lang['feed_buttons_feed'] = 'Acasa';
	$lang['feed_activity_no_results'] = 'Nu sunt rezultate';
	$lang['feed_suggestions'] = 'Sugestii';
	$lang['feed_suggestions_reload'] = 'Reincarca';
	$lang['feed_suggestions_no_results'] = 'Nu sunt sugestii';

	// Verify user

	$lang['pop_verify_title'] = 'Verifica utilizator';
	$lang['pop_verify_button'] = 'Confirma e-mail';
	$lang['verify_user_sent'] = 'Verifica adresa de e-mail';
	$lang['verify_user_success'] = 'Contul tau este verificat';
	$lang['verify_user_notsent'] = 'Asteapta 60 secunde';
	$lang['verify_user_nosuccess'] = 'Eroare, incearca din nou';
	$lang['verify_user_email'] = 'E-mail nu este setat';

	// Hashtags 

	$lang['hashtags_no_results'] = 'Nu am gasit poze';

	// Activity 

	$lang['activity_rated'] = 'a votat';
	$lang['activity_commented'] = 'a comentat';
	$lang['activity_like'] = 'a dat like';
	$lang['activity_unlike'] = 'a dat unlike';
	$lang['activity_following'] = 's-a abonat';
	$lang['activity_no_following'] = 's-a dezabonat';
	$lang['activity_welcome'] = 'Bine ai venit pe Selfie';

	// Users

	$lang['users_browse'] = 'Lista utilizatori';
	$lang['users_results'] = 'rezultate';
	$lang['users_reload'] = 'Reincarca';
	$lang['users_no_results'] = 'Nu am gasit rezultate';
	$lang['users_filters_gender'] = 'Sex';
	$lang['users_filters_gender_all'] = 'Toti';
	$lang['users_filters_gender_male'] = 'Barbat';
	$lang['users_filters_gender_female'] = 'Femeie';
	$lang['users_filters_sortedby'] = 'Sorteaza';
	$lang['users_filters_sortedby_name_az'] = 'Nume (A-Z)';
	$lang['users_filters_sortedby_name_za'] = 'Nume (Z-A)';
	$lang['users_filters_sortedby_regdate_new'] = 'Mai noi';
	$lang['users_filters_sortedby_regdate_old'] = 'Mai vechi';
	$lang['users_search_box'] = 'Cauta...';
	$lang['users_filters_title'] = 'Filtre';
	$lang['users_load_more'] = 'Incarca';

	// Edit photo

	$lang['edit_photo_title'] = 'Modifica poza';
	$lang['edit_photo_description'] = 'Your photo description (200 caractere limita)';
	$lang['edit_photo_save_button'] = 'Modifica';
	$lang['edit_video_title'] = 'Modifica video';
	$lang['edit_video_description'] = 'Descriere video (200 caractere limita)';
	$lang['edit_video_save_button'] = 'Modifica';
	$lang['edit_photo_cancel_button'] = 'Anuleaza';

	// Manage covers

	$lang['pop_covers_title'] = 'Imagini fundal';
	$lang['pop_covers_er_1'] = 'Imaginea trebuie sa fie mai mare ca: 600px X 300px';
	$lang['pop_covers_er_2'] = 'Este permis doar: JPG, GIF, PNG';
	$lang['pop_covers_er_3'] = 'Eroare, incearca din nou';
	$lang['pop_covers_er_4'] = 'Maxim 5 imagini';
	$lang['pop_covers_su_1'] = 'Imagine fundal a fost incarcata';
	$lang['pop_covers_su_2'] = 'Imaginea a fost stearsa';
	$lang['pop_covers_su_3'] = 'Imagine fundal a fost setata';
	$lang['pop_covers_upload'] = 'Incarca imagine';

	// Settings
	
	$lang['settings_err_1'] = 'Foloseste nume real';
	$lang['settings_err_2'] = 'E-mail invalid';
	$lang['settings_err_3'] = 'Utilizatorul exista deja';
	$lang['settings_err_4'] = 'Eroare, incearca din nou';
	$lang['settings_err_6'] = 'Parola nu este la fel';
	$lang['settings_err_7'] = 'Parola trebuie sa fie cel putin 6 caractere';
	$lang['settings_err_8'] = 'Contul facebook nu este valid';
	$lang['settings_err_9'] = 'Contul twitter nu este valid';
	$lang['settings_err_10'] = 'Contul google nu este valid';
	$lang['settings_err_11'] = 'Contul pinterest nu este valid';
	$lang['settings_suc_1'] = 'Setarile au fost schimbate';
	$lang['settings_suc_2'] = 'Parola a fost schimbata';
	$lang['settings_menu_general'] = 'General';
	$lang['settings_menu_about'] = 'Despre';
	$lang['settings_menu_social'] = 'Conturi sociale';
	$lang['settings_menu_password'] = 'Schimba parola';
	$lang['settings_general_profile'] = 'Profil';
	$lang['settings_general_contact'] = 'Contact';
	$lang['settings_general_name'] = 'Nume';
	$lang['settings_general_username'] = 'Utilizator';
	$lang['settings_general_email'] = 'Adresa e-mail';
	$lang['settings_general_desc'] = 'Despre mine..';
	$lang['settings_about_birthdate'] = 'Data nastere';
	$lang['settings_about_gender'] = 'Sex';
	$lang['settings_about_location'] = 'Locatie';
	$lang['settings_about_city'] = 'Oras';
	$lang['settings_about_country'] = 'Tara';
	$lang['settings_social_title'] = 'Conturi sociale';
	$lang['settings_social_facebook'] = 'Facebook';
	$lang['settings_social_twitter'] = 'Twitter';
	$lang['settings_social_google'] = 'Google+';
	$lang['settings_social_pinterest'] = 'Pinterest';
	$lang['settings_password_title_new'] = 'Parola noua';
	$lang['settings_password_current'] = 'Parola curenta';
	$lang['settings_password_new'] = 'Parola noua';
	$lang['settings_password_repeat'] = 'Repeta parola';	
	$lang['settings_save'] = 'Salveaza';
	$lang['settings_cancel'] = 'Anuleaza';
	$lang['settings_menu_title'] = 'Setari';

	// Chat

	$lang['chat_new_message'] = 'Mesajul tau aici...';

	// Upload video

	$lang['pop_upload_video_title'] = 'Video nou';
	$lang['pop_upload_video_description'] = 'Descriere video (200 caractere limita)';
	$lang['pop_upload_video_url'] = 'https://www.youtube.com/watch?v=nrJtHemSPW4';
	$lang['pop_upload_video'] = 'Incarca';
	$lang['pop_upload_video_error_1'] = 'Adresa URL nu este valida';
	$lang['pop_upload_video_success'] = 'Video a fost adaugat';

	// Upload photo

	$lang['pop_upload_title'] = 'Poza noua';
	$lang['pop_upload_description'] = 'Descriere poza (200 caracatere limita)';
	$lang['pop_upload_save'] = 'Salveaza';
	$lang['pop_upload_cancel'] = 'Anuleaza';
	$lang['pop_upload_error_1'] = 'Este permis doar: JPG, GIF, PNG';
	$lang['pop_upload_error_2'] = 'Eroare, incearca din nou';
	$lang['pop_upload_error_3'] = 'Poza este prea mica, minim: 300px x 300px (0,1MP)';
	$lang['pop_upload_error_4'] = 'Poza nu a fost adaugata';
	$lang['pop_upload_success_1'] = 'Poza a fost adaugata';

	// Update cover 

	$lang['update_cover_text'] = 'Repozitioneaza folosing mouse-ul';
	$lang['update_cover_save'] = 'Salveaza';
	$lang['update_cover_cancel'] = 'Anuleaza';

	// Photo

	$lang['photo_rating_success'] = 'Votul a fost salvat';
	$lang['photo_rating_error'] = 'Ai votat deja';
	$lang['photo_your_rate'] = 'Scorul tau';
	$lang['photo_new_comment'] = 'Mesajul tau..';
	$lang['photo_comment_spam'] = 'Asteapta 3 secunde';
	$lang['photo_views_count'] = 'afisari';
	$lang['photo_votes_count'] = 'voturi';
	$lang['photo_likes_count'] = 'like-uri';
	$lang['photo_score_count'] = 'scor';
	$lang['photo_comments_count'] = 'comentarii';
	$lang['photo_fullsize'] = 'Poza mare';
	$lang['photo_report'] = 'Raporteaza';
	$lang['photo_social'] = 'Distribuie';
	$lang['like_button'] = 'Imi place';
	$lang['unlike_button'] = 'Nu imi place';
	$lang['remove_comment'] = 'Sterge';

	// User

	$lang['user_no_photos'] = 'nu are poze';
	$lang['user_no_followers'] = 'nu are abonati';
	$lang['user_no_following'] = 'nu urmareste pe nimeni';
	$lang['user_profile_pic_remove'] = 'Sterge';
	$lang['user_profile_pic_upload'] = 'Incarca poza';
	$lang['user_about'] = 'Despre';
	$lang['user_followers'] = 'Abonati';
	$lang['user_following'] = 'Urmaresc';
	$lang['user_photos'] = 'Poza';
	$lang['user_posts'] = 'Posturi';
	$lang['user_manage_covers'] = 'Imagini cover';
	$lang['user_message'] = 'Mesaj';
	$lang['user_success_1'] = 'Poza a fost modificata';
	$lang['user_success_5'] = 'Video a fost modificat';
	$lang['user_success_2'] = 'Poza a fost stearsa';
	$lang['user_success_6'] = 'Video a fost sters';
	$lang['user_success_3'] = 'Poza de profil a fost schimbata';
	$lang['user_success_4'] = 'Poza de profil a fost stearsa';
	$lang['user_error_1'] = 'Poza nu a fost modificata';
	$lang['user_error_2'] = 'Eroare, incearca din nou';
	$lang['user_error_3'] = 'Este permis doar: JPG, GIF, PNG';
	$lang['user_error_4'] = 'Poza trebuie sa fie mai mare de 180px X 185px';
	$lang['user_edit_photo'] = 'Modifica';
	$lang['user_edit_video'] = 'Modifica';
	$lang['user_remove_photo'] = 'Sterge';
	$lang['user_remove_video'] = 'Sterge';
	$lang['user_remove_cover'] = 'Sterge';
	$lang['user_make_primary'] = 'Principal';
	$lang['user_cancel'] = 'Anuleaza';
	$lang['user_about_general'] = 'Informatii generale';
	$lang['user_about_gender'] = 'Sex';
	$lang['user_about_birthdate'] = 'Data nastere';
	$lang['user_about_location'] = 'Locatie';
	$lang['user_about_country'] = 'Tara';
	$lang['user_about_city'] = 'Oras';
	$lang['user_about_activity'] = 'Activitate';
	$lang['user_about_since'] = 'Inregistrat';
	$lang['user_about_seen'] = 'Ultima activitate';
	$lang['user_about_social'] = 'Conturi sociale';
	$lang['user_about_no_social'] = 'Nu are conturi sociale';
	$lang['user_about_description'] = 'Despre';

	// Pages
	
	$lang['pages_about'] = 'Despre';
	$lang['pages_terms'] = 'Termeni';
	$lang['pages_privacy'] = 'Privacy';
	$lang['pages_contact'] = 'Contact';
	$lang['menu_language'] = 'Limba';

	// Extra field 1.0.4

	$lang['settings_err_12'] = 'Parola curenta este gresita';
	$lang['pages_faq'] = 'Intrebari';
	$lang['browse_title_photos'] = 'Browse photos';
	$lang['browse_title_posts'] = 'Browse posts';
	$lang['browse_no_posts'] = '0 postari';
	$lang['browse_no_photos'] = '0 rezultate';
	$lang['browse_filter'] = 'Filtreaza';
	$lang['browse_filter_1'] = 'Toate';
	$lang['browse_filter_2'] = 'Poza';
	$lang['browse_filter_3'] = 'Video';
	$lang['home_new_posts'] = 'Ce este nou?';
	$lang['home_new_posts_desc'] = 'Ultimele posturi publice';
	$lang['home_terms'] = 'Apasand inregistrare esti de acord cu <span style="font-weight:bold;">Regulamentul</span>';
	$lang['footer_copyright'] = 'Toate drepturile rezervate BindCode';
	$lang['upload_photos_1'] = 'Selecteaza poze';
	$lang['upload_photos_2'] = 'Adauga via URL';
	$lang['upload_photo_input'] = 'URL poza';
	$lang['upload_more'] = 'Adauga +1';
	$lang['upload_photos_button'] = 'Incarca';
	$lang['settings_privacy_title_1'] = 'Cine poate vedea postarile';
	$lang['settings_privacy_title_2'] = 'Cine poate trimite mesaj';
	$lang['settings_privacy_title_3'] = 'Notificari e-mail';
	$lang['settings_privacy_option_1'] = 'Oricine';
	$lang['settings_privacy_option_2'] = 'Abonati';
	$lang['settings_privacy_option_3'] = 'Da';
	$lang['settings_privacy_option_4'] = 'Nu';
	$lang['header_menu_invite'] = 'Invita';
	$lang['only_followers_restrict'] = 'Doar abonatii imi pot trimite mesaj';
	$lang['only_followers_restrict_2'] = 'Doar abonatii imi pot vedea postarile';
	$lang['users_filter_name'] = 'Filtreaza nume';
	$lang['uploading'] = 'Incarcare';
	$lang['upload_limit'] = 'Limita poze %limit%';
	$lang['upload_error'] = 'Pozele tale nu au fost adaugate';
?>