<?php
	require_once('../config.php');

	$return = array('error' => 0, 'files' => array());

	if(isset($_COOKIE['logged']) && isset($_POST['video_id']) && isset($_POST['video_u']) && count($_POST['video_u']) > 0 && count($_POST['video_id']) > 0 && isset($_POST['video_desc']) && count($_POST['video_desc']) > 0) {
	
		for($i=0;$i<=count($_POST['video_id'])-1;$i++) {

			$video_u = safe_string($_POST['video_u'][$i]);
			$video_id = safe_string($_POST['video_id'][$i]);
			if(isset($_POST['video_desc'][$i]) && $_POST['video_desc'][$i] != '') {

				$desc = strip_tags($_POST['video_desc'][$i]);
				$desc = mysqli_real_escape_string($db,htmlentities($desc,ENT_QUOTES));

				
			} else {

				$desc = '';

			}

			if(file_exists($folder.'/uploads/photos/'.$video_u.'.jpg') == 1) {

				mysqli_query($db,"INSERT INTO `photos` (`url`,`time`,`photo`,`desc`,`uid`,`type`) VALUES ('".$video_id."','".time()."','".$video_u."','".$desc."','".$user_id."','1')");
				
				$return['files'][] = array(
					'error' => 0,
					'id' => mysqli_insert_id($db),
					'time' => timeAgo(time()),
					'photo' => $settings['site_url'].'/thumbs.php?src=uploads/photos/'.$video_u.'.jpg&w=250&h=220&zc=1',
					'url' => $video_id,
					'type' => 1
				);
		
			}

		}

	} else {

		$return['error'] = 1;

	}

	if(count($return['files']) == 0) {
		$return['error'] = 1;
	}

	print_r(json_encode($return));
?>