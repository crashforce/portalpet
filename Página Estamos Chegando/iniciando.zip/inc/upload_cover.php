<?php
	require_once('../config.php');

	if(count($_FILES) > 0 && $_FILES['file']['error'] == 0 && isset($_COOKIE['logged'])) {
		
		$unique_id = unique_id();

		if($_FILES['file']['type'] == 'image/jpeg') { $type = 1; }
		if($_FILES['file']['type'] == 'image/png') { $type = 2; }
		if($_FILES['file']['type'] == 'image/gif') { $type = 3; }
		if($_FILES['file']['type'] == 'image/jpg') { $type = 4; }

		if(isset($type) && $type < 5) {

			if(move_uploaded_file($_FILES['file']['tmp_name'],$folder.'/uploads/covers/'.$unique_id.'.jpg')) {
			
				list($width, $height, $type, $attr) = getimagesize($folder.'/uploads/covers/'.$unique_id.'.jpg');

				if($width < 600 || $height < 300) {

					echo 2;

				} else {

					copy($settings['site_url'].'/thumbs.php?src=uploads/covers/'.$unique_id.'.jpg&w=1135',$folder.'/uploads/covers/'.$unique_id.'_2.jpg');
					unlink($folder.'/uploads/covers/'.$unique_id.'.jpg');
					echo $unique_id.'_2';

				}

			}

		} else {

			echo 3; 

		}

	} else {

		echo 4;

	}
?>