<?php
	require_once('../config.php');
	
	if(isset($_POST['email']) && $_POST['email'] !='' && isset($_POST['message']) && $_POST['message'] != '') {

		$email = $_POST['email'];
		$message = safe_string(strip_tags($_POST['message']));

		if(!isset($_SESSION['contact_spam'])) { $time = 1; } else { $time = $_SESSION['contact_spam']; }
	
		if($time < time()) {

			if(send_contact($email,$message)) {

				echo 1;
				$_SESSION['contact_spam'] = time() + 60;

			} else {

				echo 2;

			}


		} else {

			echo 3;

		}

	} else {
			
		echo 4;

	}
?>