<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged']) && isset($_GET['id']) && is_numeric($_GET['id'])) {

		$id = safe_string($_GET['id']);

		$chat_id_1 = '+'.$id.'+_+'.$_COOKIE['logged'].'+';
		$chat_id_2 = '+'.$_COOKIE['logged'].'+_+'.$id.'+';

		$sql_6 = mysqli_query($db,"SELECT `id`,`open`,`conversation`,`read_1`,`read_2`,`chat_id` FROM `chat` WHERE `chat_id` = '".$chat_id_1."' OR `chat_id` = '".$chat_id_2."' LIMIT 1");
		if(mysqli_num_rows($sql_6) > 0) {

			$fetch_6 = mysqli_fetch_array($sql_6);

			$conversation = objectToArray(json_decode($fetch_6['conversation']));
			for($i=0;$i<=count($conversation)-1;$i++) {
				$conversation[$i]['date'] = timeAgo($conversation[$i]['date']);
			}
			print_r(json_encode($conversation));

			if($fetch_6['read_1'] == $_COOKIE['logged'].'_1' || $fetch_6['read_2'] == $_COOKIE['logged'].'_1') {
				if($fetch_6['read_1'] == $_COOKIE['logged'].'_1') {
					$reads = 'read_1';
				} else {
					$reads = 'read_2';
				}
			}

			if($fetch_6['read_1'] == $_COOKIE['logged'].'_1' || $fetch_6['read_2'] == $_COOKIE['logged'].'_1') {
				mysqli_query($db,"UPDATE `chat` SET $reads = '".$_COOKIE['logged']."_0' WHERE `chat_id` = '".$fetch_6['chat_id']."' LIMIT 1");
			}

		} else {

			echo '[]';

		}

	} else {

		echo '[]';

	}
?>