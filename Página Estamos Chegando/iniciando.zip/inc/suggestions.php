<?php
	require_once('../config.php');

	$arr = array();

	if(isset($_COOKIE['logged'])) {

		$followers = get_following('0');

		if(count($followers) > 0) {
			$array = join(',',$followers);
			$sql_33 = mysqli_query($db,"SELECT `id`,`verified`,`user`,`pic`,`name`,`followers` FROM `users` WHERE `id` NOT IN ($array) AND `id` != '".$user_id."' ORDER BY rand() LIMIT 15");
		} else {
			$sql_33 = mysqli_query($db,"SELECT `id`,`verified`,`user`,`pic`,`name`,`followers` FROM `users` WHERE `id` != '".$user_id."' ORDER BY rand() LIMIT 15");
		}

	} else {

		$sql_33 = mysqli_query($db,"SELECT `id`,`user`,`pic`,`name`,`followers` FROM `users` ORDER BY rand() LIMIT 15");

	}

	while($fetch_33 = mysqli_fetch_array($sql_33)) {

		if($fetch_33['followers'] == '' || $fetch_33['followers'] == '[]') {
			$follows_count = 0;
		} else {
			$follows = objectToArray(json_decode($fetch_33['followers']));
			$follows_count = str_to_k(count($follows));
		}

		if($settings['verified'] == 1 && $fetch_33['verified'] == 1) {
			$verified_class = '<img src="'.get_current_host().'/assets/img/verified_small_2.png" />';
		} else {
			$verified_class = '';
		}

		$arr[] = array(
			'uid' => $fetch_33['id'],
			'profile' => $settings['site_url'].'/'.$fetch_33['user'],
			'pic' => $settings['site_url'].'/picture/'.$fetch_33['id'].'/55/55',
			'name' => strip_spam($fetch_33['name']),
			'follows_count' => $follows_count,
			'verified' => $verified_class,
			'profileuser' => $fetch_33['user']
		);
		
	}

	print_r(json_encode($arr));
?>