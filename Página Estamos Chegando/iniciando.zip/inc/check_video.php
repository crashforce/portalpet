<?php
	require_once('../config.php');

	$return = array('error' => 0, 'files' => array());

	if(isset($_COOKIE['logged']) && isset($_POST['video_url']) && count(['video_url']) > 0) {

		for($i=0;$i<=count($_POST['video_url'])-1;$i++) {

			if(preg_match("/(youtube.com|youtu.be)\/(watch)?(\?v=)?(\S+)?/", $_POST['video_url'][$i], $match)){
				
				$video_id = $match[4];
				$url = md5(time() * rand(0,9999999));
			
				copy('http://img.youtube.com/vi/'.$video_id.'/0.jpg',$folder.'/uploads/photos/'.$video_id.'.jpg');
				
				$return['files'][] = array(
					'url' => $url,
					'id' => $video_id
				);

			}

		}

	} else {
		$return['error'] = 1;
	}

	if(count($return['files']) == 0) {
		$return['error'] = 1;
	}

	print_r(json_encode($return));
?>