<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged'])) {

		mysqli_query($db,"UPDATE `users` SET `pic` = '' WHERE `id` = '".$user_id."' LIMIT 1");

	}
?>