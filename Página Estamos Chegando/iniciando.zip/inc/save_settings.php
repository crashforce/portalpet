<?php
ob_start();

	require_once('../config.php');

	if(isset($_COOKIE['logged']) && isset($_POST['type']) && is_numeric($_POST['type'])) {

		$type = safe_string($_POST['type']);

		if($type == 5 && isset($_POST['privacy_1']) && is_numeric($_POST['privacy_1']) && isset($_POST['privacy_2']) && is_numeric($_POST['privacy_2'])) {

			$privacy_1 = safe_string($_POST['privacy_1']);
			$privacy_2 = safe_string($_POST['privacy_2']);
			$privacy_3 = safe_string($_POST['privacy_3']);

			mysqli_query($db,"UPDATE `users` SET `privacy_3` = '".$privacy_3."', `privacy_1` = '".$privacy_1."', `privacy_2` = '".$privacy_2."' WHERE `id` = '".$user_id."' LIMIT 1");
			mysqli_query($db,"UPDATE `photos` SET `privacy` = '".$privacy_1."' WHERE `uid` = '".$user_id."'");
			echo 1;

			setcookie('logged_privacy_1', $privacy_1, time()+86400, '/'); 
			setcookie('logged_privacy_2', $privacy_2, time()+86400, '/'); 
			setcookie('logged_privacy_3', $privacy_3, time()+86400, '/'); 

		}


		if($type == 4 && isset($_POST['new']) && $_POST['new']!='') {

			$new = safe_string($_POST['new']);
			if(isset($_POST['current_pass'])) {
				$current_pass = safe_string($_POST['current_pass']);
			} else {
				$current_pass = '';
			}

			$sql_check_pass = mysqli_query($db,"SELECT `password`,`id` FROM `users` WHERE `password` = '".$current_pass."' AND `id` = '".$user_id."' LIMIT 1");
			if(mysqli_num_rows($sql_check_pass) > 0) {

				if(mysqli_query($db,"UPDATE `users` SET `password` = '".$new."' WHERE `id` = '".$user_id."' LIMIT 1")) {

					echo 1;
					$_SESSION['logged_pass'] = $new;

				} else {

					echo 0;

				}

			} else {
		
				echo 5;

			}

		}

		if($type == 3) {

			$error = 'x';

			if(isset($_POST['facebook']) && $_POST['facebook'] != '') {
				$facebook = safe_string($_POST['facebook']);
				if(validate_url($facebook) == 0) { $error = 5; }
			} else {
				$facebook = '';
			}

			if(isset($_POST['twitter']) && $_POST['twitter'] != '') {
				$twitter = safe_string($_POST['twitter']);
				if(validate_url($twitter) == 0) { $error = 6; }
			} else {
				$twitter = '';
			}

			if(isset($_POST['google']) && $_POST['google'] != '') {
				$google = safe_string($_POST['google']);
				if(validate_url($google) == 0) { $error = 7; }
			} else {
				$google = '';
			}

			if(isset($_POST['pinterest']) && $_POST['pinterest'] != '') {
				$pinterest = safe_string($_POST['pinterest']);
				if(validate_url($pinterest) == 0) { $error = 8; }
			} else {
				$pinterest = '';
			}

			if($error != 'x') {

				echo $error;

			} else {

				$socials = array('facebook' => $facebook, 'twitter' => $twitter, 'google' => $google, 'pinterest' => $pinterest);

				if(mysqli_query($db,"UPDATE `users` SET `social` = '".json_encode($socials)."' WHERE `id` = '".$user_id."' LIMIT 1")) {

					echo 1;

					$social_decode = $social;

					if(isset($social_decode['facebook'])) {
						setcookie('logged_social_facebook', $social_decode['facebook'], time()+86400, '/'); 
					} else {
						setcookie('logged_social_facebook', '', time()+86400, '/');
					}

					if(isset($social_decode['google'])) {
						setcookie('logged_social_google', $social_decode['google'], time()+86400, '/'); 
					} else {
						setcookie('logged_social_google', '', time()+86400, '/');
					}

					if(isset($social_decode['twitter'])) {
						setcookie('logged_social_twitter', $social_decode['twitter'], time()+86400, '/'); 
					} else {
						setcookie('logged_social_twitter', '', time()+86400, '/');
					}

					if(isset($social_decode['pinterest'])) {
						setcookie('logged_social_pinterest', $social_decode['pinterst'], time()+86400, '/'); 
					} else {
						setcookie('logged_social_pinterest', '', time()+86400, '/');
					}
		
				} else {

					echo 0;

				}

			}

		}

		if($type == 2 && isset($_POST['birthdate']) && $_POST['birthdate'] != '') {

			$born = strtotime($_POST['birthdate']);
			if(isset($_POST['desc'])) { $desc = strip_spam($_POST['desc']); } else { $desc = ''; }
			$query = "`born` = '".$born."'";

			if(isset($_POST['gender']) && is_numeric($_POST['gender'])) {
				$gender = safe_string($_POST['gender']);
			} else {
				$gender = 2;
			}

			$query.= ", `gender` = '".$gender."'";
			$query.= ",`about_me` = '".$desc."'";

			if(isset($_POST['country']) && $_POST['country'] != '') {
				$country = safe_string($_POST['country']);
			} else {
				$country = '';
			}

			if(isset($_POST['city']) && $_POST['city']!= '') {
				$city = safe_string($_POST['city']);
			} else {
				$city = '';
			}

			$location = array('country' => $country, 'city' => $city);
			$query.= ",`location` = '".my_json_encode($location)."'";

			if(mysqli_query($db,"UPDATE `users` SET $query WHERE `id` = '".$user_id."' LIMIT 1")) {

				echo 1;

				setcookie("logged_gender", $gender, time()+86400);

				$location_decode = $location;

				if(isset($location_decode['country'])) {
					setcookie('logged_social_country', $location_decode['country'], time()+86400, '/'); 
				} else {
					setcookie('logged_social_country', '', time()+86400, '/');
				}

				if(isset($location_decode['city'])) {
					setcookie('logged_social_city', $location_decode['city'], time()+86400, '/'); 
				} else {
					setcookie('logged_social_city', '', time()+86400, '/');
				}

				setcookie('logged_born', $born, time()+86400, '/');
				setcookie('logged_desc', html_entity_decode(stripslashes($desc),ENT_QUOTES), time()+86400, '/');

			} else {

				echo 2;
		
			}

		}

		if($type == 1 && isset($_POST['name']) && $_POST['name'] !='' && isset($_POST['username']) && $_POST['username']!='' && isset($_POST['email']) && $_POST['email']!='') {

			$name = safe_string($_POST['name']);
			$username = safe_string($_POST['username']);
			$email = safe_string($_POST['email']);

			$error = 'x';

			$query = "`name` = '".$name."'";

			if($email != $_COOKIE['logged_user']) {

				$query.= ",`email` = '".$email."'";

			}

			if($username != $_COOKIE['logged_user']) {

				if(strlen($username) < 2) {
		
					$error = 3;

				} else {

					if(check_username($username) == 0) { 

						$error = 3;

					} else {

						$query.= ",`user` = '".$username."'";

					}

				}

			}

			if($error == 'x') {

				if(mysqli_query($db,"UPDATE `users` SET $query WHERE `id` = '".$user_id."' LIMIT 1")) {

					echo 1;

					setcookie('logged_name', strip_spam($name), time()+86400, '/');
					setcookie('logged_user', $username, time()+86400, '/');
					setcookie('logged_profile', $settings['site_url'].'/'.$username, time()+86400, '/');
					setcookie('logged_email', $email, time()+86400, '/');

				} else {

					echo 2;

				}

			} else {

				echo $error;

			}

		}

	} else {

		echo 0;

	}

ob_end_flush();
?>