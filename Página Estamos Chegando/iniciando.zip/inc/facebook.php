<?php
ob_start();

	require_once('../config.php');

	$return = array('error' => 0);

	if(isset($_POST['response']) && $_POST['response'] != '') {

		$response = $_POST['response'];

		if(isset($response['email']) && $response['email'] != '') {
			$email = $response['email'];
		} else {
			$email = 'test';
		}

		$name = $response['name'];
		$gen = $response['gender'];

		$gender = '';

		if($gen == 'female') { $gender = 1; } else { $gender = 2; }
		if($gender == '') { $gender = 2; }

		$user = unique_username($name,$email);
		
		if($email == 'test') {
			$email = '';
		}

		if($email != '') {
			$sql_70 = mysqli_query($db,"SELECT `id`,`email`,`privacy_3`,`privacy_2`,`privacy_1`,`time`,`about_me`,`password`,`gender`,`born`,`social`,`location`,`user`,`name` FROM `users` WHERE `email` = '".$email."' OR `user` = '".$user."' LIMIT 1");
		} else {
			$sql_70 = mysqli_query($db,"SELECT `id`,`email`,`privacy_3`,`privacy_2`,`privacy_1`,`time`,`about_me`,`password`,`gender`,`born`,`social`,`location`,`user`,`name` FROM `users` WHERE `name` = '".$name."' LIMIT 1");
		}

		if(mysqli_num_rows($sql_70) == 0) {
			$sql_70 = mysqli_query($db,"SELECT `id`,`email`,`privacy_3`,`privacy_2`,`privacy_1`,`time`,`about_me`,`password`,`gender`,`born`,`social`,`location`,`user`,`name` FROM `users` WHERE `email` = '".$email."' OR `user` = '".$user."' LIMIT 1");
		}

		if(mysqli_num_rows($sql_70) > 0) {

			$fetch_70 = mysqli_fetch_array($sql_70);

			setcookie('logged_security', md5($fetch_70['time']), time()+86400, '/');

			$social_decode = objectToArray(json_decode($fetch_70['social']));
			$location_decode = objectToArray(json_decode($fetch_70['location']));

			if(isset($location_decode['country'])) {
				setcookie('logged_social_country', $location_decode['country'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_country', '', time()+86400, '/');
			}

			if(isset($location_decode['city'])) {
				setcookie('logged_social_city', $location_decode['city'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_city', '', time()+86400, '/');
			}

			if(isset($social_decode['facebook'])) {
				setcookie('logged_social_facebook', $social_decode['facebook'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_facebook', '', time()+86400, '/');
			}

			if(isset($social_decode['google'])) {
				setcookie('logged_social_google', $social_decode['google'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_google', '', time()+86400, '/');
			}

			if(isset($social_decode['twitter'])) {
				setcookie('logged_social_twitter', $social_decode['twitter'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_twitter', '', time()+86400, '/');
			}

			if(isset($social_decode['pinterest'])) {
				setcookie('logged_social_pinterest', $social_decode['pinterst'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_pinterest', '', time()+86400, '/');
			}


			setcookie('logged', $fetch_70['id'], time()+86400, '/'); 
			setcookie('logged_gender', $fetch_70['gender'], time()+86400, '/'); 
			setcookie('logged_name', strip_spam($fetch_70['name']), time()+86400, '/'); 
			setcookie('logged_profile', $settings['site_url'].'/'.$fetch_70['user'], time()+86400, '/'); 
			setcookie('logged_user', $fetch_70['user'], time()+86400, '/'); 
			setcookie('logged_email', $fetch_70['email'], time()+86400, '/'); 
			setcookie('logged_born', $fetch_70['born'], time()+86400, '/'); 
			setcookie('logged_desc', html_entity_decode(stripslashes($fetch_70['about_me']),ENT_QUOTES), time()+86400, '/'); 
			setcookie('logged_privacy_1', $fetch_70['privacy_1'], time()+86400, '/');
			setcookie('logged_privacy_2', $fetch_70['privacy_2'], time()+86400, '/');
			setcookie('logged_privacy_3', $fetch_70['privacy_3'], time()+86400, '/');

			$return['error'] = 0;
			$return['logged'] = $fetch_70['id'];
			$return['profile'] = $fetch_70['user'];
			$return['id'] = $fetch_70['id'];

	
		} else {

			$time_join = time();

			if(mysqli_query($db,"INSERT INTO `users` (`user`,`email`,`name`,`gender`,`time`) VALUES ('".$user."','".$email."','".$name."','".$gender."','".$time_join."')")) {

				$user_join_id = mysqli_insert_id($db);
				add_activity('5',$user_join_id);

				$return['error'] = 0;
				$return['logged'] = $user_join_id;
				$return['profile'] = $user;
				$return['id'] = $user_join_id;

				setcookie('logged_security', md5($time_join), time()+86400, '/');
				setcookie('logged', $user_join_id, time()+86400, '/'); 
				setcookie('logged_gender', $gender, time()+86400, '/'); 
				setcookie('logged_name', strip_spam($name), time()+86400, '/'); 
				setcookie('logged_profile', $settings['site_url'].'/'.$user, time()+86400, '/'); 
				setcookie('logged_user', $user, time()+86400, '/'); 
				setcookie('logged_email', $email, time()+86400, '/'); 
				setcookie('logged_born', '0', time()+86400, '/');
				setcookie('logged_social_country', '', time()+86400, '/');
				setcookie('logged_social_city', '', time()+86400, '/');
				setcookie('logged_social_facebook', '', time()+86400, '/');
				setcookie('logged_social_google', '', time()+86400, '/');
				setcookie('logged_social_twitter', '', time()+86400, '/');
				setcookie('logged_social_pinterest', '', time()+86400, '/');
				setcookie('logged_desc', '', time()+86400, '/'); 
				setcookie('logged_privacy_1', '0', time()+86400, '/');
				setcookie('logged_privacy_2', '0', time()+86400, '/');
				setcookie('logged_privacy_3', '0', time()+86400, '/');

			}

		}
		
	} else {

		$return['error'] = 1;

	}

	print_r(json_encode($return));

ob_end_flush();
?>