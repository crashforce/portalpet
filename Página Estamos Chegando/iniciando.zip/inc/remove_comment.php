<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged'])) {

		if(isset($_POST['id']) && $_POST['id']!='') {
	
			$id = safe_string($_POST['id']);

			$sql_10 = mysqli_query($db,"SELECT `id`,`from`,`to` FROM `comments` WHERE `id` = '".$id."' AND `from` = '".$_COOKIE['logged']."' LIMIT 1");
			if(mysqli_num_rows($sql_10) > 0) {

				$fetch_10 = mysqli_fetch_array($sql_10);
				$sql_11 = mysqli_query($db,"SELECT `id`,`url`,`comments` FROM `photos` WHERE `url` = '".$fetch_10['to']."' LIMIT 1");
				$fetch_11 = mysqli_fetch_array($sql_11);
					
				mysqli_query($db,"UPDATE `photos` SET `comments` = '".($fetch_11['comments']-1)."' WHERE `url` = '".$fetch_11['url']."' LIMIT 1");
				mysqli_query($db,"DELETE FROM `comments` WHERE `id` = '".$id."' AND `from` = '".$_COOKIE['logged']."' LIMIT 1");
				echo 1;
		
			} else {

				echo 2;

			}

		} else {

			echo 3;

		}

	} else {

		echo 4;

	}
?>