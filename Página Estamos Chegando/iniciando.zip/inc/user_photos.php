<?php
	require_once('../config.php');

	$arr = array();

	if(isset($_GET['uid']) && is_numeric($_GET['uid'])) {

		$uid = safe_string($_GET['uid']);

		if($settings['video'] == 1) {
			$video_on = '2';
		} else {
			$video_on = '1';
		}

		if(isset($_GET['id']) && $_GET['id']!='x') {

			$id = safe_string($_GET['id']);
			$sql_20 = mysqli_query($db,"SELECT `id`,`url`,`type`,`uid`,`time`,`photo`,`votes`,`views`,`score`,`comments` FROM `photos` WHERE `type` != '".$video_on."' AND (`uid` = '".$uid."' AND `id` < '".$id."') ORDER BY `id` DESC LIMIT 16");

		} else {

			$sql_20 = mysqli_query($db,"SELECT `id`,`url`,`type`,`uid`,`time`,`photo`,`votes`,`views`,`score`,`comments` FROM `photos` WHERE `uid` = '".$uid."' AND `type` != '".$video_on."' ORDER BY `id` DESC LIMIT 16");

		}
	
		while($fetch_20 = mysqli_fetch_array($sql_20)) {

			$arr[] = array(
				'id' => $fetch_20['id'],
				'photo' => $settings['site_url'].'/thumbs.php?src=uploads/photos/'.$fetch_20['photo'].'.jpg&w=300&h=250&zc=1',
				'votes' => $fetch_20['votes'],
				'views' => $fetch_20['views'],
				'score' => $fetch_20['score'],
				'comments' => $fetch_20['comments'],
				'time' => timeAgo($fetch_20['time']),
				'url' => $fetch_20['url'],
				'type' => $fetch_20['type']
			);

		}

	}

	print_r(json_encode($arr));
?>