<?php
	require_once('../config.php');

	$arr = array();

	if($settings['video'] == 1) {
		$video_on = '2';
	} else {
		$video_on = '1';
	}

	if(isset($_POST['filter']) && is_numeric($_POST['filter'])) {
		
		if($_POST['filter'] == 0) {
			$video_on = 2;
		}

		if($_POST['filter'] == 1) {
			$video_on = 1;
		}

		if($_POST['filter'] == 2) {
			$video_on = 0;
		}

	}

	if(isset($_POST['id']) && is_numeric($_POST['id'])) {

		$id = mysqli_real_escape_string($db,$_POST['id']);
		if($id == 0) { $id = '9999999999999999999'; }
		$sql_18 = mysqli_query($db,"SELECT `id`,`privacy`,`url`,`type`,`uid`,`photo`,`time`,`views`,`votes`,`score`,`comments` FROM `photos` WHERE `type` != '".$video_on."' AND (`id` < '".$id."' AND `privacy` = '0') ORDER BY `id` DESC LIMIT 15");

	} else {
		
		$sql_18 = mysqli_query($db,"SELECT `id`,`privacy`,`url`,`type`,`uid`,`photo`,`time`,`views`,`votes`,`score`,`comments` FROM `photos` WHERE `type` != '".$video_on."' AND (`id` < '999999999999999' AND `privacy` = '0') ORDER BY `id` DESC LIMIT 15");

	}

	while($fetch_18 = mysqli_fetch_array($sql_18)) {

		$sql_19 = mysqli_query($db,"SELECT `id`,`name`,`user` FROM `users` WHERE `id` = '".$fetch_18['uid']."' LIMIT 1");
		$fetch_19 = mysqli_fetch_array($sql_19);

		$arr[] = array(
			'id' => $fetch_18['id'],
			'time' => timeAgo($fetch_18['time']),
			'views' => $fetch_18['views'],
			'votes' => $fetch_18['votes'],
			'score' => $fetch_18['score'],
			'comments' => $fetch_18['comments'],
			'name' => strip_spam($fetch_19['name']),
			'photo' => $settings['site_url'].'/thumbs.php?src=uploads/photos/'.$fetch_18['photo'].'.jpg&w=260&h=190&zc=1',
			'uphoto' => $settings['site_url'].'/picture/'.$fetch_19['id'].'/45/45',
			'uid' => $fetch_19['id'],
			'time_count' => $fetch_18['time'],
			'username' => $fetch_19['id'],
			'profile' => $settings['site_url'].'/'.$fetch_19['user'],
			'profileuser' => $fetch_19['user'],
			'url' => $fetch_18['url'],
			'type' => $fetch_18['type']
		);

	}

	print_r(json_encode($arr));
?>