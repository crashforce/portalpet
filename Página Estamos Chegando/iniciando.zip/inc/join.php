<?php
	require_once('../config.php');

	if(isset($_POST['email']) && $_POST['email']!='' && isset($_POST['password']) && $_POST['password']!='' && isset($_POST['name']) && $_POST['name']!='' && isset($_POST['gender']) && $_POST['gender'] != '') {
	
		$name = safe_string($_POST['name']);
		$email = safe_string($_POST['email']);
		$password = safe_string($_POST['password']);
		$gender = safe_string($_POST['gender']);

		if($gender == 'm') { $gender = 2; } else { $gender = 1; }

		$sql_7 = mysqli_query($db,"SELECT `email` FROM `users` WHERE `email` = '".$email."' LIMIT 1");
		if(mysqli_num_rows($sql_7) > 0) {

			echo 2;

		} else {
		
			$user = unique_username($name,$email);

			mysqli_query($db,"INSERT INTO `users` (`name`,`email`,`password`,`gender`,`time`,`user`) VALUES ('".$name."','".$email."','".$password."','".$gender."','".time()."','".$user."')");
	
			$user_join_id = mysqli_insert_id($db);
			add_activity('5',$user_join_id);

			echo 1;
		
		}

	} else {

		echo 3;

	}
?>