<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged']) && isset($_POST['to']) && is_numeric($_POST['to']) && isset($_POST['message']) && $_POST['message']!='') {

		$to = safe_string($_POST['to']);
		$message = htmlspecialchars(stripslashes($_POST['message']),ENT_QUOTES,'UTF-8');

		$chat_id_1 = '+'.$to.'+_+'.$_COOKIE['logged'].'+';
		$chat_id_2 = '+'.$_COOKIE['logged'].'+_+'.$to.'+';

		$sql_6 = mysqli_query($db,"SELECT `id`,`chat_id`,`read_1`,`read_2`,`conversation` FROM `chat` WHERE `chat_id` = '".$chat_id_1."' OR `chat_id` = '".$chat_id_2."' LIMIT 1");
		if(mysqli_num_rows($sql_6) == 0) {

			$conversation = array();
			$conversation[] = array(
				'to' => $to,
				'date' => time(),
				'message' => $message
			);

			$save_conversation = my_json_encode($conversation);

			if(isset($_SESSION['chat_spam']) && isset($_SESSION['chat_last'])) {
				
				if($message == $_SESSION['chat_last'] && time() == $_SESSION['chat_spam']) {

					echo '[]';

				} else {

					mysqli_query($db,"INSERT INTO `chat` (`last`,`date`,`open`,`chat_id`,`conversation`,`read_1`) VALUES ('".$message."','".time()."','".$_COOKIE['logged']."','".$chat_id_1."','".$save_conversation."','".$to."_1')");

				}

			} else {

				$_SESSION['chat_last'] = $message;
				$_SESSION['chat_spam'] = time()+3;
			
				mysqli_query($db,"INSERT INTO `chat` (`last`,`date`,`open`,`chat_id`,`conversation`,`read_1`) VALUES ('".$message."','".time()."','".$_COOKIE['logged']."','".$chat_id_1."','".$save_conversation."','".$to."_1')");
			
			}

			$msg_s = strip_spam($message);

			if($settings['comments_icons'] == 1) {
				$msg_s = '<div style="float:left;">'.$msg_s.'</div>';
				$msg_s = str_replace(':):','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/3.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':D','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/1.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':))','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/2.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':((','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/6.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':(','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/4.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':O','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/5.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(';)','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/7.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':)','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/8.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
			}

			$return = array(
				'id' => 0,
				'to' => $to,
				'date' => timeAgo(time()),
				'message' => $msg_s
			);

			if(isset($_SESSION['chat_spam']) && isset($_SESSION['chat_last'])) {
				
				if($message == $_SESSION['chat_last'] && time() == $_SESSION['chat_spam']) {

					echo '[]';

				} else {

					print_r(my_json_encode($return));

				}

			} else {

				$_SESSION['chat_last'] = $message;
				$_SESSION['chat_spam'] = time()+3;

				print_r(my_json_encode($return));
			
			}

		} else {
				
			$fetch_6 = mysqli_fetch_array($sql_6);

			if($fetch_6['read_1'] != '') {
				$read_1 = explode('_',$fetch_6['read_1']);
			} else {
				$read_1 = 'x_0';
			}

			if($fetch_6['read_2'] != '') {
				$read_2 = explode('_',$fetch_6['read_2']);
			} else {
				$read_2 = 'x_0';
			}

			if($read_1[0] == $_COOKIE['logged']) {
				$reads = 'read_2';
			} else {
				$reads = 'read_1';
			}

			$conversation = objectToArray(json_decode($fetch_6['conversation']));
			$conversation[] = array(
				'to' => $to,
				'date' => time(),
				'message' => $message
			);

			$save_conversation = my_json_encode($conversation);

			if(isset($_SESSION['chat_spam']) && isset($_SESSION['chat_last'])) {
				
				if($message == $_SESSION['chat_last'] && time() < $_SESSION['chat_spam']) {

					echo '[]';

				} else {

					mysqli_query($db,"UPDATE `chat` SET `last` = '".$message."', `date` = '".time()."', `$reads` = '".$to."_1', `conversation` = '".$save_conversation."' WHERE `chat_id` = '".$fetch_6['chat_id']."' LIMIT 1") or die(mysqli_error($db));

				}

			} else {

				$_SESSION['chat_last'] = $message;
				$_SESSION['chat_spam'] = time()+3;

				mysqli_query($db,"UPDATE `chat` SET `last` = '".$message."', `date` = '".time()."', `$reads` = '".$to."_1', `conversation` = '".$save_conversation."' WHERE `chat_id` = '".$fetch_6['chat_id']."' LIMIT 1") or die(mysqli_error($db));

			
			}

			$msg_s = strip_spam($message);

			if($settings['comments_icons'] == 1) {
				$msg_s = '<div style="float:left;">'.$msg_s.'</div>';
				$msg_s = str_replace(':):','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/3.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':D','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/1.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':))','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/2.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':((','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/6.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':(','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/4.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':O','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/5.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(';)','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/7.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':)','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/8.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
			}

			$return = array(
				'id' => count(objectToArray(json_decode($save_conversation)))-1,
				'to' => $to,
				'date' => timeAgo(time()),
				'message' => $msg_s
			);

			if(isset($_SESSION['chat_spam']) && isset($_SESSION['chat_last'])) {
				
				if($message == $_SESSION['chat_last'] && time() == $_SESSION['chat_spam']) {

					echo '[]';

				} else {

					print_r(my_json_encode($return));

				}

			} else {

				$_SESSION['chat_last'] = $message;
				$_SESSION['chat_spam'] = time()+3;

				print_r(my_json_encode($return));
			
			}

		} 

	} else {

		echo '[]';

	}
?>