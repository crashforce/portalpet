<?php
	if(isset($_POST['file']) && $_POST['file']!='' && strlen($_POST['file']) < 20) {
		$file = explode('.',$_POST['file']);
		if($file[1] == 'php') {
			setcookie("language", $_POST['file'], time()+(86400*365), "/");
			echo 1;
		} else {
			echo 2;
		}
	}
?>