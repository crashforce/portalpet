<?php
	require_once('../config.php');

	$activity = array();

	if(isset($_COOKIE['logged']) && isset($_GET['id']) && is_numeric($_GET['id'])) {

		$id = safe_string($_GET['id']);

		$sql_52 = mysqli_query($db,"SELECT `id`,`type`,`uid`,`aid`,`content`,`content_id`,`date` FROM `activity` WHERE `uid` = '".$_COOKIE['logged']."' AND `id` < '".$id."' ORDER BY `id` DESC LIMIT 15");
		while($fetch_52 = mysqli_fetch_array($sql_52)) {

			$sql_53 = mysqli_query($db,"SELECT `id`,`name`,`user`,`pic` FROM `users` WHERE `id` = '".$fetch_52['aid']."' LIMIT 1");
			$fetch_53 = mysqli_fetch_array($sql_53);

			if($fetch_52['type'] == 1) {
				$types = '<span class="call_live_profile" data-profileuser="'.$fetch_53['user'].'">'.strip_spam($fetch_53['name']).'</span> '.$lang['activity_rated'];
				$contents = '<a href="'.$settings['site_url'].'/photos/'.$fetch_52['content_id'].'">Rating: '.strip_spam($fetch_52['content']).'</a>';
			}

			if($fetch_52['type'] == 2) {
				$types = '<span class="call_live_profile" data-profileuser="'.$fetch_53['user'].'">'.strip_spam($fetch_53['name']).'</span> '.$lang['activity_commented'];
				$contents = '<a href="'.$settings['site_url'].'/photos/'.$fetch_52['content_id'].'">'.strip_spam($fetch_52['content']).'</a>';
			}

			if($fetch_52['type'] == 3) {
				$types = '<span class="call_live_profile" data-profileuser="'.$fetch_53['user'].'">'.strip_spam($fetch_53['name']).'</span> '.$lang['activity_following'];
				$contents = '';
			}

			if($fetch_52['type'] == 4) {
				$types = '<span class="call_live_profile" data-profileuser="'.$fetch_53['user'].'">'.strip_spam($fetch_53['name']).'</span> '.$lang['activity_no_following'];
				$contents = '';
			}

			if($fetch_52['type'] == 5) {
				$types = $lang['activity_welcome'];
				$contents = '';
			}

			if($fetch_52['type'] == 6) {
				$types = '<span class="call_live_profile" data-profileuser="'.$fetch_53['user'].'">'.strip_spam($fetch_53['name']).'</span> '.$lang['activity_like'];
				$contents = '<a href="'.$settings['site_url'].'/photos/'.$fetch_52['content_id'].'">'.$lang['like_button'].'</a>';
			}

			if($fetch_52['type'] == 7) {
				$types = '<span class="call_live_profile" data-profileuser="'.$fetch_53['user'].'">'.strip_spam($fetch_53['name']).'</span> '.$lang['activity_unlike'];
				$contents = '<a href="'.$settings['site_url'].'/photos/'.$fetch_52['content_id'].'">'.$lang['unlike_button'].'</a>';
			}

			if($fetch_53['id'] == '') {
				$link_photo = get_current_host().'/thumbs.php?src=uploads/profiles/no_profile_pic.jpg&w=50&h=50';
			} else {
				$link_photo = $settings['site_url'].'/picture/'.$fetch_53['id'].'/50/50';
			}

			$activity[] = array(
				'id' => $fetch_52['id'],
				'types' => $types,
				'contents' => $contents,
				'aid' => $fetch_52['aid'],
				'aname' => strip_spam($fetch_53['name']),
				'apic' => $link_photo,
				'aprofile' => $settings['site_url'].'/'.$fetch_53['user'],
				'type' => $fetch_52['type'],
				'content' => strip_spam($fetch_52['content']),
				'content_id' => $fetch_52['content_id'],
				'date' => timeAgo($fetch_52['date'])
			);
				
		}

	}

	print_r(json_encode($activity));
?>