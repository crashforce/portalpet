<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged']) && isset($_POST['fid']) && is_numeric($_POST['fid'])) {

		$fid = safe_string($_POST['fid']);

		if(remove_follower($fid) == 1) {

			add_activity('4',$fid);
			echo 1;
		
		} else {
			
			echo 2;

		}

	} else {
		
		echo 3;

	}
?>