<?php
	require_once('../config.php');
	
	if(isset($_POST['pid']) && $_POST['pid']!='' && isset($_POST['type']) && $_POST['type']!='') {
	
		$id = safe_string($_POST['pid']);
		$type = safe_string($_POST['type']);

		$sql_102 = mysqli_query($db,"SELECT `id`,`url`,`report` FROM `photos` WHERE `url` = '".$id."' AND `report` = '0' LIMIT 1");
		if(mysqli_num_rows($sql_102) > 0) {
			
			mysqli_query($db,"UPDATE `photos` SET `report` = '1' WHERE `url` = '".$id."' LIMIT 1");
			
		}

		echo 1;

	} else {

		echo 2;
	
	}
?>