<?php
	if(isset($_COOKIE['logged'])) {
	
		$logged_social_country = '';
		$logged_social_city = '';
		$logged_social_facebook = '';
		$logged_social_google = '';
		$logged_social_twitter = '';
		$logged_social_pinterest = '';
		$logged_gender = '';
		$logged_name = '';
		$logged_profile = '';
		$logged_user = '';
		$logged_email = '';
		$logged_born = '';
		$logged_desc = '';
		$logged_privacy_1 = '';
		$logged_privacy_2 = '';
		$logged_privacy_3 = '';

		if(isset($_COOKIE['logged_social_country'])) { $logged_social_country = $_COOKIE['logged_social_country']; }
		if(isset($_COOKIE['logged_social_city'])) { $logged_social_city = $_COOKIE['logged_social_city']; }
		if(isset($_COOKIE['logged_social_facebook'])) { $logged_social_facebook = $_COOKIE['logged_social_facebook']; }
		if(isset($_COOKIE['logged_social_google'])) { $logged_social_google = $_COOKIE['logged_social_google']; }
		if(isset($_COOKIE['logged_social_twitter'])) { $logged_social_twitter = $_COOKIE['logged_social_twitter']; }
		if(isset($_COOKIE['logged_social_pinterest'])) { $logged_social_pinterest = $_COOKIE['logged_social_pinterest']; }
		if(isset($_COOKIE['logged_gender'])) { $logged_gender = $_COOKIE['logged_gender']; }
		if(isset($_COOKIE['logged_name'])) { $logged_name = $_COOKIE['logged_name']; }
		if(isset($_COOKIE['logged_profile'])) { $logged_profile = $_COOKIE['logged_profile']; }
		if(isset($_COOKIE['logged_user'])) { $logged_user = $_COOKIE['logged_user']; }
		if(isset($_COOKIE['logged_email'])) { $logged_email = $_COOKIE['logged_email']; }
		if(isset($_COOKIE['logged_born'])) { $logged_born = $_COOKIE['logged_born']; }
		if(isset($_COOKIE['logged_desc'])) { $logged_desc = $_COOKIE['logged_desc']; }
		if(isset($_COOKIE['logged_privacy_1'])) { $logged_privacy_1 = $_COOKIE['logged_privacy_1']; }
		if(isset($_COOKIE['logged_privacy_2'])) { $logged_privacy_2 = $_COOKIE['logged_privacy_2']; }
		if(isset($_COOKIE['logged_privacy_3'])) { $logged_privacy_3 = $_COOKIE['logged_privacy_3']; }

		if($logged_born != '') {
			$birthday = date('j',$logged_born);
			$birthmonth = date('n',$logged_born);
			$birthyear = date('Y',$logged_born);
		} else {
			$birthday = 1;
			$birthmonth = 1;
			$birthyear = 1950;
		}

		$settings = array(
			'error' => 0,
			'logged_social_country' => $logged_social_country,
			'logged_social_city' => $logged_social_city,
			'logged_social_facebook' => $logged_social_facebook,
			'logged_social_google' => $logged_social_google,
			'logged_social_twitter' => $logged_social_twitter,
			'logged_social_pinterest' => $logged_social_pinterest,
			'logged_gender' => $logged_gender, 
			'logged_name' => $logged_name,
			'logged_profile' => $logged_profile,
			'logged_user' => $logged_user,
			'logged_email' => $logged_email,
			'logged_born' => $logged_born,
			'logged_desc' => $logged_desc,
			'logged_privacy_1' => $logged_privacy_1,
			'logged_privacy_2' => $logged_privacy_2,
			'logged_privacy_3' => $logged_privacy_3,
			'birthday' => $birthday,
			'birthmonth' => $birthmonth,
			'birthyear' => $birthyear
		);

	} else {

		$settings = array('error' => 1);

	}

	print_r(json_encode($settings));
?>