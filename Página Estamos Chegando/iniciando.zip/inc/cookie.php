<?php
	setcookie("cookie_ok", "1", time()+(86400*365), "/");
	echo 1;
?>