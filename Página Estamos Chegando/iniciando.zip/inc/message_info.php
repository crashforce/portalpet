<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged']) && isset($_GET['to']) && is_numeric($_GET['to'])) {

		$to = safe_string($_GET['to']);

		$sql_6 = mysqli_query($db,"SELECT `id`,`user`,`name` FROM `users` WHERE `id` = '".$to."' LIMIT 1");
		$fetch_6 = mysqli_fetch_array($sql_6);
	
		$data = array(
			'toname' => strip_spam($fetch_6['name']),
			'topic' => $settings['site_url'].'/picture/'.$fetch_6['id'].'/35/35',
			'toprofile' => $fetch_6['user']
		);

		print_r(json_encode($data));

	} else {

		echo '[]';

	}
?>