<?php
	require_once('../config.php');

	$arr = array();

	if(isset($_COOKIE['logged'])) {

		$count = 0;

		$sql_6 = mysqli_query($db,"SELECT `chat_id`,`read_1`,`read_2` FROM `chat` WHERE `chat_id` LIKE '%+".$_COOKIE['logged']."+%' AND (`read_1` = '".$_COOKIE['logged']."_1' OR `read_2` = '".$_COOKIE['logged']."_1')");
		$unread = mysqli_num_rows($sql_6);
		$sql_7 = mysqli_query($db,"SELECT `uid`,`seen` FROM `activity` WHERE `uid` = '".$_COOKIE['logged']."' AND `seen` = '0'");
		$unseen = mysqli_num_rows($sql_7);

		if($unread > 99) { $unread = 99; }
		if($unseen > 99) { $unseen = 99; } 

		$arr['unread'] = $unread;
		$arr['unseen'] = $unseen;

		mysqli_query($db,"UPDATE `users` SET `seen` = '".time()."' WHERE `id` = '".$_COOKIE['logged']."' LIMIT 1");

	} else {

		$arr['unread'] = 0;
		$arr['unseen'] = 0;

	}

	print_r(json_encode($arr));
?>