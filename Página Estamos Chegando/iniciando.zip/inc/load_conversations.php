<?php
	require_once('../config.php');

	$conversations = array();

	if(isset($_COOKIE['logged']) && isset($_POST['page']) && is_numeric($_POST['page'])) {

		$id = safe_string($_POST['page']);

		$sql_6 = mysqli_query($db,"SELECT `id`,`chat_id`,`open`,`read_1`,`read_2`,`date`,`last` FROM `chat` WHERE `chat_id` LIKE '%+".$_COOKIE['logged']."+%' AND `id` < '".$id."' ORDER BY `date` DESC LIMIT 15");
		$sql_65 = mysqli_query($db,"SELECT `chat_id` FROM `chat` WHERE `chat_id` LIKE '%+".$_COOKIE['logged']."+%'");
		$conversations['count'] = mysqli_num_rows($sql_65);

		while($fetch_6 = mysqli_fetch_array($sql_6)) {

			$chat_id = explode('_',str_replace('+','',$fetch_6['chat_id']));
			if($chat_id[0] == $_COOKIE['logged']) {
				$from = $chat_id[1];
			} else {
				$from = $chat_id[0];
			}

			$sql_48 = mysqli_query($db,"SELECT `id`,`seen`,`name` FROM `users` WHERE `id` = '".$from."' LIMIT 1");
			$fetch_48 = mysqli_fetch_array($sql_48);

			if($fetch_6['read_1'] == $_COOKIE['logged'].'_1' || $fetch_6['read_2'] == $_COOKIE['logged'].'_1') {
				$reads = 1;
			} else {
				$reads = 0;
			}

			$online_check = $fetch_48['seen'] + 15;
			if($online_check > time()) {

				$online = 1;
	
			} else {

				$online = 2;

			}

			if($reads == 1) { $unread = 'messages_result_unread'; } else { $unread = ''; }

			$conversations['data'][] = array(
				'id' => $fetch_6['id'],
				'to' => $from,
				'name' => strip_spam($fetch_48['name']),
				'pic' => $settings['site_url'].'/picture/'.$fetch_48['id'].'/45/45',
				'date' => timeAgo($fetch_6['date']),
				'message' => strip_spam($fetch_6['last']),
				'unread' => $unread,
				'online' => $online
			);

		}

		if(!isset($conversations['data'])) {
			$conversations['data'] = array();
		}

		print_r(json_encode($conversations));

	} else {

		echo '[]';

	}
?>