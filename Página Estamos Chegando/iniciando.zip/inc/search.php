<?php
	require_once('../config.php');

	$arr = array();

	if(isset($_POST['tag']) && $_POST['tag'] != '') {

		if($settings['video'] == 1) {
			$video_on = '2';
		} else {
			$video_on = '1';
		}

		$tag = strip_tags($_POST['tag']);
		$tag = mysqli_real_escape_string($db,htmlentities($tag,ENT_QUOTES));

		if(substr($tag,0,1) == '#') {

			if($settings['hashtags'] == 1) {
				
				$hashtag = str_replace('#','',$tag);
				$sql_31 = mysqli_query($db,"SELECT `desc`,`type`,`url`,`photo` FROM `photos` WHERE `type` != '".$video_on."' AND `desc` LIKE '%#".$hashtag."%' ORDER BY rand() LIMIT 5");
				while($fetch_31 = mysqli_fetch_array($sql_31)) {

					$arr[] = array(
						'id' => $fetch_31['url'],
						'name' => str_replace($tag,'<span style="font-weight:bold;">'.$tag.'</span>',strip_spam($fetch_31['desc'])),
						'pic' => $settings['site_url'].'/thumbs.php?src=uploads/photos/'.$fetch_31['photo'].'.jpg&w=40&h=40&zc=1',
						'username' => $fetch_31['url'],
						'hash' => 1,
						'search_type' => 1,
						'verified' => ''
					);

				}

			}

		} else {

			$sql_31 = mysqli_query($db,"SELECT `id`,`name`,`verified`,`user` FROM `users` WHERE `name` LIKE '%".$tag."%' ORDER BY `name` ASC LIMIT 5");
			while($fetch_31 = mysqli_fetch_array($sql_31)) {

				if($fetch_31['verified'] == 1 && $settings['verified'] == 1) {
					$verified_class = '<img src="'.get_current_host().'/assets/img/verified_small_2.png" />';
				} else {
					$verified_class = '';
				}

				$the_name = ucwords(str_ireplace($tag,'<span style="font-weight:bold;">'.$tag.'</span>',strip_spam($fetch_31['name'])));

				$arr[] = array(
					'id' => $fetch_31['id'],
					'name' => $the_name,
					'pic' => $settings['site_url'].'/picture/'.$fetch_31['id'].'/40/40',
					'username' => $fetch_31['user'],
					'hash' => 0,
					'search_type' => 2,
					'verified' => $verified_class
				);

			}

		}

	}
		
	print_r(json_encode($arr));
?>