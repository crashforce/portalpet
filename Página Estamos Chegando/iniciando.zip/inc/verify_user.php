<?php
	require_once('../config.php');
	
	if(isset($_POST['uid']) && $_POST['uid'] == $_COOKIE['logged']) {

		if(!isset($_SESSION['verify_user'])) { $time = 1; } else { $time = $_SESSION['verify_user']; }
	
		if($time < time()) {

			if(isset($_COOKIE['logged_email'])) {

				$result = send_verify($_COOKIE['logged_email']);

				if($result == 1) {
				
					echo 1;
					$_SESSION['verify_user'] = time() + 60;

				} else {

					echo 3;

				}

			} else {

				echo 2;

			}

		} else {

			echo 4;

		}

	} else {
			
		echo 5;

	}
?>