<?php
ob_start();

	require_once('../config.php');

	$return = array();

	if(isset($_POST['email']) && $_POST['email']!='' && isset($_POST['password']) && $_POST['password']!='') {

		$email = safe_string($_POST['email']);
		$password = safe_string($_POST['password']);

		if(strpos($email,'@')) {
			$type = 'email';
		} else {
			$type = 'user';
		}

		$sql_6 = mysqli_query($db,"SELECT `id`,`privacy_1`,`privacy_2`,`privacy_3`,`email`,`about_me`,`time`,`gender`,`password`,`born`,`social`,`location`,`user`,`name` FROM `users` WHERE $type = '".$email."' AND `password` = '".$password."' LIMIT 1");
		if(mysqli_num_rows($sql_6) > 0) {

			$fetch_6 = mysqli_fetch_array($sql_6);
			$social_decode = objectToArray(json_decode($fetch_6['social']));
			$location_decode = objectToArray(json_decode($fetch_6['location']));

			setcookie('logged_security', md5($fetch_6['time']), time()+86400, '/');

			if(isset($location_decode['country'])) {
				setcookie('logged_social_country', $location_decode['country'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_country', '', time()+86400);
			}

			if(isset($location_decode['city'])) {
				setcookie('logged_social_city', $location_decode['city'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_city', '', time()+86400, '/');
			}

			if(isset($social_decode['facebook'])) {
				setcookie('logged_social_facebook', $social_decode['facebook'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_facebook', '', time()+86400, '/');
			}

			if(isset($social_decode['google'])) {
				setcookie('logged_social_google', $social_decode['google'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_google', '', time()+86400);
			}

			if(isset($social_decode['twitter'])) {
				setcookie('logged_social_twitter', $social_decode['twitter'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_twitter', '', time()+86400, '/');
			}

			if(isset($social_decode['pinterest'])) {
				setcookie('logged_social_pinterest', $social_decode['pinterst'], time()+86400, '/'); 
			} else {
				setcookie('logged_social_pinterest', '', time()+86400, '/');
			}

			setcookie('logged', $fetch_6['id'], time()+86400, '/'); 
			setcookie('logged_gender', $fetch_6['gender'], time()+86400, '/'); 
			setcookie('logged_name', strip_spam($fetch_6['name']), time()+86400, '/'); 
			setcookie('logged_profile', $settings['site_url'].'/'.$fetch_6['user'], time()+86400, '/'); 
			setcookie('logged_user', $fetch_6['user'], time()+86400, '/'); 
			setcookie('logged_email', $fetch_6['email'], time()+86400, '/'); 
			setcookie('logged_born', $fetch_6['born'], time()+86400, '/'); 
			setcookie('logged_desc', html_entity_decode(stripslashes($fetch_6['about_me']),ENT_QUOTES), time()+86400, '/'); 
			setcookie('logged_privacy_1', $fetch_6['privacy_1'], time()+86400, '/');
			setcookie('logged_privacy_2', $fetch_6['privacy_2'], time()+86400, '/');
			setcookie('logged_privacy_3', $fetch_6['privacy_3'], time()+86400, '/');

			$return['error'] = 0;
			$return['logged'] = $fetch_6['id'];
			$return['profile'] = $fetch_6['user'];
			$return['id'] = $fetch_6['id'];

		} else {
		
			$return['error'] = 1;
		
		}

	} else {

		$return['error'] = 1;

	}

	print_r(json_encode($return));

ob_end_flush();
?>