<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged']) && isset($_POST['id']) && is_numeric($_POST['id'])) {

		$id = safe_string($_POST['id']);

		$sql_55 = mysqli_query($db,"SELECT `id`,`seen` FROM `users` WHERE `id` = '".$id."' LIMIT 1");
		$fetch_55 = mysqli_fetch_array($sql_55);

		$check_online = $fetch_55['seen'] + 15;
		if($check_online > time()) {

			echo 1;

		} else {

			echo 2;

		}

	} else {

		echo 0;

	}
?>