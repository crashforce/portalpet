<?php
	require_once('../config.php');

	$return = array('error' => 0, 'files' => array());

	if(isset($_FILES['file_pic']) && count($_FILES['file_pic']['type']) > 0 && isset($_COOKIE['logged'])) {

		for($i=0;$i<=count($_FILES['file_pic'])-1;$i++) {

			if(isset($_FILES['file_pic']['error'][$i]) && $_FILES['file_pic']['error'][$i] == 0) {

				$unique_id = unique_id();

				if($_FILES['file_pic']['type'][$i] == 'image/jpeg') { $type = 1; }
				if($_FILES['file_pic']['type'][$i] == 'image/png') { $type = 2; }
				if($_FILES['file_pic']['type'][$i] == 'image/gif') { $type = 3; }
				if($_FILES['file_pic']['type'][$i] == 'image/jpg') { $type = 4; }

				if($mobile == 1) { $type = 1; }

				if(isset($type) && $type < 5) {

					if(move_uploaded_file($_FILES['file_pic']['tmp_name'][$i],$folder.'/uploads/photos/'.$unique_id.'.jpg')) {

						if($type == 1) { image_fix_orientation($folder.'/uploads/photos/'.$unique_id.'.jpg'); }
						list($width, $height, $type, $attr) = getimagesize($folder.'/uploads/photos/'.$unique_id.'.jpg');

						if($width < 300) {

							$return['error'] = 1;

						} else {

							$crop = '';

							if($width > 601) {

								copy($settings['site_url'].'/thumbs.php?src=uploads/photos/'.$unique_id.'.jpg&w=600&zc=0',$folder.'/uploads/photos/'.$unique_id.'_2.jpg');
								$crop = 1;

							}

							if($height > 601) {
								copy($settings['site_url'].'/thumbs.php?src=uploads/photos/'.$unique_id.'.jpg&h=600&zc=0',$folder.'/uploads/photos/'.$unique_id.'_2.jpg');
								$crop = 1;
							}

							if($crop == 1) {
								list($width, $height, $type, $attr) = getimagesize($folder.'/uploads/photos/'.$unique_id.'_2.jpg');
								if($width > 601) {
									copy($settings['site_url'].'/thumbs.php?src=uploads/photos/'.$unique_id.'_2.jpg&w=600&zc=0',$folder.'/uploads/photos/'.$unique_id.'_2.jpg');
								}
							}

							if($crop == '') {
								copy($folder.'/uploads/photos/'.$unique_id.'.jpg',$folder.'/uploads/photos/'.$unique_id.'_2.jpg');
							}

							$return['files'][] = $unique_id;

						}

					}

				}

			}

		}

	}

	if(isset($_POST['upload_urls']) && count($_POST['upload_urls']) > 0 && isset($_COOKIE['logged'])) {

		for($i=0;$i<=count($_POST['upload_urls'])-1;$i++) {

			if(isset($_POST['upload_urls'][$i]) && validate_url_2($_POST['upload_urls'][$i])) {

				$unique_id = unique_id();

				$header_type = get_headers($_POST['upload_urls'][$i],1);

				if($header_type['Content-Type'] == 'image/jpeg') { $type = 1; }
				if($header_type['Content-Type'] == 'image/png') { $type = 2; }
				if($header_type['Content-Type'] == 'image/gif') { $type = 3; }
				if($header_type['Content-Type'] == 'image/jpg') { $type = 4; }

				if(isset($type) && $type < 5) {

					if(copy($_POST['upload_urls'][$i],$folder.'/uploads/photos/'.$unique_id.'.jpg')) {

						list($width, $height, $type, $attr) = getimagesize($folder.'/uploads/photos/'.$unique_id.'.jpg');

						if($width < 300) {

							$return['error'] = 1;

						} else {

							$crop = '';

							if($width > 601) {

								copy($settings['site_url'].'/thumbs.php?src=uploads/photos/'.$unique_id.'.jpg&w=600&zc=0',$folder.'/uploads/photos/'.$unique_id.'_2.jpg');
								$crop = 1;

							}

							if($height > 601) {
								copy($settings['site_url'].'/thumbs.php?src=uploads/photos/'.$unique_id.'.jpg&h=600&zc=0',$folder.'/uploads/photos/'.$unique_id.'_2.jpg');
								$crop = 1;
							}

							if($crop == 1) {
								list($width, $height, $type, $attr) = getimagesize($folder.'/uploads/photos/'.$unique_id.'_2.jpg');
								if($width > 601) {
									copy($settings['site_url'].'/thumbs.php?src=uploads/photos/'.$unique_id.'_2.jpg&w=600&zc=0',$folder.'/uploads/photos/'.$unique_id.'_2.jpg');
								}
							}

							if($crop == '') {
								copy($folder.'/uploads/photos/'.$unique_id.'.jpg',$folder.'/uploads/photos/'.$unique_id.'_2.jpg');
							}

							$return['files'][] = $unique_id;

						}

					}

				}

			}

		}

	}

	if(count($return['files']) == 0) {

		$return['error'] = 1;

	}

	print_r(json_encode($return));
?>