<?php
	require_once('../config.php');

	if(isset($_GET['id']) && $_GET['id']!='') {

		$id = mysqli_real_escape_string($db,$_GET['id']);

		$sql_11 = mysqli_query($db,"SELECT `id`,`url`,`uid`,`photo`,`type`,`desc`,`votes`,`views`,`score`,`comments`,`time` FROM `photos` WHERE `url` = '".$id."' LIMIT 1");
		$fetch_11 = mysqli_fetch_array($sql_11);

		mysqli_query($db,"UPDATE `photos` SET `views` = '".($fetch_11['views']+1)."' WHERE `url` = '".$id."' LIMIT 1");

		$uid = $fetch_11['uid'];
		$sql_12 = mysqli_query($db,"SELECT `id`,`name`,`user` FROM `users` WHERE `id` = '".$uid."' LIMIT 1");
		$fetch_12 = mysqli_fetch_array($sql_12);

		$rate = check_rate($id);
		if(!isset($_COOKIE['logged'])) { $rate = 1; }

		$arr = array();

		if(isset($_GET['m']) && $_GET['m']==1) {
			$p_size = '35/35';
		} else {
			$p_size = '65/65';
		}

		$arr['p_photo'] = $fetch_11['photo'];

		$get_fullsize = explode('_',$fetch_11['photo']);
		if(file_exists($folder.'/uploads/photos/'.$get_fullsize[0].'.jpg') == 1) {
			$fullsize_photo_1 = $get_fullsize[0];
		} else {
			$fullsize_photo_1 = $fetch_11['photo'];
		}

		$fullsize_photo = '<a href="'.get_current_host().'/uploads/photos/'.$fullsize_photo_1.'.jpg" target="_blank">'.$lang['photo_fullsize'].'</a>';

		$photo_url_link = get_current_host().'/photos/'.$fetch_11['url'];
		$media_url_link = get_current_host().'/uploads/photos/'.$fetch_11['photo'].'.jpg';

		$arr['p_social'] = '
     		<div class="photo_social_share social_share_link" data-type="facebook" data-page="'.$photo_url_link.'">Facebook</div>
      		<div class="photo_social_share social_share_link" data-type="google" data-page="'.$photo_url_link.'">Google+</div>
      		<div class="photo_social_share social_share_link" data-type="twitter" data-page="'.$photo_url_link.'">Twitter</div>
		<div class="photo_social_share social_share_link" data-type="pinterest" data-page="'.$photo_url_link.'" data-media="'.$media_url_link.'">Pinterest</div>';

		$arr['p_fullsize'] = $fullsize_photo;

		if($settings['hashtags'] == 1) {
			if($settings['desc_links'] == 1) {
				$arr['p_desc'] = create_hashtags(create_links(html_entity_decode(strip_tags($fetch_11['desc']),ENT_QUOTES)));
			} else {
				$arr['p_desc'] = create_hashtags(html_entity_decode(strip_tags($fetch_11['desc']),ENT_QUOTES));
			}
		} else {
			if($settings['desc_links'] == 1) {
				$arr['p_desc'] = create_links(html_entity_decode(strip_tags($fetch_11['desc']),ENT_QUOTES));
			} else {
				$arr['p_desc'] = html_entity_decode(strip_tags($fetch_11['desc']),ENT_QUOTES);
			}
		}

		$arr['p_desc'] = create_mention($arr['p_desc']);

		$arr['p_votes'] = $fetch_11['votes'];
		$arr['p_views'] = $fetch_11['views']+1;
		$arr['p_score'] = $fetch_11['score'];
		$arr['p_url'] = $fetch_11['url'];
		$arr['p_comments'] = $fetch_11['comments'];
		$arr['uprofile'] = $settings['site_url'].'/'.$fetch_12['user'];
		$arr['u_name'] = strip_spam($fetch_12['name']);
		$arr['u_pic'] = $settings['site_url'].'/picture/'.$fetch_12['id'].'/'.$p_size;
		$arr['u_time'] = timeAgo($fetch_11['time']);
		$arr['rate_status'] = $rate;
		$arr['type'] = $fetch_11['type'];
		$arr['profileuser'] = $fetch_12['user'];

		if($settings['video'] == 1) {
			$search_type = 2;
		} else {
			$search_type = 1;
		}

		$sql_14 = mysqli_query($db,"SELECT `id`,`type`,`uid`,`url` FROM `photos` WHERE `type` != '".$search_type."' AND (`id` < '".$fetch_11['id']."' AND `uid` = '".$uid."') ORDER BY `id` DESC LIMIT 1");
		$sql_15 = mysqli_query($db,"SELECT `id`,`type`,`uid`,`url` FROM `photos` WHERE `type` != '".$search_type."' AND (`id` > '".$fetch_11['id']."' AND `uid` = '".$uid."') LIMIT 1");

		if(mysqli_num_rows($sql_14) == 0) {
			$n_left = '';
		} else {
			$fetch_14 = mysqli_fetch_array($sql_14);
			$n_left = $fetch_14['url'];
		}

		if(mysqli_num_rows($sql_15) == 0) {
			$n_right = '';
		} else {
			$fetch_15 = mysqli_fetch_array($sql_15);
			$n_right = $fetch_15['url'];
		}

		if($n_left == '' && $n_right == '') {
			$arr['p_nleft'] = '';
			$arr['p_nright'] = '';
		} else {

			if($n_left == '') {
				$arr['p_nleft'] = '';
			} else {
				$arr['p_nleft'] = $n_left;
			}

			if($n_right == '') {
				$arr['p_nright'] = '';
			} else {	
				$arr['p_nright'] = $n_right;
			}

		}

		print_r(json_encode($arr));

	}
?>