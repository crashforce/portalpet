<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged'])) {

		if(isset($_POST['id']) && $_POST['id']!='') {
	
			$id = safe_string($_POST['id']);

			$sql_10 = mysqli_query($db,"SELECT `id`,`uid` FROM `photos` WHERE `uid` = '".$user_id."' AND `url` = '".$id."' LIMIT 1");
			if(mysqli_num_rows($sql_10) > 0) {

				mysqli_query($db,"DELETE FROM `photos` WHERE `url` = '".$id."' AND `uid` = '".$user_id."' LIMIT 1");
				echo 1;
		
			} else {

				echo 2;

			}

		} else {

			echo 3;

		}

	} else {

		echo 4;

	}
?>