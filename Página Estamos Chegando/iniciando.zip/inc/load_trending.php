<?php
	require_once('../config.php');

	$arr = array();

	$followers = get_following('0');

	if($settings['video'] == 1) {
		$video_on = '2';
	} else {
		$video_on = '1';
	}

	if(isset($_GET['id']) && is_numeric($_GET['id'])) {

		$id = mysqli_real_escape_string($db,$_GET['id']);

		if(count($followers) == 0) {
			$sql_18 = mysqli_query($db,"SELECT `id`,`type`,`url`,`uid`,`photo`,`time`,`views`,`votes`,`score`,`comments` FROM `photos` WHERE `type` != '".$video_on."' AND (`id` < '".$id."' AND `uid` = '999999999999999') ORDER BY `views` DESC LIMIT 15");
		} else {
			$array = join(',',$followers);
			$sql_18 = mysqli_query($db,"SELECT `id`,`type`,`url`,`uid`,`photo`,`time`,`views`,`votes`,`score`,`comments` FROM `photos` WHERE `type` != '".$video_on."' AND (`id` < '".$id."' AND `uid` IN ($array)) ORDER BY `views` DESC LIMIT 15");
		}

	} else {
		
		if(count($followers) == 0) {	
			$sql_18 = mysqli_query($db,"SELECT `id`,`type`,`url`,`uid`,`photo`,`time`,`views`,`votes`,`score`,`comments` FROM `photos` WHERE `type` != '".$video_on."' AND `uid` = '999999999999999' ORDER BY `views` DESC LIMIT 15");
		} else {
			if(count($followers) == 1) {
				$sql_18 = mysqli_query($db,"SELECT `id`,`type`,`url`,`uid`,`photo`,`time`,`views`,`votes`,`score`,`comments` FROM `photos` WHERE `type` != '".$video_on."' AND `uid` = '".$followers[0]."' ORDER BY `views` DESC LIMIT 15");
			} else {
				$array = join(',',$followers);
				$sql_18 = mysqli_query($db,"SELECT `id`,`type`,`url`,`uid`,`photo`,`time`,`views`,`votes`,`score`,`comments` FROM `photos` WHERE `type` != '".$video_on."' AND `uid` IN ($array) ORDER BY `views` DESC LIMIT 15");
			}
		}
		
	}

	while($fetch_18 = mysqli_fetch_array($sql_18)) {

		$sql_19 = mysqli_query($db,"SELECT `id`,`name`,`user` FROM `users` WHERE `id` = '".$fetch_18['uid']."' LIMIT 1");
		$fetch_19 = mysqli_fetch_array($sql_19);

		$arr[] = array(
			'id' => $fetch_18['id'],
			'time' => timeAgo($fetch_18['time']),
			'views' => $fetch_18['views'],
			'votes' => $fetch_18['votes'],
			'score' => $fetch_18['score'],
			'url' => $fetch_18['url'],
			'comments' => $fetch_18['comments'],
			'name' => strip_spam($fetch_19['name']),
			'photo' => $settings['site_url'].'/thumbs.php?src=uploads/photos/'.$fetch_18['photo'].'.jpg&w=260&h=190&zc=1',
			'uphoto' => $settings['site_url'].'/picture/'.$fetch_19['id'].'/45/45',
			'uid' => $fetch_19['id'],
			'time_count' => $fetch_18['time'],
			'username' => $fetch_19['id'],
			'profile' => $settings['site_url'].'/'.$fetch_19['user'],
			'profileuser' => $fetch_19['user'],
			'type' => $fetch_18['type']
		);

	}

	print_r(json_encode($arr));
?>