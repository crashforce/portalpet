<?php
	require_once('../config.php');
	
	if(isset($_POST['email']) && $_POST['email'] !='') {

		$email = safe_string($_POST['email']);

		if(!isset($_SESSION['lostpw'])) { $time = 1; } else { $time = $_SESSION['lostpw']; }
	
		if($time < time()) {

			if(email_exists($email) == 1) {

				if(send_recover($email) == 1) {
				
					echo 1;
					$_SESSION['lostpw'] = time() + 60;

				} else {

					echo 2;

				}

			} else {

				echo 2;

			}

		} else {

			echo 4;

		}

	} else {
			
		echo 3;

	}
?>