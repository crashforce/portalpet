<?php
	require_once('../config.php');

	$return = array();

	if(isset($_POST) && count($_POST) > 0 && isset($_COOKIE['logged'])) {

		$x = safe_string($_POST['x']);
		$y = safe_string($_POST['y']);
		$w = safe_string($_POST['w']);
		$h = safe_string($_POST['h']);
		
		$img = $_POST['img'];
		$img_t = str_replace('uploads/covers/','',$img);
		$img_t = str_replace('.jpg','',$img_t);

		if(isset($img_t) && $img_t != '') {

			$imgSrc = $folder.'/uploads/covers/'.$img_t.'.jpg';	
			$save_as = $folder.'/uploads/covers/'.$img_t.'_2.jpg';

			list($width, $height, $type) = @getimagesize($imgSrc);

			if($type == 3) { $myImage = imagecreatefrompng($imgSrc); }
			if($type == 2) { $myImage = imagecreatefromjpeg($imgSrc); }
			if($type == 1) { $myImage = imagecreatefromgif($imgSrc); }

			$thumb = imagecreatetruecolor(1135, 300);
			imagealphablending($thumb,true);

 			imagecopyresampled($thumb, $myImage, 0, 0, 0, $y, 1135, 300, 1135, 300);
			
			imagealphablending($thumb,false);
			imagesavealpha($thumb,true);

 			imagejpeg($thumb, $save_as);

			$sql_56 = mysqli_query($db,"SELECT `id`,`cover` FROM `users` WHERE `id` = '".$user_id."' LIMIT 1");
			$fetch_56 = mysqli_fetch_array($sql_56);

			$get_covers = json_decode($fetch_56['cover']);

			if($get_covers == '' || $get_covers == '[]') {
				$covers = array();
			} else {
				$covers = objectToArray($get_covers);
			}

			$covers[] = $img_t.'_2';

			$set_covers = json_encode($covers);

			mysqli_query($db,"UPDATE `users` SET `cover` = '".$set_covers."' WHERE `id` = '".$user_id."' LIMIT 1") or die(mysqli_error());

			$return = array(
				'id' => count(objectToArray(json_decode($set_covers)))-1,
				'cover' => $settings['site_url'].'/uploads/covers/'.$img_t.'_2.jpg',
				'small' => $settings['site_url'].'/thumbs.php?src=uploads/covers/'.$img_t.'_2.jpg&w=65&h=65&zc1',
				'fit' => $img_t.'_2',
				'error' => 0
			);

		} else {

			$return = array('error' => '1');

		}

	}

	print_r(json_encode($return));
?>