<?php
	require_once('../config.php');

	$arr = array();
	$limit = 10;

	if(isset($_GET['id']) && $_GET['id']!='') {

		$id = safe_string($_GET['id']);

		if(isset($_GET['page']) && is_numeric($_GET['page'])) {
			$page = safe_string($_GET['page']);
			$page = $page * $limit;
		} else {
			$page = 0;
		} 

		if(isset($_GET['live']) && $_GET['live'] == 1) {
			$sql_38 = mysqli_query($db,"SELECT `id`,`msg`,`from`,`time`,`to` FROM `comments` WHERE `to` = '".$id."' ORDER BY `id` DESC LIMIT 3");
		} else {
			$sql_38 = mysqli_query($db,"SELECT `id`,`msg`,`from`,`time`,`to` FROM `comments` WHERE `to` = '".$id."' ORDER BY `id` DESC LIMIT $page,$limit");
		}

		while($fetch_38 = mysqli_fetch_array($sql_38)) {
		
			$sql_39 = mysqli_query($db,"SELECT `id`,`user`,`verified`,`name` FROM `users` WHERE `id` = '".$fetch_38['from']."' LIMIT 1");
			$fetch_39 = mysqli_fetch_array($sql_39);

			if($fetch_39['id'] == '') {
				$link_photo = get_current_host().'/thumbs.php?src=uploads/profiles/no_profile_pic.jpg&w=40&h=40';
			} else {
				$link_photo = get_current_host().'/picture/'.$fetch_39['id'].'/40/40';
			}

			if($settings['comments_links'] == 1) {
				$msg_s = create_links(strip_spam($fetch_38['msg']));
			} else {
				$msg_s = strip_spam($fetch_38['msg']);
			}

			if($settings['hashtags'] == 1) {
				$msg_s = create_hashtags($msg_s);
			}

			$msg_s = create_mention($msg_s);

			if(isset($_COOKIE['logged'])) {
				if($fetch_38['from'] == $_COOKIE['logged']) {
					$mine = 1;
				} else {
					$mine = 0;
				}
			} else {
				$mine = 0;
			}

			if($fetch_39['verified'] == 1 && $settings['verified'] == 1) {
				$verified_class = '<div class="comment_verified"><img src="'.get_current_host().'/assets/img/verified_small_2.png" width="13" height="13" /></div>';
			} else {
				$verified_class = '';
			}

			if($settings['comments_icons'] == 1) {
				$msg_s = '<div style="float:left;">'.$msg_s.'</div>';
				$msg_s = str_replace(':):','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/3.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':D','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/1.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':))','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/2.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':((','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/6.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':(','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/4.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':O','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/5.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(';)','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/7.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				$msg_s = str_replace(':)','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/8.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
			}

			$arr[] = array(
				'id' => $fetch_38['id'],
				'name' => strip_spam($fetch_39['name']),
				'msg' => $msg_s,
				'pic' => $link_photo,
				'profile' => $settings['site_url'].'/'.$fetch_39['user'],
				'profileuser' => $fetch_39['user'],
				'time' => timeAgo($fetch_38['time']),
				'mine' => $mine,
				'verified' => $verified_class
			);

		}

	}

	print_r(json_encode($arr));
?>