<?php
	require_once('../config.php');

	$arr = array();

	if(isset($_POST['gender']) && is_numeric($_POST['gender']) && isset($_POST['sortby']) && is_numeric($_POST['sortby'])) {

		$genders = safe_string($_POST['gender']);
		$sortbys = safe_string($_POST['sortby']);

		if($genders == 0) { $gender = ''; } else { $gender = $genders; }
		if($sortbys == '1') { $sortby = 'name,asc'; }
		if($sortbys == '2') { $sortby = 'name,desc'; }
		if($sortbys == '3') { $sortby = 'time,desc'; }
		if($sortbys == '4') { $sortby = 'time,asc'; }

	} else {

		$gender = '';
		$sortby = 'name,asc';

	}

	if(isset($_POST['tag']) && $_POST['tag']!='') {
		$tag = safe_string($_POST['tag']);
	} else {
		$tag = '';
	}

	if($sortby != '') { $sort = explode(',',$sortby); }

	$limit = 27;

	if(isset($_POST['page']) && is_numeric($_POST['page'])) {

		$page = safe_string($_POST['page']);
		$page = $page * $limit;

		if($gender != '') {
			if($sortby == '') {
				$sql_23 = mysqli_query($db,"SELECT `id`,`verified`,`name`,`cover`,`user`,`time`,`followers` FROM `users` WHERE `gender` = '".$gender."' AND `name` LIKE '%".$tag."%' ORDER BY `name` ASC LIMIT $page,$limit");
			} else {
				$sql_23 = mysqli_query($db,"SELECT `id`,`verified`,`name`,`cover`,`user`,`time`,`followers` FROM `users` WHERE `gender` = '".$gender."' AND `name` LIKE '%".$tag."%' ORDER BY $sort[0] $sort[1] LIMIT $page,$limit");
			}
		} else {
			if($sortby == '') {
				$sql_23 = mysqli_query($db,"SELECT `id`,`verified`,`name`,`cover`,`user`,`time`,`followers` FROM `users` WHERE `name` LIKE '%".$tag."%' ORDER BY `name` ASC LIMIT $page,$limit");
			} else {
				$sql_23 = mysqli_query($db,"SELECT `id`,`verified`,`name`,`cover`,`user`,`time`,`followers` FROM `users` WHERE `name` LIKE '%".$tag."%' ORDER BY $sort[0] $sort[1] LIMIT $page,$limit");
			}
		}

	}

	$arr['list'] = array();

	while($fetch_23 = mysqli_fetch_array($sql_23)) {

		if($fetch_23['followers'] == '' || $fetch_23['followers'] == '[]') {

			$follows = array();
			$follows_count = 0;

		} else {

			$follows = objectToArray(json_decode($fetch_23['followers']));
			$follows_count = str_to_k(count($follows));

		}

		if(isset($_COOKIE['logged'])) {

			$key = array_search('+'.$user_id.'+', $follows);
			if(isset($key) && is_numeric($key)) {
				$follow_status = strtolower($lang['unfollow']);
				$follow_status_2 = 'unfollow';
			} else {
				$follow_status = strtolower($lang['follow']);
				$follow_status_2 = 'follow';
			}

		} else {

			$follow_status = strtolower($lang['follow']);
			$follow_status_2 = 'follow';

		}

		if($fetch_23['cover'] == '' && $fetch_23['cover'] == '[]') {
			$bg = 'style="background:#E8E8E8"';
		} else {
			$get_covers = objectToArray(json_decode($fetch_23['cover']));
			if(isset($get_covers[0]) && $get_covers[0] != '') {
				$bg = 'style="background:url('.$settings['site_url'].'/thumbs.php?src=uploads/covers/'.$get_covers[0].'.jpg&w=343&h=100&zc=1) no-repeat"';
			} else {
				$bg = 'style="background:#E8E8E8"';
			}
		}

		if($fetch_23['verified'] == 1 && $settings['verified'] == 1) {
			$verified_class = '<img src="'.get_current_host().'/assets/img/verified_small_2.png" />';
		} else {
			$verified_class = '';
		}

		$arr['list'][] = array(
			'id' => $fetch_23['id'],
			'name' => strip_spam($fetch_23['name']),
			'pic' => $settings['site_url'].'/picture/'.$fetch_23['id'].'/75/75',
			'username' => $settings['site_url'].'/'.$fetch_23['user'],
			'profileuser' => $fetch_23['user'],
			'profileid' => $fetch_23['id'],
			'background_cover' => $bg,
			'follow' => $follow_status,
			'follow_2' => $follow_status_2,
			'time' => $fetch_23['time'],
			'follows_count' => $follows_count,
			'verified' => $verified_class
		);

	}

	print_r(json_encode($arr));
?>