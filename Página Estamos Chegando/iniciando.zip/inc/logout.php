<?php
session_start();
session_destroy();

unset($_COOKIE['logged']);
unset($_COOKIE['logged_gender']);
unset($_COOKIE['logged_name']);
unset($_COOKIE['logged_profile']);
unset($_COOKIE['logged_user']);
unset($_COOKIE['logged_email']);
unset($_COOKIE['logged_born']);
unset($_COOKIE['logged_desc']);
unset($_COOKIE['logged_security']);

setcookie('logged', '', time() - 3600, '/');
setcookie('logged_gender', '', time() - 3600, '/');
setcookie('logged_name', '', time() - 3600, '/');
setcookie('logged_profile', '', time() - 3600, '/');
setcookie('logged_user', '', time() - 3600, '/');
setcookie('logged_email', '', time() - 3600, '/');
setcookie('logged_born', '', time() - 3600, '/');
setcookie('logged_desc', '', time() - 3600, '/');
setcookie('logged_security', '', time() - 3600, '/');
?>