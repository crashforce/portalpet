<?php
	require_once('../config.php');

	if(isset($_POST['id']) && $_POST['id']!= '' ) {

		$id = safe_string($_POST['id']);
		$user = load_user($id);

		$user['covers'] = array();

		if($user['cover'] != '' || $user['cover'] != '[]') {

			$covers = objectToArray(json_decode($user['cover']));

			for($i=0;$i<=count($covers)-1;$i++) {

				$user['covers'][] = $covers[$i];

			}
		}

		if($user['pic'] == '') {
			$user['pic_count'] = 0;
		} else {
			$user['pic_count'] = 1;
		}

		$user['pic'] = $settings['site_url'].'/picture/'.$user['id'].'/180/185';

		print_r(json_encode($user));

	} else {

		echo '[]';

	}
?>