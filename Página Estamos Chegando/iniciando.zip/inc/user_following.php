<?php
	require_once('../config.php');

	$arr = array();

	if(isset($_GET['fid']) && is_numeric($_GET['fid'])) {

		$fid = safe_string($_GET['fid']);

		if(isset($user_id) && is_numeric($user_id)) {

			$sql_61 = mysqli_query($db,"SELECT * FROM `users` WHERE `id` = '".$user_id."' LIMIT 1");
			$fetch_61 = mysqli_fetch_array($sql_61);

			if($fetch_61['followers'] == '' || $fetch_61['followers'] == '[]') {
				$follows = array();
			} else {
				$follows = objectToArray(json_decode($fetch_61['followers']));
			}

		} else {

			$follows = array();

		}

		if(isset($_GET['id']) && is_numeric($_GET['id'])) {
			$limit = safe_string($_GET['id']);
			$sql_60 = mysqli_query($db,"SELECT `id`,`verified`,`name`,`user`,`pic`,`cover`,`followers` FROM `users` WHERE `id` < '".$limit."' AND `followers` LIKE '%+".$fid."+%' ORDER BY `id` DESC LIMIT 21");
		} else {
			$sql_60 = mysqli_query($db,"SELECT `id`,`verified`,`name`,`user`,`pic`,`cover`,`followers` FROM `users` WHERE `id` < '999999999999999' AND `followers` LIKE '%+".$fid."+%' ORDER BY `id` ASC LIMIT 21");
		}

		while($fetch_24 = mysqli_fetch_array($sql_60)) {

			if($fetch_24['followers'] == '' || $fetch_24['followers'] == '[]') {
				$follows_count = 0;
				$following = array();
			} else {
				$following = objectToArray(json_decode($fetch_24['followers']));
				$follows_count = str_to_k(count($following));
			}

			if(isset($_COOKIE['logged'])) {
				$key = array_search('+'.$user_id.'+', $following);
				if(isset($key) && is_numeric($key)) {
					$follow_status = strtolower($lang['unfollow']);
					$follow_status_2 = 'unfollow';
				} else {
					$follow_status = strtolower($lang['follow']);
					$follow_status_2 = 'follow';
				}
			} else {
				$follow_status = strtolower($lang['follow']);
				$follow_status_2 = 'follow';
			}

			if($fetch_24['cover'] == '' && $fetch_24['cover'] == '[]') {
				$bg = 'style="background:#E8E8E8"';
			} else {
				$get_covers = objectToArray(json_decode($fetch_24['cover']));
				if(isset($get_covers[0]) && $get_covers[0] != '') {
					$bg = 'style="background:url('.$settings['site_url'].'/thumbs.php?src=uploads/covers/'.$get_covers[0].'.jpg&w=343&h=100&zc=1) no-repeat"';
				} else {
					$bg = 'style="background:#E8E8E8"';
				}
			}

			if($fetch_24['verified'] == 1 && $settings['verified'] == 1) {
				$verified_class = '<img src="'.get_current_host().'/assets/img/verified_small_2.png" />';
			} else {
				$verified_class = '';
			}

			$arr[] = array(
				'id' => $fetch_24['id'],
				'profileuser' => $fetch_24['user'],
				'name' => strip_spam($fetch_24['name']),
				'background_cover' => $bg,
				'pic' => $settings['site_url'].'/picture/'.$fetch_24['id'].'/85/85',
				'follow' => $follow_status,
				'follow_2' => $follow_status_2,
				'username' => $settings['site_url'].'/'.$fetch_24['user'],
				'follows_count' => $follows_count,
				'verified' => $verified_class
			);


		}

	}

	print_r(json_encode($arr));
?>