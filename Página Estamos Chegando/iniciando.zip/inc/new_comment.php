<?php
	require_once('../config.php');

	if(isset($_SESSION['spam_filter']) && $_SESSION['spam_filter'] != '') {
		$spam_check = $_SESSION['spam_filter'];
	} else {
		$spam_check = 0;
	}

	if($spam_check < time()) {

		if(isset($_POST['msg']) && strlen($_POST['msg']) > 0 && isset($_POST['to']) && $_POST['to']!='' && isset($_COOKIE['logged'])) {

			$msg = strip_spam($_POST['msg']);
			$to = safe_string($_POST['to']);

			if(mysqli_query($db,"INSERT INTO `comments` (`time`,`to`,`from`,`msg`) VALUES ('".time()."','".$to."','".$user_id."','".$msg."')")) {

				$last_id = mysqli_insert_id($db);

				$sql_46 = mysqli_query($db,"SELECT `id`,`uid`,`comments` FROM `photos` WHERE `url` = '".$to."' LIMIT 1");
				$fetch_46 = mysqli_fetch_array($sql_46);

				$old_count = $fetch_46['comments'] + 1;
				mysqli_query($db,"UPDATE `photos` SET `comments` = '".$old_count."' WHERE `url` = '".$to."' LIMIT 1");

				$sql_40 = mysqli_query($db,"SELECT `id`,`user`,`name` FROM `users` WHERE `id` = '".$user_id."' LIMIT 1");
				$fetch_40 = mysqli_fetch_array($sql_40);

				if($settings['comments_links'] == 1) {
					$msg_s = create_links(strip_spam($msg));
				} else {
					$msg_s = strip_spam($msg);
				}

				if($settings['hashtags'] == 1) {
					$msg_s = create_hashtags($msg_s);
				}

				$msg_s = create_mention($msg_s);

				if($settings['comments_icons'] == 1) {
					$msg_s = '<div style="float:left;">'.$msg_s.'</div>';
					$msg_s = str_replace(':):','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/3.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
					$msg_s = str_replace(':D','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/1.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
					$msg_s = str_replace(':))','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/2.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
					$msg_s = str_replace(':((','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/6.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
					$msg_s = str_replace(':(','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/4.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
					$msg_s = str_replace(':O','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/5.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
					$msg_s = str_replace(';)','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/7.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
					$msg_s = str_replace(':)','</div><div style="float:left;margin-bottom:1px;background:url('.get_current_host().'/assets/img/emoticons/8.png) no-repeat center center;width:15px;height:13px;"></div><div style="float:left;">',$msg_s);
				}	

				$arr = array(
					'id' => $last_id,
					'name' => strip_spam($fetch_40['name']),
					'msg' => $msg_s,
					'pic' => $settings['site_url'].'/picture/'.$fetch_40['id'].'/40/40',
					'profile' => $settings['site_url'].'/'.$fetch_40['user'],
					'profileuser' => $fetch_40['user'],
					'time' => timeAgo(time()),
					'error' => 0
				);

				if($fetch_46['uid'] != $user_id) {
					add_activity('2',$fetch_46['uid'],$msg,$to);
				}

				$_SESSION['spam_filter'] = time() + 2;

			} else {
				$arr = array('error' => 1);
			}

		} else {
			$arr = array('error' => 2);
		}

	} else {
		$arr = array('error' => 3);
	}

	print_r(json_encode($arr));
?>