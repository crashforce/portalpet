<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged']) && isset($_POST['id']) && is_numeric($_POST['id'])) {

		$id = safe_string($_POST['id']);

		$sql_57 = mysqli_query($db,"SELECT `id`,`cover` FROM `users` WHERE `id` = '".$user_id."' LIMIT 1");
		$fetch_57 = mysqli_fetch_array($sql_57);

		if($fetch_57['cover'] != '' || $fetch_57['cover'] != '[]') {

			$covers = objectToArray(json_decode($fetch_57['cover']));

			$primary = $covers[$id];
			unset($covers[$id]);

			array_unshift($covers, $primary);

			print_r(json_encode($covers));
		
			mysqli_query($db,"UPDATE `users` SET `cover` = '".json_encode($covers)."' WHERE `id` = '".$user_id."' LIMIT 1");

		}

	}
?>