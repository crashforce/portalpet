<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged']) && isset($_POST['id']) && is_numeric($_POST['id'])) {

		$id = safe_string($_POST['id']);
		
		if($sql_69 = mysqli_query($db,"DELETE FROM `activity` WHERE `id` = '".$id."' AND `uid` = '".$user_id."' LIMIT 1")) {
		
			echo 1;

		} else {

			echo 0;

		}

	} else {

		echo 0;

	}
?>