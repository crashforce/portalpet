<?php
	require_once('../config.php');

	$unique_id = unique_id();

	if(count($_FILES) > 0 && $_FILES['file']['error'] == 0) {

		if($_FILES['file']['type'] == 'image/jpeg') { $type = 1; }
		if($_FILES['file']['type'] == 'image/png') { $type = 2; }
		if($_FILES['file']['type'] == 'image/gif') { $type = 3; }
		if($_FILES['file']['type'] == 'image/jpg') { $type = 4; }

		if($mobile == 1) { $type = 1; }

		if(isset($type) && $type < 5) {

			if(move_uploaded_file($_FILES['file']['tmp_name'],$folder.'/uploads/profiles/'.$unique_id.'.jpg')) {

				list($width, $height, $type, $attr) = getimagesize($folder.'/uploads/profiles/'.$unique_id.'.jpg');

				if($width < 180 || $height < 185) {
	
					echo 2;

				} else {

					if(copy($settings['site_url'].'/thumbs.php?src=uploads/profiles/'.$unique_id.'.jpg&w=180&h=185&zc=1',$folder.'/uploads/profiles/'.$unique_id.'_2.jpg')) {
						unlink($folder.'/uploads/profiles/'.$unique_id.'.jpg');
						echo $unique_id.'_2';
						mysqli_query($db,"UPDATE `users` SET `pic` = '".$unique_id."_2' WHERE `id` = '".$user_id."' LIMIT 1");
					}

				}

			} else {

				echo 4;

			}		

		} else {

			echo 3; 
			
		}

	} else {

		echo 4;

	}
?>