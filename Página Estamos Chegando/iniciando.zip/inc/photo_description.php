<?php
	require_once('../config.php');

	if(isset($_COOKIE['logged'])) {

		if(isset($_POST['id']) && $_POST['id']!='') {
	
			$id = safe_string($_POST['id']);

			$sql_10 = mysqli_query($db,"SELECT `id`,`desc`,`uid` FROM `photos` WHERE `uid` = '".$user_id."' AND `url` = '".$id."' LIMIT 1");
			$fetch_10 = mysqli_fetch_array($sql_10);

			echo html_entity_decode(stripslashes($fetch_10['desc']),ENT_QUOTES);

		}

	}
?>