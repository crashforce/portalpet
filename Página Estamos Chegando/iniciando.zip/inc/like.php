<?php
	require_once('../config.php');
	
	if(isset($_COOKIE['logged']) && isset($_POST['pid']) && $_POST['pid']!='' && isset($_POST['status']) && $_POST['status']!='') {
	
		$id = safe_string($_POST['pid']);
		$status = check_rate($id);

		$like = set_like($id,$status);
	
		if($like == '1') {

			echo 1;

			$sql_51=mysqli_query($db,"SELECT `id`,`uid` FROM `photos` WHERE `url` = '".$id."' LIMIT 1");
			$fetch_51 = mysqli_fetch_array($sql_51);

			if($fetch_51['uid'] != $user_id) {
				if($status == 1) { 
					add_activity('6',$fetch_51['uid'],'10',$id);
				} else {
					add_activity('7',$fetch_51['uid'],'10',$id);	
				}
			}
		
		} else {
			
			echo 2;

		}

	} else {

		echo 3;
	
	}
?>