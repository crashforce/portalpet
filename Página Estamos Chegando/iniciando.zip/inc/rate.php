<?php
	require_once('../config.php');
	
	if(isset($_COOKIE['logged']) && isset($_POST['id']) && $_POST['id']!='' && isset($_POST['pid']) && $_POST['pid']!='') {
	
		$id = safe_string($_POST['id']);
		$pid = safe_string($_POST['pid']);

		$vote = explode('|',set_rate($pid,$id));
	
		if($vote[0] == '1') {

			echo $vote[1].'|'.$vote[2];

			$sql_51=mysqli_query($db,"SELECT `id`,`uid` FROM `photos` WHERE `url` = '".$pid."' LIMIT 1");
			$fetch_51 = mysqli_fetch_array($sql_51);

			if($fetch_51['uid'] != $user_id) {
				add_activity('1',$fetch_51['uid'],$id,$pid);
			}
		
		} else {
			
			echo 2;

		}

	} else {

		echo 3;
	
	}
?>