	
	<?php if(!isset($_COOKIE['cookie_ok']) && $settings['cookie_bar'] == 1) { ?>
	<div class="cookie_bar">
		<span class="cookie_text"><?=$lang['cookie_text'];?></span>
		&nbsp;<span class="cookie_ok"><?=$lang['cookie_ok'];?></span>
	</div>
	<?php } ?>

	<?php
	if($settings['allow_lang'] == 1 && $mobile == 0) {
		$language_style = '<div class="menu_languages unselect">';
		for($i=1;$i<=count($languages_list);$i++) {
			$language_style.='<div data-file="'.$languages_list[$i]['file'].'" class="menu_languages_box_item">'.$languages_list[$i]['name'].'</div>';
		}
		$language_style.= '</div>';
	}
	if($settings['allow_lang'] == 1 && $mobile == 0) {
		$lang_menu_link = '<span style="position:relative;">
					<span class="footer_button hit_language">'.$lang['menu_language'].'</span>
					'.$language_style.'
					<span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
				</span>';
	} else {
		$lang_menu_link = '';
	}

	if($settings['video'] == 1) {
		$browse_posts_lang = $lang['browse_title_posts'];
	} else {
		$browse_posts_lang = $lang['browse_title_photos'];
	}

	$footer = '
	<div class="footer_clear"></div>
	<div class="footer_home">
		<div class="footer_opac"></div>
		<div class="footer_box">

		<div class="logo_homes call_live_home logo_footer">'.$settings['logo_text'].'</div>

		<div class="footer_copyright">'.$lang['footer_copyright'].'</div>
		
			<div class="right footer_rightside">
				<div class="footer_home_content">			
					<span class="call_live_about footer_button hit_page_1" data-page="about">'.$lang['pages_about'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_faq footer_button hit_page_2">'.$lang['pages_faq'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_terms footer_button hit_page_4">'.$lang['pages_terms'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_privacy footer_button hit_page_3">'.$lang['pages_privacy'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_users footer_button">'.$lang['header_menu_users'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_browse footer_button">'.$browse_posts_lang.'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					'.$lang_menu_link.'
					<span class="hit_contact footer_button">'.$lang['pages_contact'].'</span>
				</div>
			</div>

		</div>
	</div>';

	$footer_mobile = '
	<div class="footer_clear"></div>
	<div class="footer_home footer_home_x">
		<div class="footer_opac"></div>
		
		<div class="footer_box">

			<div class="footer_copyright">'.$lang['footer_copyright'].'</div>
		
			<div class="footer_subbox">
				<div class="footer_home_content">			
					<span class="call_live_about footer_button hit_page_1" data-page="about">'.$lang['pages_about'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_faq footer_button hit_page_2">'.$lang['pages_faq'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_terms footer_button hit_page_4">'.$lang['pages_terms'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_privacy footer_button hit_page_3">'.$lang['pages_privacy'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_users footer_button">'.$lang['header_menu_users'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="call_live_browse footer_button">'.$browse_posts_lang.'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="footer_button hit_language">'.$lang['menu_language'].'</span><span class="footer_space">&nbsp;&nbsp;&nbsp;&nbsp;</span>
					<span class="hit_contact footer_button">'.$lang['pages_contact'].'</span>
				</div>
			</div>

		</div>
	</div>';

	echo '</div>';

	if($mobile == 1) {
		echo $footer_mobile;
	} else {
		echo $footer;
	}

	if(isset($_GET['photo']) && $_GET['photo']!='') { if(isset($_GET['pop_type']) && $_GET['pop_type'] == 1) { $pop_type = 1; } else { $pop_type = 0; }
	echo '<div class="auto" data-type="'.$pop_type.'" data-id="'.$_GET['photo'].'"></div>'; } ?>
	
	<input type="hidden" id="_logged" value="<?php if(isset($_COOKIE['logged'])) { echo 1; } else { echo '0'; } ?>" />
	<input type="hidden" id="_loggedid" value="<?php if(isset($_COOKIE['logged'])) { echo $user_id; } else { echo '0'; } ?>" />
	<input type="hidden" id="_followerid" value="<?php if(isset($user['id'])) { echo $user['id']; } else { echo '0'; } ?>" />
	<input type="hidden" id="_logged_in" value="<?php if(isset($_COOKIE['logged']) && isset($id) && $user_id == $id) { echo 1; } else { echo 0; } ?>" />
	<input type="hidden" id="_current_id" value="<?php if(isset($user['id'])) { echo $user['id']; } else { echo '0'; } ?>" />
	<input type="hidden" id="_current_user" value="<?php if(isset($id)) { echo $id; } else { echo '0'; } ?>" />
	<input type="hidden" id="_hashtag" value="<?php if(isset($hashtag)) { echo $hashtag; } ?>" />
	<input type="hidden" id="_main_now" value="" />
	<input type="hidden" id="_settings_loaded" value="0" />
	<input type="hidden" id="_ads_loaded" value="0" />
	<input type="hidden" id="_ads_loaded_2" value="0" />
	<input type="hidden" id="_ads_loaded_3" value="0" />
	<input type="hidden" id="_load_start" value="0" /> 
	<input type="hidden" id="_ad_728_active" value="<?php if($settings['ad_728_90'] != '') { echo 1; } else { echo 0; } ?>" />
	<input type="hidden" id="_ad_468_active" value="<?php if($settings['ad_468_15'] != '') { echo 1; } else { echo 0; } ?>" />
	<input type="hidden" id="_ad_300_active" value="<?php if($settings['ad_300_250'] != '') { echo 1; } else { echo 0; } ?>" />
	<input type="hidden" id="_ad_320_active" value="<?php if($settings['ad_320_50'] != '') { echo 1; } else { echo 0; } ?>" />

	<?php if($mobile == 0) { ?>
	<script type="text/javascript">var tag_728_90 = ''; var tag_300_250 = ''; var tag_468_15 = '';</script>
	<div style="width:728px;height:90px;display:none;" id="tag_728_90"><?=$settings['ad_728_90'];?></div>
	<div style="width:300px;height:250px;display:none;" id="tag_300_250"><?=$settings['ad_300_250'];?></div>
	<div style="width:468px;height:15px;display:none;" id="tag_468_15"><?=$settings['ad_468_15'];?></div>
	<?php } else { ?>
	<script type="text/javascript">var tag_320_50 = '';</script>
	<div style="width:320px;height:50px;display:none;" id="tag_320_50"><?=$settings['ad_320_50'];?></div>
	<?php } ?>

	<script src="assets/jquery/jquery-2.1.3.min.js" type="text/javascript"></script>
	<script src="assets/jquery/jquery.form.js" type="text/javascript"></script>
	<script src="assets/jquery/jquery.imgload.js" type="text/javascript"></script>
	<script src="assets/jquery/jquery.jWindowCrop.js" type="text/javascript"></script>
	<script src="assets/jquery/jquery.mousewheel.js" type="text/javascript"></script>
	<script src="assets/jquery/perfect-scrollbar.js" type="text/javascript"></script>

	<?php if($mobile == 0) { ?>
	<script type="text/javascript">
	$('#comments_area').perfectScrollbar();
	$('#conversation').perfectScrollbar();
	$('.messages_box').perfectScrollbar({ suppressScrollX: true });
	$('.activity_box').perfectScrollbar({ suppressScrollX: true });
	</script>
	<?php } ?>

	<script src="http://connect.facebook.net/en_US/all.js"></script>
	<script>
		FB.init({ appId:'<?=$settings['fb_api'];?>', cookie:true, status:true, xfbml:true });
		
		function FacebookInviteFriends() {
			FB.ui({
    				method: 'send',
    				name: 'Join to Selfie',
    				link: '<?=get_current_host();?>',
			});
		}
	</script>

	<div id="fb-root"></div>

	<script type="text/javascript">
	<?php if($mobile == 1) {
	
		if($detect->isWindowsMobileOS()) {
			echo "var mobile_supported = 1;";
		} else {
			echo "var mobile_supported = 1;";
		}
		
		echo "var mobile = '1';";
	
	} else {
		echo "var mobile = '0';";
		echo "var mobile_supported = 1;";
	} ?>
	var app_id = '<?=$settings['fb_api'];?>';
	var home_style = <?=$settings['home_style'];?>;
	var custom_bar_style = '<?=$settings['custom_4'];?>';
	var temp_page = '';
	var video_system = '<?=$settings['video'];?>';
	var files_limit = 5;
	var slide_start = null;
	var follower_id = 0;
	<?php if($page == 'home') { ?>var the_page = 'home'; <?php } else { ?>var the_page = 'not_home';<?php } ?>
	var site_url = '<?php echo $settings['site_url'];?>';
	var page_now = '<?=$page;?>';
	var main_now = '<?php echo $page; ?>';
	var request_uri = '<?php echo get_current_page(); ?>';
	var page_url = site_url+'/'+request_uri;
	var current_page = '<?=get_current_url();?>';
	var video_skin = '<?php if($settings['video_skin'] == 1) { echo 'light'; } else { echo 'dark'; } ?>';
	var video_size_w = '<?=$settings['video_size_w'];?>';
	var video_size_h = '<?=$settings['video_size_h'];?>';
	var rating_system = '<?=$settings['rating_system'];?>';
	var report_setting = '<?=$settings['report_setting'];?>';
	var remove_comment_option = '<?=$settings['remove_comments'];?>';
	var cover_slide = null;
	var last_count_photos = 16;
	var last_count_follow = 21;
	var feed_update = null;
	var activity_update = null;
	var feed_limit = 15;
	var users_limit = 27;
	var browse_limit = 15;
	var follower_status = 0;
	var hashtags_limit = 15;
	var activity_limit = 15;

	var lang = {
		header_search_no_results: '<?=$lang['header_search_no_results'];?>',
		activity_no_results: '<?=$lang['header_activity_no_results'];?>',
		follow: '<?=$lang['follow'];?>',
		unfollow: '<?=$lang['unfollow'];?>',
		messages_no_results: '<?=$lang['header_messages_no_results'];?>',
		user_remove_cover:'<?=$lang['user_remove_cover'];?>',
		user_make_primary: '<?=$lang['user_make_primary'];?>',	
		user_edit_photo: '<?=$lang['user_edit_photo'];?>',
		user_edit_video: '<?=$lang['user_edit_video'];?>',
		user_remove_video: '<?=$lang['user_remove_video'];?>',
		user_remove_photo: '<?=$lang['user_remove_photo'];?>',
		spam_filter: '<?=$lang['photo_comment_spam'];?>',
		pop_edit_photo: '<?=$lang['edit_photo_title'];?>',
		pop_edit_video: '<?=$lang['edit_video_title'];?>',
		pop_edit_photo_desc: '<?=$lang['edit_photo_description'];?>',
		pop_edit_video_desc: '<?=$lang['edit_video_description'];?>',
		pop_edit_save_video: '<?=$lang['edit_video_save_button'];?>',
		pop_edit_save_photo: '<?=$lang['edit_photo_save_button'];?>',
		remove_comment: '<?=$lang['remove_comment'];?>',
		like_button: '<?=$lang['like_button'];?>',
		unlike_button: '<?=$lang['unlike_button'];?>',
		pop_upload_description: '<?=$lang['pop_upload_description'];?>',
		pop_upload_video_description: '<?=$lang['pop_upload_video_description'];?>',
		pop_upload_video_url: '<?=$lang['pop_upload_video_url'];?>',
		upload_photo_input: '<?=$lang['upload_photo_input'];?>',
		uploading: '<?=$lang['uploading'];?>',
		upload_limit: '<?=$lang['upload_limit'];?>',
		title_home: '<?=$settings['meta_1'];?>',
		title_trending: '<?=$lang['feed_buttons_trending'];?>',
		title_activity: '<?=$lang['feed_buttons_activity'];?>',
		title_feed: '<?=$lang['feed_buttons_feed'];?>',
		title_users: '<?=$settings['meta_4'];?>',
		title_user: '<?=$settings['meta_7'];?>',
		title_feed: '<?=$lang['header_menu_feed'];?>',
		title_browse: '<?php if($settings['video']==1) { echo $lang['browse_title_posts']; } else { echo $lang['browse_title_photos']; } ?>',
		title_faq: '<?=$lang['pages_faq'];?>',
		title_terms: '<?=$lang['pages_terms'];?>',
		title_privacy: '<?=$lang['pages_privacy'];?>',
		title_about: '<?=$lang['pages_about'];?>'
	};
	</script>

	<script type="text/javascript" src="assets/js/functions.js"></script>
	<script type="text/javascript" src="assets/js/overlay.js"></script>
	<script type="text/javascript" src="assets/js/photo.js"></script>
	<script type="text/javascript" src="assets/js/members.js"></script>
	<script type="text/javascript" src="assets/js/search.js"></script>
	<script type="text/javascript" src="assets/js/rate.js"></script>
	<script type="text/javascript" src="assets/js/feed.js"></script>
	<script type="text/javascript" src="assets/js/user.js"></script>
	<script type="text/javascript" src="assets/js/users.js"></script>
	<script type="text/javascript" src="assets/js/browse.js"></script>
	<script type="text/javascript" src="assets/js/hashtags.js"></script>
	<script type="text/javascript" src="assets/js/notifications.js"></script>
	<script type="text/javascript" src="assets/js/messages.js"></script>
	<script type="text/javascript" src="assets/js/activity.js"></script>
	<script type="text/javascript" src="assets/js/chat.js"></script>
	<script type="text/javascript" src="assets/js/upload_photo.js"></script>
	<script type="text/javascript" src="assets/js/upload_video.js"></script>
	<script type="text/javascript" src="assets/js/settings.js"></script>
	<script type="text/javascript" src="assets/js/facebook.js"></script>

	<script type="text/javascript">
	<?php
	if(isset($_GET['page']) && $_GET['page'] == 'home') {
		if(isset($_COOKIE['logged']) && is_numeric($_COOKIE['logged']) && !isset($_GET['tab'])) {
			echo "load_live_page('feed');";
		} else {
			if(!isset($_GET['tab'])) { echo "load_live_page('home');"; }
		}
	}
	if(!isset($_GET['page']) && !isset($_GET['id'])) {
		if(isset($_COOKIE['logged']) && is_numeric($_COOKIE['logged']) && !isset($_GET['tab'])) {
			echo "load_live_page('feed');";
		} else {
			if(!isset($_GET['tab'])) { echo "load_live_page('home');"; }
		}
	}
	if(isset($_GET['page']) && $_GET['page'] == 'browse') { echo "load_live_page('browse');"; }
	if(isset($_GET['page']) && $_GET['page'] == 'users') { echo "load_live_page('users');"; }
	if(isset($_GET['photo']) && $_GET['photo']!='') { echo "$('.auto').click();"; }
	if(isset($_GET['id']) && $_GET['id']!='') { echo 'load_live_page(\'profile\',\''.safe_string($_GET['id']).'\');'; }
	if(isset($_GET['hashtags']) && $_GET['hashtags']!='') { echo 'load_live_page(\'hashtag\',\''.safe_string($_GET['hashtags']).'\');'; }
	if($page == 'home' && isset($_GET['tab']) && $_GET['tab'] == 'trending') { echo 'load_live_page(\'trending\');'; }
	if($page == 'home' && isset($_GET['tab']) && $_GET['tab'] == 'activity') { echo 'load_live_page(\'activity\');'; }
	if(isset($_GET['pop']) && $_GET['pop'] == 'login') { echo "$('#login_but').click();"; }
	if(isset($_GET['pop']) && $_GET['pop'] == 'join') { echo "$('#join_but').click();"; }
	if(isset($_GET['pop']) && $_GET['pop'] == 'contact') { echo "$('.hit_contact').click();"; }
	if(isset($_GET['pop']) && $_GET['pop'] == 'lostpw') { echo "$('.pop_login_recover').click();"; }
	if(isset($_GET['pop']) && $_GET['pop'] == 'settings') { echo "$('.call_settings').click();"; }
	if(isset($_GET['tab']) && $_GET['tab'] == 'settings_about') { echo "$('.settings_pop').show(); $('#settings_button_about').click();"; }
	if(isset($_GET['tab']) && $_GET['tab'] == 'settings_social') { echo "$('.settings_pop').show(); $('#settings_button_social').click();"; }
	if(isset($_GET['tab']) && $_GET['tab'] == 'settings_password') { echo "$('.settings_pop').show(); $('#settings_button_password').click();"; }
	if(isset($_GET['id']) && isset($_GET['tab']) && $_GET['tab']=='followers') { echo "$('#followers_menu').click();"; }
	if(isset($_GET['id']) && isset($_GET['tab']) && $_GET['tab']=='following') { echo "$('#following_menu').click();"; }
	if(isset($_GET['id']) && isset($_GET['tab']) && $_GET['tab']=='about') { echo "$('#about_menu').click();"; }
	if(isset($_GET['page']) && $_GET['page'] == 'pages' && isset($_GET['no']) && $_GET['no'] == 'about') { echo "load_live_page('about');"; }
	if(isset($_GET['page']) && $_GET['page'] == 'pages' && isset($_GET['no']) && $_GET['no'] == 'terms') { echo "load_live_page('terms');"; }
	if(isset($_GET['page']) && $_GET['page'] == 'pages' && isset($_GET['no']) && $_GET['no'] == 'privacy') { echo "load_live_page('privacy');"; }
	if(isset($_GET['page']) && $_GET['page'] == 'pages' && isset($_GET['no']) && $_GET['no'] == 'faq') { echo "load_live_page('faq');"; }
	?></script>

	<?=$settings['analytics'];?>

</body>
</html>