<?php
	require_once('inc/db.php');

	if(!isset($installed)) {
		header('location: install_selfie.php');
		exit();
	}

	if(isset($header_sent) && $header_sent == 1) {

		// Empty query

	} else {

		session_start();

		error_reporting(E_ALL);
		ini_set('display_errors','0');

		$subfolder = '';
		$folder = $_SERVER['DOCUMENT_ROOT'].'/'.$subfolder;

		////////////////////////////////////////////

		if(isset($_COOKIE['logged'])) {
			$user_id = $_COOKIE['logged'];
		} else {
			$user_id = '';
		}

		require_once($folder.'/inc/functions.php');

		if(isset($home) && $home == 1) {
			if(isset($_COOKIE['logged'])) {
				$page = 'index';
			} else {
				$page = 'home';
			}
		}

		if(isset($_COOKIE['logged'])) { $user_info = load_user($_COOKIE['logged']); }

		/////////////// DO NOT EDIT ////////////////

		$cp_tag = 'selfie'; // control panel files protection

		////////////////////////////////////////////

	}
?>